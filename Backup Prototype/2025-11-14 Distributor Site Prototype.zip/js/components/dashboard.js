// Dashboard Component

var DashboardComponent = {
  init: function() {
    this.render();
    this.attachEvents();
  },
  
  render: function() {
    $('#app-container').html(Templates.dashboardPage());
    this.updateActiveNav('dashboard');
  },
  
  attachEvents: function() {
    var self = this;
    
    // Partner card click (but not when clicking buttons)
    $(document).on('click', '.partner-card', function(e) {
      // Don't navigate if clicking on a button
      if ($(e.target).closest('button').length > 0) {
        return;
      }
      var partnerId = $(this).data('partner-id');
      App.navigate('partner-detail', { partnerId: partnerId });
    });
    
    // Edit partner button on card
    $(document).on('click', '.edit-partner-card-btn', function(e) {
      e.stopPropagation(); // Prevent card click
      var partnerId = $(this).data('partner-id');
      App.navigate('partner-form', { partnerId: partnerId });
    });
    
    // Manage partner button on card
    $(document).on('click', '.manage-partner-btn', function(e) {
      e.stopPropagation(); // Prevent card click
      var partnerId = $(this).data('partner-id');
      App.navigate('partner-detail', { partnerId: partnerId });
    });
    
    // Create partner button
    $(document).on('click', '#create-partner-btn', function() {
      App.navigate('partner-form');
    });
    
    // Search partners
    $(document).on('input', '#partner-search', function() {
      var query = $(this).val().toLowerCase();
      self.filterPartners(query);
    });
  },
  
  updateActiveNav: function(view) {
    $('.nav-link').removeClass('active');
    $('.nav-link[data-nav="' + view + '"]').addClass('active');
  },
  
  filterPartners: function(searchTerm) {
    var filtered = AppState.partners;
    
    if (searchTerm) {
      searchTerm = searchTerm.toLowerCase();
      filtered = AppState.partners.filter(function(partner) {
        return partner.name.toLowerCase().indexOf(searchTerm) > -1 ||
               (partner.industry && partner.industry.toLowerCase().indexOf(searchTerm) > -1);
      });
    }
    
    $('#partner-grid').html(Templates.partnerCards(filtered));
  }
};