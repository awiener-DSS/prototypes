// Employee Bulk Import Component

var EmployeeBulkImport = {
  currentPartnerId: null,
  selectedGroupId: null,
  
  show: function(partnerId) {
    this.currentPartnerId = partnerId;
    var partner = AppState.getPartnerById(partnerId);
    
    // Find Default Group or first available group
    var defaultGroup = partner.groups.find(function(g) { return g.name === 'Default Group'; });
    this.selectedGroupId = defaultGroup ? defaultGroup.id : (partner.groups[0] ? partner.groups[0].id : null);
    
    this.renderModal(partner);
  },
  
  renderModal: function(partner) {
    var self = this;
    
    var modalHtml = '<div class="modal fade" id="bulk-import-modal" tabindex="-1">' +
      '<div class="modal-dialog modal-lg">' +
      '<div class="modal-content">' +
      '<div class="modal-header">' +
      '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
      '<h4 class="modal-title">Bulk Import Employees</h4>' +
      '</div>' +
      '<div class="modal-body">' +
      '<div class="alert alert-info">' +
      '<strong><span class="glyphicon glyphicon-info-sign"></span> How it works:</strong>' +
      '<ol class="mb-0 mt-2">' +
      '<li>Download the CSV template</li>' +
      '<li>Fill in employee information</li>' +
      '<li>Select the user group for these employees</li>' +
      '<li>Upload the completed CSV file</li>' +
      '</ol>' +
      '</div>' +
      '<div class="panel panel-default">' +
      '<div class="panel-heading"><strong>Step 1: Download Template</strong></div>' +
      '<div class="panel-body">' +
      '<p class="text-muted">Download a CSV template with the correct column headers based on this partner\'s configuration.</p>' +
      '<button type="button" class="btn btn-primary" id="download-template-btn">' +
      '<span class="glyphicon glyphicon-download-alt"></span> Download CSV Template' +
      '</button>' +
      '</div>' +
      '</div>' +
      '<div class="panel panel-default">' +
      '<div class="panel-heading"><strong>Step 2: Select User Group</strong></div>' +
      '<div class="panel-body">' +
      '<p class="text-muted">Choose which user group the imported employees should be assigned to.</p>' +
      '<div class="form-group">' +
      '<label>User Group *</label>' +
      '<select class="form-control" id="bulk-import-group-select">' +
      partner.groups.map(function(g) {
        var groupVouchers = partner.vouchers.filter(function(v) {
          return v.userGroupIds && v.userGroupIds.indexOf(g.id) > -1;
        });
        var totalAmount = groupVouchers.reduce(function(sum, v) { return sum + v.defaultAmount; }, 0);
        var selected = g.id === self.selectedGroupId ? ' selected' : '';
        return '<option value="' + g.id + '"' + selected + '>' +
          Helpers.escapeHtml(g.name) + ' - $' + totalAmount.toFixed(2) + ' (' + groupVouchers.length + ' vouchers)' +
          '</option>';
      }).join('') +
      '</select>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div class="panel panel-default">' +
      '<div class="panel-heading"><strong>Step 3: Upload File</strong></div>' +
      '<div class="panel-body">' +
      '<p class="text-muted">Upload your completed CSV file with employee data.</p>' +
      '<div class="form-group">' +
      '<label class="btn btn-success" for="csv-file-input">' +
      '<span class="glyphicon glyphicon-upload"></span> Choose CSV File' +
      '</label>' +
      '<input type="file" id="csv-file-input" accept=".csv" style="display: none;">' +
      '<p class="help-block" id="file-name-display">No file selected</p>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div id="import-progress" style="display: none;">' +
      '<div class="progress">' +
      '<div class="progress-bar progress-bar-striped active" role="progressbar" style="width: 0%;" id="import-progress-bar">' +
      '<span id="import-progress-text">0%</span>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div id="import-results" style="display: none;" class="alert"></div>' +
      '</div>' +
      '<div class="modal-footer">' +
      '<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>';
    
    $('body').append(modalHtml);
    $('#bulk-import-modal').modal('show');
    
    this.attachModalEvents(partner);
    
    $('#bulk-import-modal').on('hidden.bs.modal', function() {
      $(this).remove();
    });
  },
  
  attachModalEvents: function(partner) {
    var self = this;
    
    // Download template
    $(document).on('click', '#download-template-btn', function() {
      self.downloadTemplate(partner);
    });
    
    // Group selection
    $(document).on('change', '#bulk-import-group-select', function() {
      self.selectedGroupId = $(this).val();
    });
    
    // File selection
    $(document).on('change', '#csv-file-input', function(e) {
      var fileName = e.target.files[0] ? e.target.files[0].name : 'No file selected';
      $('#file-name-display').text(fileName);
      
      if (e.target.files[0]) {
        self.processFile(e.target.files[0], partner);
      }
    });
  },
  
  downloadTemplate: function(partner) {
    // Build header based on partner's employee field configuration
    var headers = ['First Name', 'Last Name'];
    
    if (partner.employeeFieldConfig.requireEmployeeId) {
      headers.push('Employee ID');
    }
    if (partner.employeeFieldConfig.requireUsername) {
      headers.push('Username');
    }
    if (partner.employeeFieldConfig.requireDateOfBirth) {
      headers.push('Date of Birth');
    }
    if (partner.employeeFieldConfig.requireStartDate) {
      headers.push('Start Date');
    }
    headers.push('Notes');
    
    // Create CSV with header row
    var csv = headers.join(',') + '\n';
    
    // Add example rows
    var exampleRow1 = ['John', 'Doe'];
    if (partner.employeeFieldConfig.requireEmployeeId) exampleRow1.push('EMP001');
    if (partner.employeeFieldConfig.requireUsername) exampleRow1.push('jdoe');
    if (partner.employeeFieldConfig.requireDateOfBirth) exampleRow1.push('1990-01-15');
    if (partner.employeeFieldConfig.requireStartDate) exampleRow1.push('2020-01-01');
    exampleRow1.push('Example notes for employee');
    csv += exampleRow1.join(',') + '\n';
    
    var exampleRow2 = ['Jane', 'Smith'];
    if (partner.employeeFieldConfig.requireEmployeeId) exampleRow2.push('EMP002');
    if (partner.employeeFieldConfig.requireUsername) exampleRow2.push('jsmith');
    if (partner.employeeFieldConfig.requireDateOfBirth) exampleRow2.push('1985-05-22');
    if (partner.employeeFieldConfig.requireStartDate) exampleRow2.push('2019-06-15');
    exampleRow2.push('');
    csv += exampleRow2.join(',') + '\n';
    
    var blob = new Blob([csv], { type: 'text/csv' });
    var url = window.URL.createObjectURL(blob);
    var a = document.createElement('a');
    a.href = url;
    a.download = 'employee_import_template.csv';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
    
    Helpers.showAlert('Template downloaded successfully', 'success', '#download-template-btn');
  },
  
  processFile: function(file, partner) {
    var self = this;
    
    if (!this.selectedGroupId) {
      Helpers.showAlert('Please select a user group first', 'danger', '#select-group');
      return;
    }
    
    var reader = new FileReader();
    
    reader.onload = function(e) {
      try {
        var text = e.target.result;
        var lines = text.split('\n').filter(function(line) { return line.trim(); });
        
        if (lines.length < 2) {
          Helpers.showAlert('CSV file is empty or invalid', 'danger', '#file-input');
          return;
        }
        
        // Skip header row
        var dataLines = lines.slice(1);
        var successCount = 0;
        var errorCount = 0;
        var errors = [];
        
        $('#import-progress').show();
        $('#import-results').hide();
        
        var validEmployees = dataLines.map(function(line, index) {
          var values = line.split(',').map(function(s) { return s.trim(); });
          
          // Parse values based on field configuration
          var colIndex = 0;
          var firstName = values[colIndex++];
          var lastName = values[colIndex++];
          var employeeId = partner.employeeFieldConfig.requireEmployeeId ? values[colIndex++] : undefined;
          var username = partner.employeeFieldConfig.requireUsername ? values[colIndex++] : undefined;
          var dateOfBirth = partner.employeeFieldConfig.requireDateOfBirth ? values[colIndex++] : undefined;
          var startDate = partner.employeeFieldConfig.requireStartDate ? values[colIndex++] : undefined;
          var notes = values[colIndex] || '';
          
          // Validate required fields
          if (!firstName || !lastName) {
            errorCount++;
            errors.push('Row ' + (index + 2) + ': Missing first or last name');
            return;
          }
          
          if (partner.employeeFieldConfig.requireEmployeeId && !employeeId) {
            errorCount++;
            errors.push('Row ' + (index + 2) + ': Missing Employee ID for ' + firstName + ' ' + lastName);
            return;
          }
          
          if (partner.employeeFieldConfig.requireUsername && !username) {
            errorCount++;
            errors.push('Row ' + (index + 2) + ': Missing Username for ' + firstName + ' ' + lastName);
            return;
          }
          
          if (partner.employeeFieldConfig.requireDateOfBirth && !dateOfBirth) {
            errorCount++;
            errors.push('Row ' + (index + 2) + ': Missing Date of Birth for ' + firstName + ' ' + lastName);
            return;
          }
          
          if (partner.employeeFieldConfig.requireStartDate && !startDate) {
            errorCount++;
            errors.push('Row ' + (index + 2) + ': Missing Start Date for ' + firstName + ' ' + lastName);
            return;
          }
          
          // Get vouchers for this group
          var groupVouchers = partner.vouchers.filter(function(v) {
            return v.userGroupIds && v.userGroupIds.indexOf(self.selectedGroupId) > -1;
          });
          
          // Calculate total voucher balance
          var totalBalance = groupVouchers.reduce(function(sum, v) { return sum + v.defaultAmount; }, 0);
          
          // Initialize voucher balances
          var voucherBalances = groupVouchers.map(function(v) {
            return {
              voucherId: v.id,
              remainingAmount: v.defaultAmount
            };
          });
          
          // Get expiry date from vouchers
          var voucherExpiry = groupVouchers.length > 0 ? groupVouchers[0].endDate : '';
          
          var employeeData = {
            id: Helpers.generateId(),
            firstName: firstName,
            lastName: lastName,
            name: firstName + ' ' + lastName,
            groupId: self.selectedGroupId,
            voucherExpiry: voucherExpiry,
            voucherStatus: 'active',
            remainingBalance: totalBalance,
            voucherBalances: voucherBalances,
            notes: notes
          };
          
          // Add optional fields
          if (employeeId) employeeData.employeeId = employeeId;
          if (username) employeeData.username = username;
          if (dateOfBirth) employeeData.dateOfBirth = dateOfBirth;
          if (startDate) employeeData.startDate = startDate;
          
          successCount++;
          
          // Update progress
          var progress = Math.round(((index + 1) / dataLines.length) * 100);
          $('#import-progress-bar').css('width', progress + '%');
          $('#import-progress-text').text(progress + '%');
          
          return employeeData;
        }).filter(function(emp) { return emp !== undefined; });
        
        // Get current employees and combine with new ones
        var allEmployees = partner.employees.concat(validEmployees);
        
        // Update employee count in group
        var updatedGroups = partner.groups.map(function(g) {
          if (g.id === self.selectedGroupId) {
            var count = allEmployees.filter(function(e) { return e.groupId === g.id; }).length;
            return Object.assign({}, g, { employeeCount: count });
          }
          return g;
        });
        
        AppState.updatePartner(partner.id, {
          employees: allEmployees,
          employeeCount: allEmployees.length,
          groups: updatedGroups
        });
        
        // Show results
        $('#import-progress').hide();
        var resultHtml = '';
        
        if (successCount > 0) {
          resultHtml += '<p class="text-success"><strong>' + successCount + ' employee(s) imported successfully!</strong></p>';
        }
        
        if (errorCount > 0) {
          resultHtml += '<p class="text-danger"><strong>' + errorCount + ' employee(s) failed to import:</strong></p>';
          resultHtml += '<ul class="text-danger">';
          errors.forEach(function(err) {
            resultHtml += '<li>' + err + '</li>';
          });
          resultHtml += '</ul>';
        }
        
        $('#import-results').removeClass('alert-success alert-danger');
        $('#import-results').addClass(errorCount > 0 ? 'alert-warning' : 'alert-success');
        $('#import-results').html(resultHtml).show();
        
        // Refresh the employee list
        if (successCount > 0) {
          setTimeout(function() {
            $('#bulk-import-modal').modal('hide');
            PartnerDetailComponent.renderTabContent('employees');
            Helpers.showAlert(successCount + ' employee(s) imported successfully', 'success');
          }, 2000);
        }
        
      } catch (error) {
        console.error('Error processing file:', error);
        Helpers.showAlert('Error processing file. Please check the format.', 'danger');
      }
    };
    
    reader.readAsText(file);
  }
};