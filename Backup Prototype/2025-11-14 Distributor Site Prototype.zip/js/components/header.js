// Header Component

var HeaderComponent = {
  attachEvents: function() {
    // Logo click - navigate to dashboard (distributors only)
    $(document).on('click', '#header-logo', function(e) {
      e.preventDefault();
      var isDistributor = AppState.currentUser && AppState.currentUser.role === 'Distributor';
      if (isDistributor) {
        window.location.href = 'dashboard.html';
      }
    });
    
    // Logout
    $(document).on('click', '#logout-btn', function(e) {
      e.preventDefault();
      if (confirm('Are you sure you want to logout?')) {
        AppState.logout();
        window.location.href = 'login.html';
      }
    });
  }
};
