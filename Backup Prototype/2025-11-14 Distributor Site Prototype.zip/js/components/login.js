// Login Component

var LoginComponent = {
  init: function() {
    this.render();
    this.attachEvents();
  },
  
  render: function() {
    $('#app-container').html(Templates.loginPage());
  },
  
  attachEvents: function() {
    var self = this;
    
    // Login form submission
    $(document).on('submit', '#login-form', function(e) {
      e.preventDefault();
      self.handleLogin(e);
    });
    
    // Forgot password link
    $(document).on('click', '#forgot-password-link', function(e) {
      e.preventDefault();
      self.showForgotPasswordModal();
    });
    
    // Forgot password form submission
    $(document).on('submit', '#forgot-password-form', function(e) {
      e.preventDefault();
      self.handleForgotPassword();
    });
  },
  
  handleLogin: function(e) {
    e.preventDefault();
    
    var email = $('#login-email').val();
    var password = $('#login-password').val();
    
    // Use AppState.login() which properly saves to localStorage
    var success = AppState.login(email, password);
    
    if (success) {
      var user = AppState.currentUser;
      
      // Navigate based on user role
      if (user.role === 'Distributor') {
        window.location.href = 'dashboard.html';
      } else if (user.role === 'Partner') {
        // Navigate to their specific partner detail page
        if (user.partnerId) {
          window.location.href = 'partner-detail.html?partnerId=' + user.partnerId;
        } else {
          Helpers.showAlert('Partner account configuration error', 'danger', e.target);
        }
      }
    } else {
      // Login failed
      Helpers.showAlert('Invalid email or password', 'danger', e.target);
    }
  },
  
  showForgotPasswordModal: function() {
    // Add modal to page if not exists
    if ($('#forgot-password-modal').length === 0) {
      $('body').append(Templates.forgotPasswordModal());
    }
    
    $('#forgot-password-modal').modal('show');
  },
  
  handleForgotPassword: function() {
    var email = $('#reset-email').val();
    
    // Simulate sending reset email
    $('#forgot-password-modal').modal('hide');
    Helpers.showAlert('Password reset link sent to ' + email, 'success');
    
    // Clear form
    $('#reset-email').val('');
  }
};