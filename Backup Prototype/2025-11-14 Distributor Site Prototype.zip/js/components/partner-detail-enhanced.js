// Enhanced Partner Detail Component Event Handlers

// Add these event handlers to partner-detail.js attachEvents method

// Export employees
$(document).on('click', '#export-employees-btn', function() {
  var partner = AppState.getPartnerById(PartnerDetailComponent.partnerId);
  EmployeeTableEnhanced.exportToCSV(partner.employees, partner.groups, partner);
});

// Select all employees
$(document).on('change', '#select-all-employees', function() {
  var partner = AppState.getPartnerById(PartnerDetailComponent.partnerId);
  EmployeeTableEnhanced.toggleSelectAll(partner.employees);
});

// Select individual employee
$(document).on('change', '.employee-checkbox', function() {
  var employeeId = $(this).data('employee-id');
  EmployeeTableEnhanced.toggleSelection(employeeId);
});

// Clear selection
$(document).on('click', '#clear-selection-btn', function() {
  EmployeeTableEnhanced.clearSelection();
});

// Bulk change group
$(document).on('click', '#bulk-change-group-btn', function() {
  var partner = AppState.getPartnerById(PartnerDetailComponent.partnerId);
  var selectedIds = EmployeeTableEnhanced.selectedEmployees;
  
  EmployeeTableEnhanced.showBulkGroupChangeModal(selectedIds, partner.groups, function(targetGroupId) {
    // Update employees
    var updatedEmployees = partner.employees.map(function(emp) {
      if (selectedIds.indexOf(emp.id) > -1) {
        // Get vouchers for new group
        var groupVouchers = partner.vouchers.filter(function(v) {
          return v.userGroupIds && v.userGroupIds.indexOf(targetGroupId) > -1;
        });
        
        var totalBalance = groupVouchers.reduce(function(sum, v) { return sum + v.defaultAmount; }, 0);
        var voucherBalances = groupVouchers.map(function(v) {
          return { voucherId: v.id, remainingAmount: v.defaultAmount };
        });
        var voucherExpiry = groupVouchers.length > 0 ? groupVouchers[0].endDate : '';
        
        return Object.assign({}, emp, {
          groupId: targetGroupId,
          voucherBalances: voucherBalances,
          remainingBalance: totalBalance,
          voucherExpiry: voucherExpiry
        });
      }
      return emp;
    });
    
    // Update employee counts in groups
    var updatedGroups = partner.groups.map(function(group) {
      var count = updatedEmployees.filter(function(e) { return e.groupId === group.id; }).length;
      return Object.assign({}, group, { employeeCount: count });
    });
    
    AppState.updatePartner(PartnerDetailComponent.partnerId, {
      employees: updatedEmployees,
      groups: updatedGroups
    });
    
    EmployeeTableEnhanced.clearSelection();
    PartnerDetailComponent.renderTabContent('employees');
    Helpers.showAlert(selectedIds.length + ' employee(s) moved successfully', 'success');
  });
});

// Sort column
$(document).on('click', '.sortable-column', function() {
  var column = $(this).data('column');
  
  // Just set the sort column and direction, don't sort here
  // The template will handle the actual sorting
  EmployeeTableEnhanced.setSortColumn(column);
  
  // Re-render tab
  PartnerDetailComponent.renderTabContent('employees');
});
