// Partner Detail Component

var PartnerDetailComponent = {
  partnerId: null,
  currentTab: 'employees',
  selectedGroupId: null,
  
  init: function(partnerId, tab) {
    this.partnerId = partnerId;
    this.currentTab = tab || 'employees';
    this.selectedGroupId = null;
    EmployeeTableEnhanced.init(); // Initialize enhanced table features
    this.render();
    this.attachEvents();
  },
  
  render: function() {
    $('#app-container').html(Templates.partnerDetailPage(this.partnerId));
    this.updateActiveNav('dashboard');
    this.renderTabContent(this.currentTab);
  },
  
  attachEvents: function() {
    var self = this;
    
    // Back button
    $(document).on('click', '#back-to-dashboard', function() {
      App.navigate('dashboard');
    });
    
    // Tab switching
    $(document).on('click', '.nav-tabs a[data-tab]', function(e) {
      e.preventDefault();
      var tab = $(this).data('tab');
      self.switchTab(tab);
    });
    
    // Edit partner button
    $(document).on('click', '#edit-partner-btn', function() {
      self.showEditPartnerModal();
    });
    
    // Add employee button
    $(document).on('click', '#add-employee-btn', function() {
      self.showAddEmployeeModal();
    });
    
    // Create group button
    $(document).on('click', '#create-group-btn', function() {
      self.showCreateGroupModal();
    });
    
    // Edit group button
    $(document).on('click', '.edit-group-btn', function(e) {
      e.stopPropagation(); // Prevent triggering the group card click
      var groupId = $(this).data('group-id');
      // Navigate to full-page user group form
      App.navigate('partner-group-form', { partnerId: self.partnerId, groupId: groupId });
    });
    
    // Delete group button
    $(document).on('click', '.delete-group-btn', function(e) {
      e.stopPropagation(); // Prevent triggering the group card click
      var groupId = $(this).data('group-id');
      self.deleteGroup(groupId);
    });
    
    // Toggle products list
    $(document).on('click', '.toggle-products-list', function(e) {
      e.stopPropagation(); // Prevent triggering the group card click
      var groupId = $(this).data('group-id');
      var $productsList = $('.all-products-list[data-group-id="' + groupId + '"]');
      var $toggleLink = $(this);
      var $chevron = $toggleLink.find('.glyphicon');
      
      if ($productsList.is(':visible')) {
        $productsList.slideUp(200);
        $chevron.removeClass('glyphicon-chevron-up').addClass('glyphicon-chevron-down');
        $toggleLink.html('<span class="glyphicon glyphicon-chevron-down"></span> View all products');
      } else {
        $productsList.slideDown(200);
        $chevron.removeClass('glyphicon-chevron-down').addClass('glyphicon-chevron-up');
        $toggleLink.html('<span class="glyphicon glyphicon-chevron-up"></span> Hide products');
      }
    });
    
    // Select group
    $(document).on('click', '.user-group-card', function() {
      var groupId = $(this).data('group-id');
      self.selectGroup(groupId);
    });
    
    // Create voucher button
    $(document).on('click', '#create-voucher-btn', function() {
      self.showCreateVoucherModal();
    });
    
    // Edit voucher button
    $(document).on('click', '.edit-voucher-btn', function() {
      var voucherId = $(this).data('voucher-id');
      self.showEditVoucherModal(voucherId);
    });
    
    // Delete voucher button
    $(document).on('click', '.delete-voucher-btn', function() {
      var voucherId = $(this).data('voucher-id');
      self.deleteVoucher(voucherId);
    });
    
    // Delete employee button
    $(document).on('click', '.delete-employee-btn', function() {
      var employeeId = $(this).data('employee-id');
      self.deleteEmployee(employeeId);
    });
    
    // Toggle employee status button
    $(document).on('click', '.toggle-employee-status-btn', function() {
      var employeeId = $(this).data('employee-id');
      self.toggleEmployeeStatus(employeeId);
    });
    
    // Edit employee button
    $(document).on('click', '.edit-employee-btn', function() {
      var employeeId = $(this).data('employee-id');
      self.showEditEmployeeModal(employeeId);
    });
    
    // Bulk import button
    $(document).on('click', '#bulk-import-btn', function() {
      EmployeeBulkImport.show(self.partnerId);
    });
    
    // Toggle product visibility
    $(document).on('change', '.product-visibility-toggle', function() {
      var productId = $(this).data('product-id');
      var visible = $(this).prop('checked');
      self.updateProductVisibility(productId, visible);
    });
  },
  
  updateActiveNav: function(view) {
    $('.nav-link').removeClass('active');
    $('.nav-link[data-nav="' + view + '"]').addClass('active');
  },
  
  switchTab: function(tabName) {
    this.currentTab = tabName;
    
    // Update active tab
    $('.nav-tabs li').removeClass('active');
    $('.nav-tabs a[data-tab="' + tabName + '"]').parent().addClass('active');
    
    // Render tab content
    this.renderTabContent(tabName);
  },
  
  renderTabContent: function(tabName) {
    var partner = AppState.getPartnerById(this.partnerId);
    if (!partner) return;
    
    var isDistributor = AppState.currentUser && AppState.currentUser.role === 'Distributor';
    var content = '';
    
    switch(tabName) {
      case 'employees':
        content = this.renderEmployeesTab(partner);
        break;
      case 'groups':
        content = this.renderGroupsTab(partner);
        break;
      case 'vouchers':
        content = this.renderVouchersTab(partner);
        break;
      case 'pricing':
        // Only allow distributors to see pricing
        if (isDistributor) {
          content = this.renderPricingTab(partner);
        } else {
          content = '<div class="alert alert-warning">Access denied. Only distributor users can view pricing information.</div>';
        }
        break;
    }
    
    $('#partner-tab-content').html(content);
  },
  
  renderEmployeesTab: function(partner) {
    // Use enhanced template if available
    if (typeof Templates.renderEmployeesTabEnhanced === 'function') {
      return Templates.renderEmployeesTabEnhanced(partner);
    }
    
    // Fallback to basic template
    var self = this;
    var html = '<div class="row">';
    
    // Full width - Employees only
    html += '<div class="col-md-12">' +
      '<div class="mb-4">' +
      '<button class="btn btn-primary" id="add-employee-btn">' +
      '<span class="glyphicon glyphicon-plus"></span> Add Employee' +
      '</button> ' +
      '<button class="btn btn-primary" id="bulk-import-btn">' +
      '<span class="glyphicon glyphicon-import"></span> Bulk Import' +
      '</button>' +
      '</div>';
    
    if (partner.employees.length > 0) {
      html += '<div class="table-responsive">' +
        '<table class="table table-hover">' +
        '<thead>' +
        '<tr>' +
        '<th>Name</th>' +
        (partner.employeeFieldConfig.requireEmployeeId ? '<th>Employee ID</th>' : '') +
        '<th>Group</th>' +
        '<th>Status</th>' +
        '<th>Notes</th>' +
        '<th>Actions</th>' +
        '</tr>' +
        '</thead>' +
        '<tbody>';
      
      partner.employees.forEach(function(emp) {
        var group = partner.groups.find(function(g) { return g.id === emp.groupId; });
        var isActive = emp.status !== 'inactive';
        html += '<tr' + (!isActive ? ' class="text-muted"' : '') + '>' +
          '<td>' + Helpers.escapeHtml(emp.name) + '</td>' +
          (partner.employeeFieldConfig.requireEmployeeId ? '<td>' + Helpers.escapeHtml(emp.employeeId || '') + '</td>' : '') +
          '<td>' + (group ? Helpers.escapeHtml(group.name) : '-') + '</td>' +
          '<td><span class="label label-' + (isActive ? 'success' : 'default') + '">' + (isActive ? 'Active' : 'Inactive') + '</span></td>' +
          '<td>' + (emp.notes ? Helpers.escapeHtml(emp.notes) : '-') + '</td>' +
          '<td>' +
          '<button class="btn btn-xs btn-default edit-employee-btn" data-employee-id="' + emp.id + '">' +
          '<span class="glyphicon glyphicon-pencil"></span>' +
          '</button> ' +
          '<button class="btn btn-xs btn-' + (isActive ? 'warning' : 'success') + ' toggle-employee-status-btn" data-employee-id="' + emp.id + '">' +
          '<span class="glyphicon glyphicon-' + (isActive ? 'ban-circle' : 'ok-circle') + '"></span> ' +
          (isActive ? 'Deactivate' : 'Activate') +
          '</button>' +
          '</td>' +
          '</tr>';
      });
      
      html += '</tbody></table></div>';
    } else {
      html += '<div class="alert alert-info">No employees added yet. Click "Add Employee" to get started.</div>';
    }
    
    html += '</div></div>';
    
    return html;
  },
  
  renderGroupsTab: function(partner) {
    var self = this;
    var isDistributor = AppState.currentUser && AppState.currentUser.role === 'Distributor';
    
    var html = '<div class="row">' +
      '<div class="col-md-12">';
    
    // Help Section - Conditional based on whether employees exist
    if (partner.employees.length === 0) {
      // No employees - show "User Groups Locked" message
      html += '<div class="alert alert-info" style="background-color: #e3f2fd; border-color: #90caf9; margin-bottom: 20px;">' +
        '<div style="display: flex; align-items: start; gap: 15px;">' +
        '<div style="background-color: #bbdefb; padding: 10px; border-radius: 4px; flex-shrink: 0;">' +
        '<span class="glyphicon glyphicon-info-sign" style="font-size: 20px; color: #1976d2;"></span>' +
        '</div>' +
        '<div style="flex: 1;">' +
        '<h4 style="margin: 0 0 8px 0; color: #0d47a1; font-size: 14px; font-weight: 600;">User Groups Locked</h4>' +
        '<p style="margin: 0 0 12px 0; color: #1565c0; font-size: 13px; line-height: 1.5;">' +
        'Add employees first, then you can create user groups to organize them' +
        '</p>' +
        '<button class="btn btn-sm btn-primary" onclick="PartnerDetailComponent.switchTab(\'employees\')">' +
        'Go to Employees' +
        '</button>' +
        '</div>' +
        '</div>' +
        '</div>';
    } else {
      // Has employees - show "How User Groups Work" message
      html += '<div class="alert alert-info" style="background-color: #e3f2fd; border-color: #90caf9; margin-bottom: 20px;">' +
        '<div style="display: flex; align-items: start; gap: 15px;">' +
        '<div style="background-color: #bbdefb; padding: 10px; border-radius: 4px; flex-shrink: 0;">' +
        '<span class="glyphicon glyphicon-info-sign" style="font-size: 20px; color: #1976d2;"></span>' +
        '</div>' +
        '<div style="flex: 1;">' +
        '<h4 style="margin: 0 0 8px 0; color: #0d47a1; font-size: 14px; font-weight: 600;">How User Groups Work</h4>' +
        '<p style="margin: 0; color: #1565c0; font-size: 13px; line-height: 1.5;">' +
        'User groups allow you to organize employees and configure settings for multiple employees at once. ' +
        'Each group can have its own product visibility, vouchers, and payment options. ' +
        'The "Default Group" is automatically created for all new employees, and you can create additional groups based on department, location, or any other criteria.' +
        '</p>' +
        '</div>' +
        '</div>' +
        '</div>';
    }
    
    html += '<div class="mb-4">' +
      '<button class="btn btn-primary" id="create-group-btn"' + 
      (partner.employees.length === 0 ? ' disabled title="Add employees first"' : '') + '>' +
      '<span class="glyphicon glyphicon-plus"></span> Create Group' +
      '</button>' +
      '</div>' +
      '<div id="groups-list">';
    
    partner.groups.forEach(function(group) {
      var isSelected = self.selectedGroupId === group.id;
      var productIds = group.productIds || [];
      var productCount = productIds.length;
      
      // Get product names for display
      var assignedProducts = [];
      productIds.forEach(function(productId) {
        var product = AppState.products.find(function(p) { return p.id === productId; });
        if (product) {
          assignedProducts.push(product);
        }
      });
      
      // Show first 3 products, then "and X more" if there are more
      var maxDisplayProducts = 3;
      var displayProducts = assignedProducts.slice(0, maxDisplayProducts);
      var remainingCount = assignedProducts.length - maxDisplayProducts;
      
      html += '<div class="user-group-card ' + (isSelected ? 'selected' : '') + '" data-group-id="' + group.id + '">' +
        '<div class="group-header">' +
        '<h4>' + Helpers.escapeHtml(group.name) + '</h4>' +
        '<div class="btn-group btn-group-xs">' +
        '<button class="btn btn-default edit-group-btn" data-group-id="' + group.id + '" style="padding: 5px 10px; background-color: transparent; border-color: transparent; color: #6b7280;" title="Edit Group">' +
        '<span class="glyphicon glyphicon-pencil"></span>' +
        '</button>' +
        (group.name !== 'Default Group' ? 
          '<button class="btn btn-default delete-group-btn" data-group-id="' + group.id + '" style="padding: 5px 10px; background-color: transparent; border-color: transparent; color: #dc2626;" title="Delete Group">' +
          '<span class="glyphicon glyphicon-trash"></span>' +
          '</button>' : 
          '<span class="text-muted" style="font-size: 11px; font-style: italic; padding: 5px 10px;">Cannot delete</span>') +
        '</div>' +
        '</div>' +
        '<div class="text-muted mb-2">' +
        '<span class="glyphicon glyphicon-user"></span> ' + group.employeeCount + ' employees' +
        '</div>' +
        (group.department ? '<div class="text-muted mb-2"><strong>Dept:</strong> ' + Helpers.escapeHtml(group.department) + '</div>' : '') +
        (group.location ? '<div class="text-muted mb-2"><strong>Location:</strong> ' + Helpers.escapeHtml(group.location) + '</div>' : '') +
        '<div class="mb-2" style="margin-top: 10px; padding-top: 10px; border-top: 1px solid #e0e0e0;">' +
        '<div style="display: flex; align-items: center; margin-bottom: 8px;">' +
        '<span class="glyphicon glyphicon-shopping-cart" style="color: #666; margin-right: 5px;"></span>' +
        '<strong style="font-size: 13px; color: #333;">Assigned Products (' + productCount + ')</strong>' +
        '</div>';
      
      if (productCount === 0) {
        html += '<div class="text-muted" style="font-size: 12px; font-style: italic;">No products assigned</div>';
      } else {
        html += '<div style="display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 5px;">';
        displayProducts.forEach(function(product) {
          html += '<span class="label label-default" style="font-size: 11px; font-weight: normal;">' + Helpers.escapeHtml(product.name) + '</span>';
        });
        if (remainingCount > 0) {
          html += '<span class="label label-info" style="font-size: 11px; font-weight: normal;">and ' + remainingCount + ' more</span>';
        }
        html += '</div>';
        
        // Add expandable section for all products if there are more than maxDisplayProducts
        if (assignedProducts.length > maxDisplayProducts) {
          html += '<div style="margin-top: 8px;">' +
            '<a href="#" class="toggle-products-list" data-group-id="' + group.id + '" style="font-size: 11px; color: #1976d2; text-decoration: none;">' +
            '<span class="glyphicon glyphicon-chevron-down"></span> View all products' +
            '</a>' +
            '<div class="all-products-list" data-group-id="' + group.id + '" style="display: none; margin-top: 8px; padding: 10px; background-color: #f9f9f9; border-radius: 4px; max-height: 200px; overflow-y: auto;">';
          assignedProducts.forEach(function(product) {
            html += '<div style="padding: 4px 0; font-size: 12px; color: #666;">' +
              '<span class="glyphicon glyphicon-ok" style="color: #5cb85c; margin-right: 5px; font-size: 10px;"></span>' +
              Helpers.escapeHtml(product.name) +
              '</div>';
          });
          html += '</div></div>';
        }
      }
      
      html += '</div></div>';
    });
    
    html += '</div></div>';
    
    return html;
  },
  
  renderVouchersTab: function(partner) {
    var isDistributor = AppState.currentUser && AppState.currentUser.role === 'Distributor';
    var hasGroupsWithProducts = partner.groups.some(function(g) {
      return (g.productIds || []).length > 0;
    });
    var hasEmployees = partner.groups.some(function(g) {
      return g.employeeCount > 0;
    });
    
    var html = '<div class="row">' +
      '<div class="col-md-12">';
    
    // Help Section - Only visible for distributors
    if (isDistributor) {
      if (!hasEmployees) {
        // No employees
        html += '<div class="alert alert-info" style="background-color: #e3f2fd; border-color: #90caf9; margin-bottom: 20px;">' +
          '<div style="display: flex; align-items: start; gap: 15px;">' +
          '<div style="background-color: #bbdefb; padding: 10px; border-radius: 4px; flex-shrink: 0;">' +
          '<span class="glyphicon glyphicon-info-sign" style="font-size: 20px; color: #1976d2;"></span>' +
          '</div>' +
          '<div style="flex: 1;">' +
          '<h4 style="margin: 0 0 8px 0; color: #0d47a1; font-size: 14px; font-weight: 600;">Add Employees First</h4>' +
          '<p style="margin: 0 0 12px 0; color: #1565c0; font-size: 13px; line-height: 1.5;">' +
          'Before creating vouchers, you need to add employees in the Employees & Groups section. Once employees are added, you can create user groups and assign product visibility to enable voucher creation.' +
          '</p>' +
          '<button class="btn btn-sm btn-primary" onclick="PartnerDetailComponent.switchTab(\'employees\')">' +
          'Go to Employees & Groups' +
          '</button>' +
          '</div>' +
          '</div>' +
          '</div>';
      } else if (!hasGroupsWithProducts) {
        // Has employees but no groups with products
        html += '<div class="alert alert-info" style="background-color: #e3f2fd; border-color: #90caf9; margin-bottom: 20px;">' +
          '<div style="display: flex; align-items: start; gap: 15px;">' +
          '<div style="background-color: #bbdefb; padding: 10px; border-radius: 4px; flex-shrink: 0;">' +
          '<span class="glyphicon glyphicon-info-sign" style="font-size: 20px; color: #1976d2;"></span>' +
          '</div>' +
          '<div style="flex: 1;">' +
          '<h4 style="margin: 0 0 8px 0; color: #0d47a1; font-size: 14px; font-weight: 600;">Assign Products to User Groups</h4>' +
          '<p style="margin: 0 0 12px 0; color: #1565c0; font-size: 13px; line-height: 1.5;">' +
          'Before creating vouchers, you need to assign product visibility to at least one user group. Go to the Employees & Groups section, edit a user group, and configure which products that group can access.' +
          '</p>' +
          '<button class="btn btn-sm btn-primary" onclick="PartnerDetailComponent.switchTab(\'groups\')">' +
          'Go to User Groups' +
          '</button>' +
          '</div>' +
          '</div>' +
          '</div>';
      } else {
        // Ready to create vouchers
        html += '<div class="alert alert-info" style="background-color: #e3f2fd; border-color: #90caf9; margin-bottom: 20px;">' +
          '<div style="display: flex; align-items: start; gap: 15px;">' +
          '<div style="background-color: #bbdefb; padding: 10px; border-radius: 4px; flex-shrink: 0;">' +
          '<span class="glyphicon glyphicon-info-sign" style="font-size: 20px; color: #1976d2;"></span>' +
          '</div>' +
          '<div style="flex: 1;">' +
          '<h4 style="margin: 0 0 8px 0; color: #0d47a1; font-size: 14px; font-weight: 600;">Create Vouchers for User Groups</h4>' +
          '<p style="margin: 0; color: #1565c0; font-size: 13px; line-height: 1.5;">' +
          'Vouchers define the allowance amounts, validity periods, and qualified products that user groups can access. Each voucher is assigned to a single user group and can be configured with auto-renewal and rollover settings.' +
          '</p>' +
          '</div>' +
          '</div>' +
          '</div>';
      }
    }
    
    html += '<div class="mb-4">' +
      (isDistributor ? 
        '<button class="btn btn-primary" id="create-voucher-btn"' +
        (!hasGroupsWithProducts ? ' disabled title="Add user groups with products first"' : '') + '>' +
        '<span class="glyphicon glyphicon-plus"></span> Create Voucher' +
        '</button>' : '') +
      '</div>';
    
    if (partner.vouchers.length > 0) {
      html += '<div class="row">';
      
      partner.vouchers.forEach(function(voucher) {
        // Get assigned user group
        var assignedGroup = null;
        if (voucher.userGroupIds && voucher.userGroupIds.length > 0) {
          assignedGroup = partner.groups.find(function(g) {
            return g.id === voucher.userGroupIds[0];
          });
        }
        
        html += '<div class="col-md-6 mb-4">' +
          '<div class="panel panel-default">' +
          '<div class="panel-heading">' +
          '<h3 class="panel-title">' +
          Helpers.escapeHtml(voucher.name) +
          (isDistributor ? 
            '<span class="pull-right">' +
            '<button class="btn btn-xs btn-default edit-voucher-btn" data-voucher-id="' + voucher.id + '" style="padding: 5px 10px; background-color: transparent; border-color: transparent; color: #6b7280;" title="Edit Voucher">' +
            '<span class="glyphicon glyphicon-pencil"></span>' +
            '</button> ' +
            '<button class="btn btn-xs btn-default delete-voucher-btn" data-voucher-id="' + voucher.id + '" style="padding: 5px 10px; background-color: transparent; border-color: transparent; color: #dc2626;" title="Delete Voucher">' +
            '<span class="glyphicon glyphicon-trash"></span>' +
            '</button>' +
            '</span>' : '') +
          '</h3>' +
          '</div>' +
          '<div class="panel-body">' +
          '<p class="text-muted">' + Helpers.escapeHtml(voucher.description) + '</p>';
        
        // Show assigned user group
        if (assignedGroup) {
          html += '<div class="well well-sm" style="background-color: #e8f4f8; border-color: #bee5eb;">' +
            '<p class="mb-1"><strong>Assigned to:</strong></p>' +
            '<span class="label label-info">' +
            Helpers.escapeHtml(assignedGroup.name) + ' (' + assignedGroup.employeeCount + ' employees)' +
            '</span>' +
            '</div>';
        }
        
        html += '<div class="row">' +
          '<div class="col-xs-6">' +
          '<strong>Amount:</strong><br>' +
          '<span class="text-primary">' + Helpers.formatCurrency(voucher.defaultAmount) + '</span>' +
          '</div>' +
          '<div class="col-xs-6">' +
          '<strong>Status:</strong><br>' +
          '<span class="label ' + (voucher.isActive ? 'label-success' : 'label-default') + '">' +
          (voucher.isActive ? 'Active' : 'Inactive') +
          '</span>' +
          '</div>' +
          '</div>' +
          '<hr>' +
          '<div class="text-muted">' +
          '<small>' +
          '<span class="glyphicon glyphicon-calendar"></span> ' +
          Helpers.formatDate(voucher.startDate) + ' - ' + Helpers.formatDate(voucher.endDate) +
          '</small><br>' +
          '<small>' +
          (voucher.autoRenewal ? '<span class="glyphicon glyphicon-repeat text-success"></span> Auto-renewal' : '') +
          (voucher.rolloverEnabled ? ' <span class="glyphicon glyphicon-transfer text-info"></span> Rollover' : '') +
          '</small>' +
          '</div>' +
          '</div>' +
          '</div>' +
          '</div>';
      });
      
      html += '</div>';
    } else {
      html += '<div class="alert alert-info">No voucher programs configured yet.</div>';
    }
    
    html += '</div></div>';
    
    return html;
  },
  
  renderPricingTab: function(partner) {
    var self = this;
    var html = '<div class="row">' +
      '<div class="col-md-12">';
    
    // Help Section - Partner-Specific Pricing
    html += '<div class="alert alert-info" style="background-color: #e3f2fd; border-color: #90caf9; margin-bottom: 20px;">' +
      '<div style="display: flex; align-items: start; gap: 15px;">' +
      '<div style="background-color: #bbdefb; padding: 10px; border-radius: 4px; flex-shrink: 0;">' +
      '<span class="glyphicon glyphicon-usd" style="font-size: 20px; color: #1976d2;"></span>' +
      '</div>' +
      '<div style="flex: 1;">' +
      '<h4 style="margin: 0 0 8px 0; color: #0d47a1; font-size: 14px; font-weight: 600;">Customize Partner-Specific Pricing</h4>' +
      '<p style="margin: 0; color: #1565c0; font-size: 13px; line-height: 1.5;">' +
      'Set custom prices for individual products that apply only to ' + Helpers.escapeHtml(partner.name) + '. ' +
      'Base prices show standard pricing, while partner prices show your custom overrides. ' +
      'Product visibility is controlled through user groups in the Employees & Groups section.' +
      '</p>' +
      '</div>' +
      '</div>' +
      '</div>';
    
    html += '<h4>Partner-Specific Pricing</h4>' +
      '<p class="text-muted mb-4">Set custom prices for products specific to this partner. Leave blank to use the default price.</p>';
    
    // Search and Filter
    html += '<div class="row" style="margin-bottom: 20px;">' +
      '<div class="col-md-8">' +
      '<div class="input-group">' +
      '<span class="input-group-addon"><span class="glyphicon glyphicon-search"></span></span>' +
      '<input type="text" class="form-control" id="pricing-search" placeholder="Search by product name, category, or SKU...">' +
      '</div>' +
      '</div>' +
      '<div class="col-md-4">' +
      '<select class="form-control" id="pricing-category-filter">' +
      '<option value="all">All Categories</option>';
    
    // Get unique categories
    var categories = [];
    var categorySet = {};
    AppState.products.forEach(function(product) {
      if (!categorySet[product.category]) {
        categorySet[product.category] = true;
        categories.push(product.category);
      }
    });
    
    categories.forEach(function(category) {
      html += '<option value="' + Helpers.escapeHtml(category) + '">' + Helpers.escapeHtml(category) + '</option>';
    });
    
    html += '</select>' +
      '</div>' +
      '</div>';
    
    html += '<div class="table-responsive">' +
      '<table class="table table-hover" id="pricing-table">' +
      '<thead>' +
      '<tr>' +
      '<th>Product</th>' +
      '<th>SureWerx SKU</th>' +
      '<th>Category</th>' +
      '<th>Base Price</th>' +
      '<th>Partner Price</th>' +
      '<th>Actions</th>' +
      '</tr>' +
      '</thead>' +
      '<tbody id="pricing-table-body">';
    
    AppState.products.forEach(function(product) {
      var partnerProduct = partner.availableProducts.find(function(p) { return p.id === product.id; });
      var customPrice = partnerProduct && partnerProduct.customPrice ? partnerProduct.customPrice : '';
      var hasCustomPrice = partnerProduct && partnerProduct.customPrice;
      var effectivePrice = hasCustomPrice ? customPrice : product.price;
      
      html += '<tr class=\"pricing-row\" ' +
        'data-product-name=\"' + Helpers.escapeHtml(product.name).toLowerCase() + '\" ' +
        'data-category=\"' + Helpers.escapeHtml(product.category).toLowerCase() + '\" ' +
        'data-sku=\"' + Helpers.escapeHtml(product.surewerxSku).toLowerCase() + '\" ' +
        'data-product-id=\"' + product.id + '\">' +
        '<td>' + Helpers.escapeHtml(product.name) + '</td>' +
        '<td><span class=\"text-muted\" style=\"font-family: monospace; font-size: 12px;\">' + Helpers.escapeHtml(product.surewerxSku) + '</span></td>' +
        '<td><span class=\"label label-default\">' + Helpers.escapeHtml(product.category) + '</span></td>' +
        '<td>' + Helpers.formatCurrency(product.price) + '</td>' +
        '<td class=\"price-edit-cell\" data-product-id=\"' + product.id + '\">' +
        '<span class=\"price-display\" data-product-id=\"' + product.id + '\">' +
        '<span style=\"' + (hasCustomPrice ? 'font-weight: 600; color: #22c55e;' : '') + '\">' +
        Helpers.formatCurrency(effectivePrice) +
        '</span> ' +
        (hasCustomPrice ? '<span class=\"label label-success\">Partner</span>' : '') +
        '</span>' +
        '<div class=\"price-edit-controls\" data-product-id=\"' + product.id + '\" style=\"display: none;\">' +
        '<div class=\"input-group\" style=\"width: 200px;\">' +
        '<span class=\"input-group-addon\">$</span>' +
        '<input type=\"number\" class=\"form-control input-sm price-edit-input\" ' +
        'data-product-id=\"' + product.id + '\" ' +
        'data-base-price=\"' + product.price + '\" ' +
        'value=\"' + (hasCustomPrice ? customPrice : product.price) + '\" ' +
        'step=\"0.01\" min=\"0.01\" style=\"height: 30px;\">' +
        '<span class=\"input-group-btn\">' +
        '<button class=\"btn btn-sm btn-success save-price-btn\" data-product-id=\"' + product.id + '\" style=\"height: 30px;\">' +
        '<span class=\"glyphicon glyphicon-ok\"></span>' +
        '</button>' +
        '<button class=\"btn btn-sm btn-default cancel-price-btn\" data-product-id=\"' + product.id + '\" style=\"height: 30px;\">' +
        '<span class=\"glyphicon glyphicon-remove\"></span>' +
        '</button>' +
        '</span>' +
        '</div>' +
        '</div>' +
        '</td>' +
        '<td>' +
        '<button class="btn btn-sm btn-default edit-price-btn" data-product-id="' + product.id + '" style="margin-right: 5px;">' +
        '<span class="glyphicon glyphicon-pencil"></span> Edit' +
        '</button>' +
        (hasCustomPrice ? 
          '<button class="btn btn-sm btn-default reset-custom-price-btn" data-product-id="' + product.id + '">' +
          '<span class="glyphicon glyphicon-repeat"></span> Reset' +
          '</button>' : '') +
        '</td>' +
        '</tr>';
    });
    
    html += '</tbody></table></div>';
    
    // No results message
    html += '<div id="no-pricing-results" style="display: none; text-align: center; padding: 40px; color: #999;">' +
      '<span class="glyphicon glyphicon-search" style="font-size: 48px; display: block; margin-bottom: 15px;"></span>' +
      '<p>No products found matching your search.</p>' +
      '</div>';
    
    html += '</div></div>';
    
    // Attach events for search, filter, and pricing
    setTimeout(function() {
      var filterPricingTable = function() {
        var searchTerm = $('#pricing-search').val().toLowerCase();
        var categoryFilter = $('#pricing-category-filter').val();
        var visibleCount = 0;
        
        $('.pricing-row').each(function() {
          var $row = $(this);
          var productName = $row.data('product-name');
          var category = $row.data('category');
          var sku = $row.data('sku');
          
          var matchesSearch = searchTerm === '' ||
            productName.indexOf(searchTerm) !== -1 ||
            category.indexOf(searchTerm) !== -1 ||
            sku.indexOf(searchTerm) !== -1;
          
          var matchesCategory = categoryFilter === 'all' || category === categoryFilter.toLowerCase();
          
          if (matchesSearch && matchesCategory) {
            $row.show();
            visibleCount++;
          } else {
            $row.hide();
          }
        });
        
        // Show/hide no results message
        if (visibleCount === 0) {
          $('#pricing-table').hide();
          $('#no-pricing-results').show();
        } else {
          $('#pricing-table').show();
          $('#no-pricing-results').hide();
        }
      };
      
      // Search input
      $(document).off('input', '#pricing-search').on('input', '#pricing-search', filterPricingTable);
      
      // Category filter
      $(document).off('change', '#pricing-category-filter').on('change', '#pricing-category-filter', filterPricingTable);
      
      // Edit price button
      $(document).off('click', '.edit-price-btn').on('click', '.edit-price-btn', function() {
        var productId = $(this).data('product-id');
        // Toggle inline edit mode
        $('.price-display[data-product-id="' + productId + '"]').hide();
        $('.price-edit-controls[data-product-id="' + productId + '"]').show();
        $('.price-edit-input[data-product-id="' + productId + '"]').focus().select();
      });
      
      // Reset custom price
      $(document).off('click', '.reset-custom-price-btn').on('click', '.reset-custom-price-btn', function() {
        var productId = $(this).data('product-id');
        self.resetCustomPrice(productId);
      });
      
      // Save price button
      $(document).off('click', '.save-price-btn').on('click', '.save-price-btn', function() {
        var productId = $(this).data('product-id');
        var input = $('.price-edit-input[data-product-id="' + productId + '"]');
        var customPrice = parseFloat(input.val());
        
        if (!customPrice || customPrice <= 0) {
          Helpers.showAlert('Please enter a valid price', 'warning');
          return;
        }
        
        self.updateCustomPrice(productId, customPrice);
        $('.price-edit-controls[data-product-id="' + productId + '"]').hide();
        $('.price-display[data-product-id="' + productId + '"]').show();
      });
      
      // Cancel price button
      $(document).off('click', '.cancel-price-btn').on('click', '.cancel-price-btn', function() {
        var productId = $(this).data('product-id');
        $('.price-edit-controls[data-product-id="' + productId + '"]').hide();
        $('.price-display[data-product-id="' + productId + '"]').show();
      });
      
      // Allow Enter key to save
      $(document).off('keypress', '.price-edit-input').on('keypress', '.price-edit-input', function(e) {
        if (e.which === 13) {
          var productId = $(this).data('product-id');
          $('.save-price-btn[data-product-id="' + productId + '"]').click();
        }
      });
    }, 0);
    
    return html;
  },
  
  selectGroup: function(groupId) {
    this.selectedGroupId = groupId;
    $('.user-group-card').removeClass('selected');
    $('.user-group-card[data-group-id="' + groupId + '"]').addClass('selected');
  },
  
  showEditPartnerModal: function() {
    var partner = AppState.getPartnerById(this.partnerId);
    // Navigate to partner form wizard in edit mode
    App.navigate('partner-form', { partnerId: this.partnerId });
  },
  
  showAddEmployeeModal: function() {
    var partner = AppState.getPartnerById(this.partnerId);
    Templates.showAddEmployeeModal(partner, this.partnerId);
  },
  
  showCreateGroupModal: function() {
    var partner = AppState.getPartnerById(this.partnerId);
    Templates.showCreateGroupModal(partner, this.partnerId);
  },
  
  showEditGroupModal: function(groupId) {
    var partner = AppState.getPartnerById(this.partnerId);
    var group = partner.groups.find(function(g) { return g.id === groupId; });
    if (group) {
      Templates.showEditGroupModal(partner, group, this.partnerId);
    }
  },
  
  deleteGroup: function(groupId) {
    var self = this;
    var partner = AppState.getPartnerById(this.partnerId);
    var group = partner.groups.find(function(g) { return g.id === groupId; });
    
    if (group.name === 'Default Group') {
      UIHelpers.showError('Cannot Delete Default Group', 'The default group cannot be deleted as it is required for the system to function properly.');
      return;
    }
    
    // Check if group has employees
    var employeeCount = partner.employees.filter(function(e) { return e.groupId === groupId; }).length;
    var message = 'Are you sure you want to delete "' + group.name + '"?';
    
    if (employeeCount > 0) {
      message += '\n\nWarning: This group currently has ' + employeeCount + ' employee(s). Deleting the group will remove group assignment from these employees.';
    }
    
    UIHelpers.showConfirmDialog({
      title: 'Delete User Group',
      message: message,
      confirmText: 'Delete Group',
      confirmClass: 'btn-danger',
      onConfirm: function() {
        UIHelpers.showLoadingSpinner('Deleting group...');
        
        setTimeout(function() {
          var updatedGroups = partner.groups.filter(function(g) { return g.id !== groupId; });
          
          // Remove group assignment from employees
          var updatedEmployees = partner.employees.map(function(e) {
            if (e.groupId === groupId) {
              return Object.assign({}, e, { groupId: null });
            }
            return e;
          });
          
          AppState.updatePartner(self.partnerId, { 
            groups: updatedGroups,
            employees: updatedEmployees
          });
          
          UIHelpers.hideLoadingSpinner();
          self.renderTabContent('employees');
          Helpers.showAlert('Group "' + group.name + '" deleted successfully', 'success');
        }, 500);
      }
    });
  },
  
  showCreateVoucherModal: function() {
    App.navigate('voucher-form', { partnerId: this.partnerId });
  },
  
  showEditVoucherModal: function(voucherId) {
    App.navigate('voucher-form', { partnerId: this.partnerId, voucherId: voucherId });
  },
  
  deleteVoucher: function(voucherId) {
    var self = this;
    var partner = AppState.getPartnerById(this.partnerId);
    var voucher = partner.vouchers.find(function(v) { return v.id === voucherId; });
    
    if (!voucher) return;
    
    // Check if voucher is assigned to any employees
    var affectedEmployees = partner.employees.filter(function(e) {
      return e.voucherBalances && e.voucherBalances.some(function(vb) {
        return vb.voucherId === voucherId;
      });
    }).length;
    
    var message = 'Are you sure you want to delete the voucher "' + voucher.name + '"?';
    
    if (affectedEmployees > 0) {
      message += '\n\nWarning: This voucher is currently assigned to ' + affectedEmployees + ' employee(s). Their voucher balances will be updated.';
    }
    
    UIHelpers.showConfirmDialog({
      title: 'Delete Voucher',
      message: message,
      confirmText: 'Delete Voucher',
      confirmClass: 'btn-danger',
      onConfirm: function() {
        UIHelpers.showLoadingSpinner('Deleting voucher...');
        
        setTimeout(function() {
          var updatedVouchers = partner.vouchers.filter(function(v) { return v.id !== voucherId; });
          
          // Update employee voucher balances
          var updatedEmployees = partner.employees.map(function(e) {
            if (e.voucherBalances) {
              var newBalances = e.voucherBalances.filter(function(vb) {
                return vb.voucherId !== voucherId;
              });
              var newTotal = newBalances.reduce(function(sum, vb) {
                return sum + vb.remainingAmount;
              }, 0);
              
              return Object.assign({}, e, {
                voucherBalances: newBalances,
                remainingBalance: newTotal
              });
            }
            return e;
          });
          
          AppState.updatePartner(self.partnerId, { 
            vouchers: updatedVouchers,
            employees: updatedEmployees,
            activeVouchers: updatedVouchers.filter(function(v) { return v.isActive; }).length
          });
          
          UIHelpers.hideLoadingSpinner();
          self.renderTabContent('vouchers');
          Helpers.showAlert('Voucher "' + voucher.name + '" deleted successfully', 'success');
        }, 500);
      }
    });
  },
  
  deleteEmployee: function(employeeId) {
    var self = this;
    var partner = AppState.getPartnerById(this.partnerId);
    var employee = partner.employees.find(function(e) { return e.id === employeeId; });
    
    if (!employee) return;
    
    var employeeName = employee.firstName && employee.lastName 
      ? employee.firstName + ' ' + employee.lastName 
      : employee.name;
    
    UIHelpers.showConfirmDialog({
      title: 'Delete Employee',
      message: 'Are you sure you want to delete employee "' + employeeName + '"?\n\nThis action cannot be undone.',
      confirmText: 'Delete Employee',
      confirmClass: 'btn-danger',
      onConfirm: function() {
        UIHelpers.showLoadingSpinner('Deleting employee...');
        
        setTimeout(function() {
          var updatedEmployees = partner.employees.filter(function(e) { return e.id !== employeeId; });
          
          // Update employee counts in groups
          var updatedGroups = partner.groups.map(function(group) {
            var count = updatedEmployees.filter(function(e) { return e.groupId === group.id; }).length;
            return Object.assign({}, group, { employeeCount: count });
          });
          
          AppState.updatePartner(self.partnerId, { 
            employees: updatedEmployees,
            groups: updatedGroups,
            employeeCount: updatedEmployees.length
          });
          
          UIHelpers.hideLoadingSpinner();
          self.renderTabContent('employees');
          Helpers.showAlert('Employee "' + employeeName + '" deleted successfully', 'success');
        }, 500);
      }
    });
  },
  
  toggleEmployeeStatus: function(employeeId) {
    var self = this;
    var partner = AppState.getPartnerById(this.partnerId);
    var employee = partner.employees.find(function(e) { return e.id === employeeId; });
    
    if (!employee) return;
    
    var newStatus = employee.status === 'active' ? 'inactive' : 'active';
    var employeeName = employee.firstName && employee.lastName 
      ? employee.firstName + ' ' + employee.lastName 
      : employee.name;
    
    UIHelpers.showConfirmDialog({
      title: 'Toggle Employee Status',
      message: 'Are you sure you want to ' + (newStatus === 'active' ? 'activate' : 'deactivate') + ' employee "' + employeeName + '"?',
      confirmText: 'Confirm',
      confirmClass: 'btn-' + (newStatus === 'active' ? 'success' : 'warning'),
      onConfirm: function() {
        UIHelpers.showLoadingSpinner('Updating employee status...');
        
        setTimeout(function() {
          var updatedEmployees = partner.employees.map(function(e) {
            if (e.id === employeeId) {
              return Object.assign({}, e, { status: newStatus });
            }
            return e;
          });
          
          AppState.updatePartner(self.partnerId, { 
            employees: updatedEmployees
          });
          
          UIHelpers.hideLoadingSpinner();
          self.renderTabContent('employees');
          Helpers.showAlert('Employee "' + employeeName + '" ' + (newStatus === 'active' ? 'activated' : 'deactivated') + ' successfully', 'success');
        }, 500);
      }
    });
  },
  
  showEditEmployeeModal: function(employeeId) {
    var partner = AppState.getPartnerById(this.partnerId);
    var employee = partner.employees.find(function(e) { return e.id === employeeId; });
    if (employee) {
      Templates.showEditEmployeeModal(partner, employee, this.partnerId);
    }
  },
  
  updateProductVisibility: function(productId, visible) {
    var partner = AppState.getPartnerById(this.partnerId);
    var updatedProducts = partner.availableProducts.map(function(p) {
      if (p.id === productId) {
        return Object.assign({}, p, { visible: visible });
      }
      return p;
    });
    
    AppState.updatePartner(this.partnerId, { availableProducts: updatedProducts });
    Helpers.showAlert('Product visibility updated', 'success');
  },
  
  updateCustomPrice: function(productId, customPrice) {
    var partner = AppState.getPartnerById(this.partnerId);
    var updatedProducts = partner.availableProducts.map(function(p) {
      if (p.id === productId) {
        return Object.assign({}, p, { customPrice: customPrice });
      }
      return p;
    });
    
    AppState.updatePartner(this.partnerId, { availableProducts: updatedProducts });
    this.renderTabContent('pricing');
    Helpers.showAlert('Custom price updated successfully', 'success');
  },
  
  resetCustomPrice: function(productId) {
    var self = this;
    var partner = AppState.getPartnerById(this.partnerId);
    
    UIHelpers.showConfirmDialog({
      title: 'Reset Custom Price',
      message: 'Are you sure you want to reset to the default price?',
      confirmText: 'Reset Price',
      confirmClass: 'btn-warning',
      onConfirm: function() {
        var updatedProducts = partner.availableProducts.map(function(p) {
          if (p.id === productId) {
            var updated = Object.assign({}, p);
            delete updated.customPrice;
            return updated;
          }
          return p;
        });
        
        AppState.updatePartner(self.partnerId, { availableProducts: updatedProducts });
        self.renderTabContent('pricing');
        Helpers.showAlert('Custom price reset to default', 'success');
      }
    });
  },
  
  showEditPriceModal: function(productId) {
    var partner = AppState.getPartnerById(this.partnerId);
    var product = AppState.products.find(function(p) { return p.id === productId; });
    var partnerProduct = partner.availableProducts.find(function(p) { return p.id === productId; });
    var customPrice = partnerProduct && partnerProduct.customPrice ? partnerProduct.customPrice : '';
    var hasCustomPrice = partnerProduct && partnerProduct.customPrice;
    var effectivePrice = hasCustomPrice ? customPrice : product.price;
    
    var modalHtml = '<div class="modal fade" id="edit-price-modal" tabindex="-1" role="dialog" aria-labelledby="edit-price-modal-label" aria-hidden="true">' +
      '<div class="modal-dialog" role="document">' +
      '<div class="modal-content">' +
      '<div class="modal-header">' +
      '<button type="button" class="close" data-dismiss="modal" aria-label="Close">' +
      '<span aria-hidden="true">&times;</span>' +
      '</button>' +
      '<h4 class="modal-title" id="edit-price-modal-label">Edit Price for ' + Helpers.escapeHtml(product.name) + '</h4>' +
      '</div>' +
      '<div class="modal-body">' +
      '<p class="text-muted">Set a custom price for this product that applies only to ' + Helpers.escapeHtml(partner.name) + '.</p>' +
      '<div class="input-group" style="width: 150px;">' +
      '<span class="input-group-addon">$</span>' +
      '<input type="number" class="form-control custom-price-input" ' +
      'data-product-id="' + product.id + '" ' +
      'value="' + customPrice + '" ' +
      'step="0.01" ' +
      'placeholder="' + product.price.toFixed(2) + '">' +
      '</div>' +
      '</div>' +
      '<div class="modal-footer">' +
      '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
      '<button type="button" class="btn btn-primary save-custom-price-btn" data-product-id="' + product.id + '">' +
      '<span class="glyphicon glyphicon-floppy-disk"></span> Save' +
      '</button>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '</div>';
    
    $('body').append(modalHtml);
    
    // Attach events for modal
    $('#edit-price-modal').modal('show');
    
    // Save custom price
    $(document).off('click', '.save-custom-price-btn').on('click', '.save-custom-price-btn', function() {
      var productId = $(this).data('product-id');
      var input = $('.custom-price-input[data-product-id="' + productId + '"]');
      var customPrice = parseFloat(input.val());
      
      if (!customPrice || customPrice <= 0) {
        Helpers.showAlert('Please enter a valid price', 'warning');
        return;
      }
      
      self.updateCustomPrice(productId, customPrice);
      $('#edit-price-modal').modal('hide');
    });
    
    // Allow Enter key to save
    $(document).off('keypress', '.custom-price-input').on('keypress', '.custom-price-input', function(e) {
      if (e.which === 13) {
        var productId = $(this).data('product-id');
        $('.save-custom-price-btn[data-product-id="' + productId + '"]').click();
      }
    });
  }
};