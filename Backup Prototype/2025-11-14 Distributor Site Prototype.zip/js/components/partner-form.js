// Partner Form Component (Multi-step wizard)

var PartnerFormComponent = {
  currentStep: 1,
  totalSteps: 5,
  isEditMode: false,
  editingPartnerId: null,
  formData: {
    name: '',
    slug: '',
    status: 'active',
    logo: null,
    employeeFieldConfig: {
      requireEmployeeId: true,
      requireUsername: false,
      requireDateOfBirth: true,
      requireStartDate: false
    },
    paymentMethods: []
  },
  
  init: function(partner) {
    this.currentStep = 1;
    this.isEditMode = !!partner;
    this.editingPartnerId = partner ? partner.id : null;
    
    if (partner) {
      // Normalize payment methods - if array, use first one; if empty, default to Credit Card
      var paymentMethods = partner.paymentMethods;
      if (Array.isArray(paymentMethods) && paymentMethods.length > 0) {
        paymentMethods = [paymentMethods[0]]; // Use first method only for radio buttons
      } else {
        paymentMethods = ['Credit Card']; // Default if empty
      }
      
      this.formData = {
        name: partner.name,
        slug: partner.slug,
        status: partner.status,
        logo: partner.logoUrl || null,
        employeeFieldConfig: partner.employeeFieldConfig,
        paymentMethods: paymentMethods
      };
    } else {
      this.resetFormData();
    }
    
    this.render();
    this.attachEvents();
  },
  
  resetFormData: function() {
    this.formData = {
      name: '',
      slug: '',
      status: 'active',
      logo: null,
      employeeFieldConfig: {
        requireEmployeeId: true,
        requireUsername: false,
        requireDateOfBirth: true,
        requireStartDate: false
      },
      paymentMethods: ['Credit Card'] // Default to Credit Card for new partners
    };
  },
  
  render: function() {
    $('#app-container').html(Templates.partnerFormWizard(this.currentStep, this.formData, this.isEditMode));
    // Always update slug preview after rendering step 1
    if (this.currentStep === 1) {
      this.updateSlugPreview();
    }
  },
  
  attachEvents: function() {
    var self = this;
    
    // Remove all existing event handlers first to prevent duplicates
    $(document).off('click', '#cancel-partner-form');
    $(document).off('click', '#next-step-btn');
    $(document).off('click', '#back-step-btn');
    $(document).off('input change', '#partner-name');
    $(document).off('input change', '#partner-slug');
    $(document).off('change', '#partner-status');
    $(document).off('change', '#partner-logo-upload');
    $(document).off('click', '#remove-logo-btn');
    $(document).off('click', '#upload-logo-area');
    $(document).off('change', '#require-employee-id');
    $(document).off('change', '#require-username');
    $(document).off('change', '#require-dob');
    $(document).off('change', '#require-start-date');
    $(document).off('change', '#payment-credit-card');
    $(document).off('change', '#payment-payroll');
    $(document).off('click', '#save-partner-btn');
    
    // Cancel button
    $(document).on('click', '#cancel-partner-form', function(e) {
      e.preventDefault();
      App.navigate('dashboard');
    });
    
    // Next button
    $(document).on('click', '#next-step-btn', function() {
      if (self.validateStep(self.currentStep)) {
        self.currentStep++;
        self.render();
      }
    });
    
    // Back button
    $(document).on('click', '#back-step-btn', function() {
      self.currentStep--;
      self.render();
    });
    
    // Form field changes
    $(document).on('input change', '#partner-name', function() {
      self.formData.name = $(this).val();
      if (!self.isEditMode) {
        self.formData.slug = self.generateSlug($(this).val());
        $('#partner-slug').val(self.formData.slug);
        self.updateSlugPreview();
      }
    });
    
    $(document).on('input change', '#partner-slug', function() {
      self.formData.slug = $(this).val().toLowerCase();
      self.updateSlugPreview();
    });
    
    $(document).on('change', '#partner-status', function() {
      self.formData.status = $(this).val();
    });
    
    // Logo upload
    $(document).on('change', '#partner-logo-upload', function(e) {
      self.handleLogoUpload(e);
    });
    
    $(document).on('click', '#remove-logo-btn', function() {
      self.formData.logo = null;
      self.render();
    });
    
    $(document).on('click', '#upload-logo-area', function() {
      $('#partner-logo-upload').click();
    });
    
    // Employee field config checkboxes - only allow changes if not in edit mode
    $(document).on('change', '#require-employee-id', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireEmployeeId);
        $('#require-username').prop('checked', self.formData.employeeFieldConfig.requireUsername);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireEmployeeId = true;
        self.formData.employeeFieldConfig.requireUsername = false;
      }
    });
    
    $(document).on('change', '#require-username', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireUsername);
        $('#require-employee-id').prop('checked', self.formData.employeeFieldConfig.requireEmployeeId);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireEmployeeId = false;
        self.formData.employeeFieldConfig.requireUsername = true;
      }
    });
    
    $(document).on('change', '#require-dob', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireDateOfBirth);
        $('#require-start-date').prop('checked', self.formData.employeeFieldConfig.requireStartDate);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireDateOfBirth = true;
        self.formData.employeeFieldConfig.requireStartDate = false;
      }
    });
    
    $(document).on('change', '#require-start-date', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireStartDate);
        $('#require-dob').prop('checked', self.formData.employeeFieldConfig.requireDateOfBirth);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireDateOfBirth = false;
        self.formData.employeeFieldConfig.requireStartDate = true;
      }
    });
    
    // Payment methods (radio buttons - single selection)
    $(document).on('change', 'input[name="payment-method"]', function() {
      var selectedMethod = $(this).val();
      // Store as array with single value for compatibility with existing data structure
      self.formData.paymentMethods = [selectedMethod];
    });
    
    // Save button
    $(document).on('click', '#save-partner-btn', function() {
      self.handleSave();
    });
  },
  
  generateSlug: function(text) {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  },
  
  updateSlugPreview: function() {
    var distributorName = AppState.distributorName || 'Premier Distributor Co';
    var distributorSlug = this.generateSlug(distributorName);
    var partnerSlug = this.formData.slug || 'partner-name';
    var url = 'www.surewerxdistributor.com/<span style="color: #666;">' + distributorSlug + '</span>/<strong>' + partnerSlug + '</strong>';
    $('#slug-preview').html(url);
  },
  
  handleLogoUpload: function(e) {
    var file = e.target.files[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
      Helpers.showAlert('Logo file size must be less than 5MB', 'danger');
      return;
    }
    
    if (!file.type.startsWith('image/')) {
      Helpers.showAlert('Please upload an image file', 'danger');
      return;
    }
    
    var reader = new FileReader();
    var self = this;
    reader.onload = function(event) {
      self.formData.logo = event.target.result;
      self.render();
    };
    reader.readAsDataURL(file);
  },
  
  validateStep: function(step) {
    switch(step) {
      case 1:
        if (!this.formData.name.trim()) {
          Helpers.showAlert('Please enter a partner name', 'danger', '#next-step-btn');
          return false;
        }
        if (!this.formData.slug.trim()) {
          Helpers.showAlert('Please enter a partner URL slug', 'danger', '#next-step-btn');
          return false;
        }
        // Validate slug format
        var slugPattern = /^[a-z0-9-]+$/;
        if (!slugPattern.test(this.formData.slug)) {
          Helpers.showAlert('Partner URL slug can only contain lowercase letters, numbers, and hyphens', 'danger', '#next-step-btn');
          return false;
        }
        // Check if slug already exists (only for new partners)
        if (!this.isEditMode) {
          var existingPartner = AppState.partners.find(function(p) {
            return p.slug === this.formData.slug;
          }.bind(this));
          if (existingPartner) {
            Helpers.showAlert('This URL slug is already in use. Please choose a different one.', 'danger', '#next-step-btn');
            return false;
          }
        }
        return true;
      case 3:
        // Check at least one identifier field
        var hasIdentifier = this.formData.employeeFieldConfig.requireEmployeeId || 
                           this.formData.employeeFieldConfig.requireUsername;
        if (!hasIdentifier) {
          Helpers.showAlert('Please select at least one identifier field (Employee ID or Username)', 'danger', '#next-step-btn');
          return false;
        }
        // Check at least one date field
        var hasDate = this.formData.employeeFieldConfig.requireDateOfBirth || 
                     this.formData.employeeFieldConfig.requireStartDate;
        if (!hasDate) {
          Helpers.showAlert('Please select at least one date field (Date of Birth or Start Date)', 'danger', '#next-step-btn');
          return false;
        }
        return true;
      case 4:
        if (this.formData.paymentMethods.length === 0) {
          Helpers.showAlert('Please select at least one payment method', 'danger', '#next-step-btn');
          return false;
        }
        return true;
      default:
        return true;
    }
  },
  
  handleSave: function() {
    if (!this.validateStep(4)) {
      return;
    }
    
    if (this.isEditMode) {
      // Get the original partner to preserve identifier fields
      var originalPartner = AppState.getPartnerById(this.editingPartnerId);
      
      // Update existing partner - preserve all employee field config from original
      var employeeFieldConfig = {
        requireEmployeeId: originalPartner.employeeFieldConfig.requireEmployeeId,
        requireUsername: originalPartner.employeeFieldConfig.requireUsername,
        requireDateOfBirth: originalPartner.employeeFieldConfig.requireDateOfBirth,
        requireStartDate: originalPartner.employeeFieldConfig.requireStartDate
      };
      
      AppState.updatePartner(this.editingPartnerId, {
        name: this.formData.name.trim(),
        status: this.formData.status,
        logoUrl: this.formData.logo,
        employeeFieldConfig: employeeFieldConfig,
        paymentMethods: this.formData.paymentMethods
      });
      
      Helpers.showAlert('Partner updated successfully', 'success');
    } else {
      // Create new partner
      var newPartner = {
        id: Helpers.generateId(),
        name: this.formData.name.trim(),
        slug: this.formData.slug.trim(),
        industry: 'General', // Default industry
        status: this.formData.status,
        logoUrl: this.formData.logo,
        employeeCount: 0,
        activeVouchers: 0,
        monthlySpend: 0,
        totalBudget: 0,
        paymentMethods: this.formData.paymentMethods,
        employeeFieldConfig: this.formData.employeeFieldConfig,
        employees: [],
        groups: [
          {
            id: Helpers.generateId(),
            name: 'Default Group',
            department: '',
            location: '',
            employeeCount: 0,
            productIds: [],
            categoryIds: []
          }
        ],
        vouchers: [],
        availableProducts: AppState.products.slice()
      };
      
      AppState.partners.push(newPartner);
      AppState.savePartners();
      Helpers.showAlert('Partner created successfully', 'success');
    }
    
    App.navigate('dashboard');
  }
};