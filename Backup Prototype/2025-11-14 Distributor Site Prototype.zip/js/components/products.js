// Products Management Component

var ProductsComponent = {
  searchTerm: '',
  categoryFilter: 'all',
  editingProduct: null,
  displayCount: 20, // Initial number of products to display
  incrementCount: 20, // Number to load on each scroll
  
  init: function() {
    this.displayCount = 20; // Reset display count
    this.render();
    this.attachEvents();
    this.attachScrollListener();
  },
  
  render: function() {
    var categories = this.getCategories();
    
    var html = '<div>' +
      Templates.header() +
      '<div class="container">' +
      '<div class="row mb-4">' +
      '<div class="col-md-12">' +
      '<button class="btn btn-default mb-3" id="back-to-dashboard">' +
      '<span class="glyphicon glyphicon-chevron-left"></span> Back to Dashboard' +
      '</button>' +
      '<h2>Product Management</h2>' +
      '<p class="text-muted">Manage product SKU numbers globally - pricing can only be overridden at the partner level</p>' +
      '</div>' +
      '</div>' +
      
      '<div class="row mb-4">' +
      '<div class="col-md-8">' +
      '<div class="input-group">' +
      '<span class="input-group-addon"><span class="glyphicon glyphicon-search"></span></span>' +
      '<input type="text" class="form-control" id="product-search" placeholder="Search by product name, category, or SKU..." value="' + Helpers.escapeHtml(this.searchTerm) + '">' +
      '</div>' +
      '</div>' +
      '<div class="col-md-4">' +
      '<select class="form-control" id="category-filter">' +
      '<option value="all">All Categories</option>' +
      categories.map(function(cat) {
        return '<option value="' + Helpers.escapeHtml(cat) + '">' + Helpers.escapeHtml(cat) + '</option>';
      }).join('') +
      '</select>' +
      '</div>' +
      '</div>' +
      
      this.renderProductsTable() +
      
      '</div>' +
      '</div>';
    
    $('#app-container').html(html);
    this.updateActiveNav('products');
  },
  
  attachEvents: function() {
    var self = this;
    
    // Back button
    $(document).on('click', '#back-to-dashboard', function() {
      App.navigate('dashboard');
    });
    
    // Search
    $(document).on('input', '#product-search', function() {
      self.searchTerm = $(this).val();
      self.displayCount = 20; // Reset display count on search
      self.updateProductsTable();
    });
    
    // Category filter
    $(document).on('change', '#category-filter', function() {
      self.categoryFilter = $(this).val();
      self.displayCount = 20; // Reset display count on filter
      self.updateProductsTable();
    });
    
    // Edit SKU button
    $(document).on('click', '.edit-sku-btn', function() {
      var productId = $(this).data('product-id');
      var product = AppState.products.find(function(p) { return p.id === productId; });
      if (product) {
        self.showEditSkuModal(product);
      }
    });
  },
  
  attachScrollListener: function() {
    var self = this;
    
    // Remove any existing scroll listener to prevent duplicates
    $(window).off('scroll.productsLazyLoad');
    
    // Use component property for isLoading to persist across re-attachments
    if (typeof this.isLoading === 'undefined') {
      this.isLoading = false;
    }
    
    $(window).on('scroll.productsLazyLoad', function() {
      if (self.isLoading) return;
      
      var scrollTop = $(window).scrollTop();
      var windowHeight = $(window).height();
      var documentHeight = $(document).height();
      
      // Check if user is near bottom (within 200px)
      if (scrollTop + windowHeight >= documentHeight - 200) {
        var filteredProducts = self.getFilteredProducts();
        if (self.displayCount < filteredProducts.length) {
          self.isLoading = true;
          self.displayCount += self.incrementCount;
          self.updateProductsTable();
          setTimeout(function() {
            self.isLoading = false;
          }, 200);
        }
      }
    });
  },
  
  updateActiveNav: function(view) {
    $('.nav-link').removeClass('active');
    $('.nav-link[data-nav="' + view + '"]').addClass('active');
  },
  
  getCategories: function() {
    var categories = [];
    AppState.products.forEach(function(p) {
      if (categories.indexOf(p.category) === -1) {
        categories.push(p.category);
      }
    });
    return categories.sort();
  },
  
  getFilteredProducts: function() {
    var products = AppState.products;
    var searchLower = this.searchTerm.toLowerCase();
    
    return products.filter(function(product) {
      var matchesSearch = !searchLower ||
        product.name.toLowerCase().indexOf(searchLower) > -1 ||
        product.category.toLowerCase().indexOf(searchLower) > -1 ||
        product.surewerxSku.toLowerCase().indexOf(searchLower) > -1 ||
        (product.customSku && product.customSku.toLowerCase().indexOf(searchLower) > -1);
      
      var matchesCategory = this.categoryFilter === 'all' || product.category === this.categoryFilter;
      
      return matchesSearch && matchesCategory;
    }.bind(this));
  },
  
  renderProductsTable: function() {
    var filteredProducts = this.getFilteredProducts();
    var customSkuCount = AppState.products.filter(function(p) { return p.customSku; }).length;
    var displayedProducts = filteredProducts.slice(0, this.displayCount);
    var hasMore = filteredProducts.length > this.displayCount;
    
    return '<div class="panel panel-default">' +
      '<table class="table table-hover">' +
      '<thead>' +
      '<tr>' +
      '<th>Product Name</th>' +
      '<th>SureWerx SKU</th>' +
      '<th>Custom SKU</th>' +
      '<th>Category</th>' +
      '<th>Base Price</th>' +
      '<th class="text-right">Actions</th>' +
      '</tr>' +
      '</thead>' +
      '<tbody id="products-table-body">' +
      (filteredProducts.length === 0 ?
        '<tr><td colspan="6" class="text-center text-muted">No products found matching your search.</td></tr>' :
        displayedProducts.map(function(product) {
          return '<tr>' +
            '<td>' + Helpers.escapeHtml(product.name) + '</td>' +
            '<td><code>' + Helpers.escapeHtml(product.surewerxSku) + '</code></td>' +
            '<td>' + (product.customSku ? 
              '<strong><code>' + Helpers.escapeHtml(product.customSku) + '</code></strong>' : 
              '<span class="text-muted">Not set</span>') + '</td>' +
            '<td><span class="label label-default">' + Helpers.escapeHtml(product.category) + '</span></td>' +
            '<td>' + Helpers.formatCurrency(product.price) + '</td>' +
            '<td class="text-right">' +
            '<button class="btn btn-sm btn-default edit-sku-btn" data-product-id="' + product.id + '">' +
            '<span class="glyphicon glyphicon-pencil"></span> ' + (product.customSku ? 'Edit' : 'Add') + ' SKU' +
            '</button>' +
            '</td>' +
            '</tr>';
        }).join('')) +
      (hasMore ? 
        '<tr id="loading-more-row">' +
        '<td colspan="6" class="text-center text-muted" style="padding: 20px;">' +
        '<span class="glyphicon glyphicon-refresh"></span> Scroll down to load more products...' +
        '</td>' +
        '</tr>' : '') +
      '</tbody>' +
      '</table>' +
      '</div>';
  },
  
  updateProductsTable: function() {
    $('#products-table-body').parent().parent().replaceWith(this.renderProductsTable());
    // Re-attach scroll listener after table update to ensure it's working
    // The listener should persist, but this ensures it's active after DOM changes
    this.attachScrollListener();
  },
  
  showEditSkuModal: function(product) {
    this.editingProduct = product;
    
    var modalHtml = '<div class="modal fade" id="edit-sku-modal" tabindex="-1">' +
      '<div class="modal-dialog">' +
      '<div class="modal-content">' +
      '<div class="modal-header">' +
      '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
      '<h4 class="modal-title">Custom SKU Number</h4>' +
      '</div>' +
      '<form id="edit-sku-form">' +
      '<div class="modal-body">' +
      '<p class="text-muted">Add your own SKU number for <strong>' + Helpers.escapeHtml(product.name) + '</strong>. This will apply to all partners, user groups, and vouchers.</p>' +
      '<div class="well">' +
      '<div class="row">' +
      '<div class="col-xs-6 text-muted">SureWerx SKU:</div>' +
      '<div class="col-xs-6 text-right"><code><strong>' + Helpers.escapeHtml(product.surewerxSku) + '</strong></code></div>' +
      '</div>' +
      (product.customSku ?
        '<div class="row mt-2">' +
        '<div class="col-xs-6 text-muted">Current Custom SKU:</div>' +
        '<div class="col-xs-6 text-right"><code class="text-primary"><strong>' + Helpers.escapeHtml(product.customSku) + '</strong></code></div>' +
        '</div>' : '') +
      '</div>' +
      '<div class="form-group">' +
      '<label>Custom SKU</label>' +
      '<input type="text" class="form-control" id="custom-sku-input" value="' + Helpers.escapeHtml(product.customSku || '') + '" placeholder="Enter your custom SKU">' +
      '<small class="text-muted">Leave blank to remove custom SKU</small>' +
      '</div>' +
      '</div>' +
      '<div class="modal-footer">' +
      '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
      '<button type="submit" class="btn btn-primary">Save SKU</button>' +
      '</div>' +
      '</form>' +
      '</div>' +
      '</div>' +
      '</div>';
    
    $('body').append(modalHtml);
    $('#edit-sku-modal').modal('show');
    
    var self = this;
    $(document).off('submit', '#edit-sku-form').on('submit', '#edit-sku-form', function(e) {
      e.preventDefault();
      
      var newSku = $('#custom-sku-input').val().trim();
      
      // Update the product
      var productIndex = AppState.products.findIndex(function(p) { return p.id === product.id; });
      if (productIndex > -1) {
        if (newSku) {
          AppState.products[productIndex].customSku = newSku;
        } else {
          delete AppState.products[productIndex].customSku;
        }
        AppState.saveToStorage();
      }
      
      $('#edit-sku-modal').modal('hide');
      self.updateProductsTable();
      Helpers.showAlert('Product SKU updated successfully', 'success');
    });
    
    $('#edit-sku-modal').on('hidden.bs.modal', function() {
      $(this).remove();
    });
  }
};
