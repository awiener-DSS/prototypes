// Reporting Component

var ReportingComponent = {
  filters: {
    partner: 'all',
    dateRange: 'all',
    voucher: 'all',
    status: 'all'
  },
  
  init: function() {
    this.render();
    this.attachEvents();
  },
  
  render: function() {
    var html = '<div>' +
      Templates.header() +
      '<div class="container">' +
      '<div class="row mb-4">' +
      '<div class="col-md-8">' +
      '<button class="btn btn-default mb-3" id="back-to-dashboard">' +
      '<span class="glyphicon glyphicon-chevron-left"></span> Back to Dashboard' +
      '</button>' +
      '<h2>Reporting</h2>' +
      '<p class="text-muted">Track key metrics and performance across all partners</p>' +
      '</div>' +
      '<div class="col-md-4 text-right">' +
      '<button class="btn btn-success" id="export-csv-btn">' +
      '<span class="glyphicon glyphicon-download-alt"></span> Export Report' +
      '</button>' +
      '</div>' +
      '</div>' +
      
      this.renderFilters() +
      this.renderMetrics() +
      this.renderTransactions() +
      
      '</div>' +
      '</div>';
    
    $('#app-container').html(html);
    this.updateActiveNav('reporting');
  },
  
  attachEvents: function() {
    var self = this;
    
    // Back button
    $(document).on('click', '#back-to-dashboard', function() {
      App.navigate('dashboard');
    });
    
    // Export button
    $(document).on('click', '#export-csv-btn', function() {
      self.exportToCSV();
    });
    
    // Filter changes
    $(document).on('change', '#filter-partner, #filter-date-range, #filter-voucher, #filter-status', function() {
      self.applyFilters();
    });
    
    // Clear filters
    $(document).on('click', '#clear-filters-btn', function() {
      self.clearFilters();
    });
  },
  
  updateActiveNav: function(view) {
    $('.nav-link').removeClass('active');
    $('.nav-link[data-nav="' + view + '"]').addClass('active');
  },
  
  renderFilters: function() {
    return '<div class="filter-panel">' +
      '<h4>Filters</h4>' +
      '<form class="form-horizontal">' +
      '<div class="row">' +
      '<div class="col-md-3">' +
      '<div class="form-group">' +
      '<label>Partner</label>' +
      '<select class="form-control" id="filter-partner">' +
      '<option value="all">All Partners</option>' +
      AppState.partners.map(function(p) {
        return '<option value="' + p.id + '">' + Helpers.escapeHtml(p.name) + '</option>';
      }).join('') +
      '</select>' +
      '</div>' +
      '</div>' +
      '<div class="col-md-3">' +
      '<div class="form-group">' +
      '<label>Date Range</label>' +
      '<select class="form-control" id="filter-date-range">' +
      '<option value="all">All Time</option>' +
      '<option value="7days">Last 7 Days</option>' +
      '<option value="30days">Last 30 Days</option>' +
      '<option value="90days">Last 90 Days</option>' +
      '</select>' +
      '</div>' +
      '</div>' +
      '<div class="col-md-3">' +
      '<div class="form-group">' +
      '<label>Voucher</label>' +
      '<select class="form-control" id="filter-voucher">' +
      '<option value="all">All Vouchers</option>' +
      '<option value="Monthly Safety Allowance">Monthly Safety Allowance</option>' +
      '</select>' +
      '</div>' +
      '</div>' +
      '<div class="col-md-3">' +
      '<div class="form-group">' +
      '<label>Status</label>' +
      '<select class="form-control" id="filter-status">' +
      '<option value="all">All Statuses</option>' +
      '<option value="Processing">Processing</option>' +
      '<option value="Shipped">Shipped</option>' +
      '<option value="Cancelled">Cancelled</option>' +
      '<option value="Returned">Returned</option>' +
      '</select>' +
      '</div>' +
      '</div>' +
      '</div>' +
      '<div class="row">' +
      '<div class="col-md-12">' +
      '<button type="button" class="btn btn-default" id="clear-filters-btn">Clear Filters</button>' +
      '</div>' +
      '</div>' +
      '</form>' +
      '</div>';
  },
  
  renderMetrics: function() {
    var transactions = this.getFilteredTransactions();
    var totalRevenue = transactions.reduce(function(sum, t) { return sum + t.totalPrice; }, 0);
    var totalTransactions = transactions.length;
    var totalCost = transactions.reduce(function(sum, t) { return sum + t.distributorCost * t.quantity; }, 0);
    var totalProfit = totalRevenue - totalCost;
    
    return '<div class="dashboard-metrics row mb-4">' +
      '<div class="col-md-4">' +
      '<div class="metric-card">' +
      '<div class="metric-header">' +
      '<h4>Total Revenue</h4>' +
      '<span class="glyphicon glyphicon-usd"></span>' +
      '</div>' +
      '<div class="metric-value">' + Helpers.formatCurrency(totalRevenue) + '</div>' +
      '<div class="metric-label">Gross sales</div>' +
      '</div>' +
      '</div>' +
      '<div class="col-md-4">' +
      '<div class="metric-card">' +
      '<div class="metric-header">' +
      '<h4>Total Transactions</h4>' +
      '<span class="glyphicon glyphicon-shopping-cart"></span>' +
      '</div>' +
      '<div class="metric-value">' + totalTransactions + '</div>' +
      '<div class="metric-label">Purchase orders</div>' +
      '</div>' +
      '</div>' +
      '<div class="col-md-4">' +
      '<div class="metric-card">' +
      '<div class="metric-header">' +
      '<h4>Total Profit</h4>' +
      '<span class="glyphicon glyphicon-stats"></span>' +
      '</div>' +
      '<div class="metric-value">' + Helpers.formatCurrency(totalProfit) + '</div>' +
      '<div class="metric-label">' + 
      (totalRevenue > 0 ? ((totalProfit / totalRevenue) * 100).toFixed(1) : 0) + '% margin</div>' +
      '</div>' +
      '</div>' +
      '</div>';
  },
  
  renderTransactions: function() {
    var transactions = this.getFilteredTransactions();
    
    // Group by order ID
    var orderGroups = {};
    transactions.forEach(function(t) {
      if (!orderGroups[t.orderId]) {
        orderGroups[t.orderId] = [];
      }
      orderGroups[t.orderId].push(t);
    });
    
    var ordersHtml = Object.keys(orderGroups).map(function(orderId) {
      var orderItems = orderGroups[orderId];
      var firstItem = orderItems[0];
      var orderTotal = orderItems.reduce(function(sum, item) { return sum + item.totalPrice; }, 0);
      var voucherAmount = firstItem.voucherAmount;
      var paidByVoucher = Math.min(orderTotal, voucherAmount);
      var paidByCreditCard = orderTotal > voucherAmount ? orderTotal - voucherAmount : 0;
      
      return '<div class="transaction-order">' +
        '<div class="order-header">' +
        '<div class="order-info">' +
        '<div class="order-meta">' +
        '<span class="order-id">Order #' + Helpers.escapeHtml(orderId) + '</span>' +
        '<span class="text-muted">' + Helpers.formatDate(firstItem.dateOrdered) + '</span>' +
        '<span class="label label-default">' + Helpers.escapeHtml(firstItem.employeeGroup) + '</span>' +
        '</div>' +
        '<div class="order-totals">' +
        '<div class="total-label">Order Total</div>' +
        '<div class="total-value">' + Helpers.formatCurrency(orderTotal) + '</div>' +
        '</div>' +
        '</div>' +
        '<div><strong>' + Helpers.escapeHtml(firstItem.employeeName) + '</strong> • ' +
        Helpers.escapeHtml(firstItem.partnerName) + '</div>' +
        '<div class="payment-info">' +
        '<span class="payment-method">Payment: ' + Helpers.formatCurrency(paidByVoucher) + ' Voucher' +
        (paidByCreditCard > 0 ? ' + ' + Helpers.formatCurrency(paidByCreditCard) + ' Credit Card' : '') +
        '</span>' +
        '</div>' +
        '</div>' +
        '<div class="order-items">' +
        orderItems.map(function(item) {
          return '<div class="order-item">' +
            '<div class="item-header">' +
            '<span class="status-badge ' + Helpers.getStatusBadgeClass(item.lineStatus) + '">' +
            Helpers.escapeHtml(item.lineStatus) +
            '</span>' +
            '</div>' +
            '<div class="product-details">' +
            '<div class="detail-group">' +
            '<div class="detail-label">Product</div>' +
            '<div class="detail-value">' + Helpers.escapeHtml(item.productName) + '</div>' +
            '</div>' +
            '<div class="detail-group">' +
            '<div class="detail-label">SureWerx Part #</div>' +
            '<div class="detail-value"><code>' + Helpers.escapeHtml(item.surewerxPartNumber) + '</code></div>' +
            '</div>' +
            (item.distributorPartNumber ?
              '<div class="detail-group">' +
              '<div class="detail-label">Distributor Part #</div>' +
              '<div class="detail-value"><code>' + Helpers.escapeHtml(item.distributorPartNumber) + '</code></div>' +
              '</div>' : '') +
            '<div class="detail-group">' +
            '<div class="detail-label">Quantity</div>' +
            '<div class="detail-value">' + item.quantity + '</div>' +
            '</div>' +
            '</div>' +
            '<div class="financial-details">' +
            '<div class="detail-group">' +
            '<div class="detail-label">Unit Price</div>' +
            '<div class="detail-value">' + Helpers.formatCurrency(item.unitPrice) + '</div>' +
            '</div>' +
            '<div class="detail-group">' +
            '<div class="detail-label">Line Total</div>' +
            '<div class="detail-value"><strong>' + Helpers.formatCurrency(item.totalPrice) + '</strong></div>' +
            '</div>' +
            '<div class="detail-group">' +
            '<div class="detail-label">Distributor Cost</div>' +
            '<div class="detail-value text-muted">' + Helpers.formatCurrency(item.distributorCost * item.quantity) + '</div>' +
            '</div>' +
            '</div>' +
            '</div>';
        }).join('') +
        '</div>' +
        '</div>';
    }).join('');
    
    return '<div class="panel panel-default">' +
      '<div class="panel-heading">' +
      '<h3 class="panel-title">Purchase Transactions</h3>' +
      '</div>' +
      '<div class="panel-body">' +
      (ordersHtml || '<p class="text-muted">No transactions found for the selected filters.</p>') +
      '</div>' +
      '</div>';
  },
  
  getFilteredTransactions: function() {
    var transactions = AppState.transactions;
    var filters = this.filters;
    
    return transactions.filter(function(t) {
      if (filters.partner !== 'all') {
        var partner = AppState.partners.find(function(p) { return p.id === filters.partner; });
        if (!partner || t.partnerName !== partner.name) {
          return false;
        }
      }
      
      if (filters.voucher !== 'all' && t.voucherUsed !== filters.voucher) {
        return false;
      }
      
      if (filters.status !== 'all' && t.lineStatus !== filters.status) {
        return false;
      }
      
      // Date range filter
      if (filters.dateRange !== 'all') {
        var transactionDate = new Date(t.dateOrdered);
        var today = new Date();
        var daysDiff = Math.floor((today - transactionDate) / (1000 * 60 * 60 * 24));
        
        if (filters.dateRange === '7days' && daysDiff > 7) return false;
        if (filters.dateRange === '30days' && daysDiff > 30) return false;
        if (filters.dateRange === '90days' && daysDiff > 90) return false;
      }
      
      return true;
    });
  },
  
  applyFilters: function() {
    this.filters.partner = $('#filter-partner').val();
    this.filters.dateRange = $('#filter-date-range').val();
    this.filters.voucher = $('#filter-voucher').val();
    this.filters.status = $('#filter-status').val();
    
    // Re-render metrics and transactions
    $('.dashboard-metrics').replaceWith(this.renderMetrics());
    $('.panel-default').last().replaceWith(this.renderTransactions());
  },
  
  clearFilters: function() {
    this.filters = {
      partner: 'all',
      dateRange: 'all',
      voucher: 'all',
      status: 'all'
    };
    
    $('#filter-partner').val('all');
    $('#filter-date-range').val('all');
    $('#filter-voucher').val('all');
    $('#filter-status').val('all');
    
    this.applyFilters();
    Helpers.showAlert('Filters cleared', 'success');
  },
  
  exportToCSV: function() {
    var transactions = this.getFilteredTransactions();
    
    var csvData = transactions.map(function(t) {
      return {
        'Order ID': t.orderId,
        'Date': t.dateOrdered,
        'Employee': t.employeeName,
        'Email': t.employeeEmail,
        'Group': t.employeeGroup,
        'Partner': t.partnerName,
        'Product': t.productName,
        'SureWerx Part #': t.surewerxPartNumber,
        'Distributor Part #': t.distributorPartNumber || 'N/A',
        'Quantity': t.quantity,
        'Unit Price': t.unitPrice.toFixed(2),
        'Total': t.totalPrice.toFixed(2),
        'Status': t.lineStatus
      };
    });
    
    Helpers.exportToCSV(csvData, 'purchase-report-' + new Date().toISOString().split('T')[0] + '.csv');
  }
};