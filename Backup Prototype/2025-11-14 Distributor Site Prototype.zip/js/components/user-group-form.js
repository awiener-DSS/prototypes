// User Group Form Component - Full Page
var UserGroupFormComponent = {
  partnerId: null,
  groupId: null,
  partner: null,
  group: null,
  selectedProductIds: [],
  currentCategory: 'all',
  searchQuery: '',
  
  init: function(partnerId, groupId) {
    this.partnerId = partnerId;
    this.groupId = groupId || null;
    this.partner = AppState.partners.find(function(p) { return p.id === partnerId; });
    
    if (!this.partner) {
      Helpers.showAlert('Partner not found', 'danger');
      App.navigate('dashboard');
      return;
    }
    
    this.group = groupId ? this.partner.groups.find(function(g) { return g.id === groupId; }) : null;
    this.selectedProductIds = this.group ? (this.group.productIds || []) : [];
    
    this.render();
    this.attachEvents();
    this.updateProductList();
    this.updateCategoryFilters();
  },
  
  render: function() {
    var self = this;
    var isEdit = !!this.group;
    
    var html = Templates.header() +
      '<div class="container">' +
      
      // Back button
      '<button class="btn btn-default" id="back-to-partner" style="margin-bottom: 20px;">' +
      '<span class="glyphicon glyphicon-chevron-left"></span> Back to User Groups' +
      '</button>' +
      
      // Page Title
      '<div style="margin-bottom: 30px;">' +
      '<h2>' + (isEdit ? 'Edit User Group' : 'Create User Group') + '</h2>' +
      '<p class="text-muted">' + 
      (isEdit ? 'Update group information and product visibility' : 'Create a new user group and assign product visibility') +
      '</p>' +
      '</div>' +
      
      // Form Card
      '<div class="panel panel-default">' +
      '<div class="panel-body" style="padding: 30px;">' +
      '<form id="user-group-form">' +
      
      // Basic Information Section
      '<div style="margin-bottom: 30px;">' +
      '<h4 style="margin-bottom: 20px; border-bottom: 1px solid #e0e0e0; padding-bottom: 10px;">Basic Information</h4>' +
      
      '<div class="form-group">' +
      '<label for="group-name">Group Name <span class="text-danger">*</span></label>' +
      '<input type="text" class="form-control" id="group-name" ' +
      'placeholder="e.g., Engineering Team, Sales Department" ' +
      'value="' + (this.group ? Helpers.escapeHtml(this.group.name) : '') + '" required>' +
      '</div>' +
      
      '<div class="form-group">' +
      '<label for="group-department">Department (Optional)</label>' +
      '<input type="text" class="form-control" id="group-department" ' +
      'placeholder="e.g., Engineering, Sales, Operations" ' +
      'value="' + (this.group ? Helpers.escapeHtml(this.group.department || '') : '') + '\">' +
      '</div>' +
      
      '<div class="form-group">' +
      '<label for="group-location">Location (Optional)</label>' +
      '<input type="text" class="form-control" id="group-location" ' +
      'placeholder="e.g., New York Office, Warehouse A, Remote" ' +
      'value="' + (this.group ? Helpers.escapeHtml(this.group.location || '') : '') + '\">' +
      '</div>' +
      '</div>' +
      
      // Product Visibility Section
      '<div style="margin-bottom: 30px; padding-top: 30px; border-top: 1px solid #e0e0e0;">' +
      '<div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 20px;">' +
      '<div>' +
      '<h4 style="margin: 0 0 5px 0;">Product Visibility</h4>' +
      '<p class="text-muted" style="margin: 0; font-size: 13px;">Select which products this user group can access</p>' +
      '</div>' +
      '<button type="button" class="btn btn-default btn-sm" id="toggle-all-products">Select All</button>' +
      '</div>' +
      
      // Selected Products Display
      '<div id="selected-products-display" style="display: none; margin-bottom: 15px; padding: 15px; background-color: #f5f5f5; border: 1px solid #e0e0e0; border-radius: 4px;">' +
      '<div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">' +
      '<p style="margin: 0; font-size: 12px; color: #666;">Selected Products (<span id="selected-count">0</span>)</p>' +
      '</div>' +
      '<div id="selected-products-badges" style="display: flex; flex-wrap: wrap; gap: 8px;"></div>' +
      '</div>' +
      
      // Search and Filter
      '<div style="margin-bottom: 15px;">' +
      '<div style="position: relative; margin-bottom: 15px;">' +
      '<span class="glyphicon glyphicon-search" style="position: absolute; left: 10px; top: 10px; color: #999;"></span>' +
      '<input type="text" class="form-control" id="product-search" ' +
      'placeholder="Search products by name, category, or SKU..." ' +
      'style="padding-left: 35px;">' +
      '</div>' +
      
      // Category Filter Badges
      '<div id="category-filters" style="display: flex; flex-wrap: wrap; gap: 8px;"></div>' +
      '</div>' +
      
      // Product List (scrollable)
      '<div style="border: 1px solid #ddd; border-radius: 4px; max-height: 500px; overflow-y: auto;">' +
      '<div id="product-list" style="padding: 15px;"></div>' +
      '</div>' +
      '</div>' +
      
      // Form Actions
      '<div style="display: flex; gap: 10px; padding-top: 20px;">' +
      '<button type="button" class="btn btn-default" id="cancel-group-form">Cancel</button>' +
      '<button type="submit" class="btn btn-primary">' + (isEdit ? 'Save Changes' : 'Create Group') + '</button>' +
      '</div>' +
      
      '</form>' +
      '</div>' +
      '</div>' +
      '</div>';
    
    $('#app-container').html(html);
  },
  
  attachEvents: function() {
    var self = this;
    
    // Back button
    $('#back-to-partner').on('click', function() {
      App.navigate('partner-detail', { partnerId: self.partnerId, tab: 'groups' });
    });
    
    // Cancel button
    $('#cancel-group-form').on('click', function() {
      App.navigate('partner-detail', { partnerId: self.partnerId, tab: 'groups' });
    });
    
    // Form submission
    $('#user-group-form').on('submit', function(e) {
      e.preventDefault();
      self.handleSubmit();
    });
    
    // Toggle all products
    $('#toggle-all-products').on('click', function() {
      if (self.selectedProductIds.length === AppState.products.length) {
        self.selectedProductIds = [];
        $(this).text('Select All');
      } else {
        self.selectedProductIds = AppState.products.map(function(p) { return p.id; });
        $(this).text('Deselect All');
      }
      self.updateProductList();
      self.updateSelectedDisplay();
    });
    
    // Search
    $('#product-search').on('input', function() {
      self.searchQuery = $(this).val().toLowerCase();
      self.updateProductList();
    });
    
    // Product checkboxes (delegated)
    $(document).off('change', '.product-checkbox').on('change', '.product-checkbox', function() {
      var productId = $(this).data('product-id');
      self.toggleProduct(productId);
    });
    
    // Category filter click (delegated)
    $(document).off('click', '.category-badge').on('click', '.category-badge', function() {
      self.currentCategory = $(this).data('category');
      self.updateCategoryFilters();
      self.updateProductList();
    });
  },
  
  toggleProduct: function(productId) {
    var index = this.selectedProductIds.indexOf(productId);
    if (index > -1) {
      this.selectedProductIds.splice(index, 1);
    } else {
      this.selectedProductIds.push(productId);
    }
    
    this.updateProductList();
    this.updateSelectedDisplay();
    
    // Update toggle button text
    if (this.selectedProductIds.length === AppState.products.length) {
      $('#toggle-all-products').text('Deselect All');
    } else {
      $('#toggle-all-products').text('Select All');
    }
  },
  
  updateCategoryFilters: function() {
    // Get unique categories
    var categories = ['all'];
    AppState.products.forEach(function(p) {
      if (categories.indexOf(p.category) === -1) {
        categories.push(p.category);
      }
    });
    
    var html = '';
    categories.forEach(function(category) {
      var isActive = this.currentCategory === category;
      html += '<span class="badge category-badge ' + (isActive ? 'badge-primary' : 'badge-default') + '" ' +
        'data-category="' + category + '" ' +
        'style="cursor: pointer; padding: 6px 12px; ' + 
        (isActive ? 'background-color: #337ab7; color: white;' : 'background-color: white; color: #777; border: 1px solid #ddd;') + '">' +
        (category === 'all' ? 'All Categories' : category) +
        '</span>';
    }.bind(this));
    
    $('#category-filters').html(html);
  },
  
  updateProductList: function() {
    var self = this;
    
    // Filter products
    var filteredProducts = AppState.products.filter(function(product) {
      var matchesSearch = self.searchQuery === '' ||
        product.name.toLowerCase().indexOf(self.searchQuery) > -1 ||
        product.category.toLowerCase().indexOf(self.searchQuery) > -1 ||
        product.surewerxSku.toLowerCase().indexOf(self.searchQuery) > -1;
      
      var matchesCategory = self.currentCategory === 'all' || product.category === self.currentCategory;
      
      return matchesSearch && matchesCategory;
    });
    
    var html = '';
    
    if (filteredProducts.length === 0) {
      html = '<div style="text-center; padding: 40px; color: #999;">' +
        '<span class="glyphicon glyphicon-inbox" style="font-size: 40px; display: block; margin-bottom: 10px;"></span>' +
        '<p>No products found</p>' +
        '</div>';
    } else {
      html = '<div style="display: flex; flex-direction: column; gap: 10px;">';
      
      filteredProducts.forEach(function(product) {
        var isSelected = self.selectedProductIds.indexOf(product.id) > -1;
        var price = product.partnerOverridePrice || product.price;
        
        html += '<div class="product-item" style="display: flex; align-items: center; gap: 15px; padding: 12px; border: 1px solid ' + 
          (isSelected ? '#5bc0de' : '#ddd') + '; border-radius: 4px; cursor: pointer; background-color: ' + 
          (isSelected ? '#f0f8ff' : 'white') + ';" data-product-id="' + product.id + '">' +
          '<input type="checkbox" class="product-checkbox" data-product-id="' + product.id + '" ' + 
          (isSelected ? 'checked' : '') + ' style="width: 16px; height: 16px;">' +
          '<div style="flex: 1; min-width: 0;">' +
          '<div style="display: flex; align-items: center; gap: 8px;">' +
          '<p style="margin: 0; font-size: 14px;">' + Helpers.escapeHtml(product.name) + '</p>' +
          (isSelected ? '<span class="glyphicon glyphicon-ok text-primary"></span>' : '') +
          '</div>' +
          '<div style="display: flex; align-items: center; gap: 10px; margin-top: 5px;">' +
          '<span class="label label-default" style="font-size: 11px;">' + Helpers.escapeHtml(product.category) + '</span>' +
          '<span style="font-size: 11px; color: #999;">SKU: ' + Helpers.escapeHtml(product.surewerxSku) + '</span>' +
          '</div>' +
          '</div>' +
          '<div style="font-size: 14px; color: #333;">' +
          Helpers.formatCurrency(price) +
          '</div>' +
          '</div>';
      });
      
      html += '</div>';
    }
    
    $('#product-list').html(html);
    
    // Add click handlers for product items
    $('.product-item').on('click', function() {
      var productId = $(this).data('product-id');
      var checkbox = $(this).find('.product-checkbox');
      checkbox.prop('checked', !checkbox.prop('checked'));
      self.toggleProduct(productId);
    });
  },
  
  updateSelectedDisplay: function() {
    var self = this;
    
    if (this.selectedProductIds.length === 0) {
      $('#selected-products-display').hide();
      return;
    }
    
    $('#selected-products-display').show();
    $('#selected-count').text(this.selectedProductIds.length);
    
    var html = '';
    this.selectedProductIds.forEach(function(productId) {
      var product = AppState.products.find(function(p) { return p.id === productId; });
      if (product) {
        html += '<span class="label label-info" style="padding: 6px 10px; font-size: 12px; display: inline-flex; align-items: center; gap: 6px;">' +
          Helpers.escapeHtml(product.name) +
          '<button type="button" class="remove-product-badge" data-product-id="' + productId + '" ' +
          'style="background: none; border: none; color: white; padding: 0; margin-left: 4px; cursor: pointer; font-size: 14px;">' +
          '<span class="glyphicon glyphicon-remove"></span>' +
          '</button>' +
          '</span>';
      }
    });
    
    $('#selected-products-badges').html(html);
    
    // Add click handler for remove buttons
    $('.remove-product-badge').on('click', function(e) {
      e.stopPropagation();
      var productId = $(this).data('product-id');
      self.toggleProduct(productId);
    });
  },
  
  handleSubmit: function() {
    var self = this;
    
    var name = $('#group-name').val().trim();
    if (!name) {
      Helpers.showAlert('Group name is required', 'warning');
      return;
    }
    
    var groupData = {
      name: name,
      department: $('#group-department').val().trim() || '',
      location: $('#group-location').val().trim() || '',
      productIds: this.selectedProductIds
    };
    
    if (this.group) {
      // Edit existing group
      var updatedGroups = this.partner.groups.map(function(g) {
        if (g.id === self.group.id) {
          return Object.assign({}, g, groupData);
        }
        return g;
      });
      
      AppState.updatePartner(this.partnerId, { groups: updatedGroups });
      Helpers.showAlert('Group updated successfully', 'success');
    } else {
      // Create new group
      var newGroup = Object.assign({}, groupData, {
        id: Helpers.generateId(),
        employeeCount: 0
      });
      
      var updatedGroups = this.partner.groups.concat([newGroup]);
      AppState.updatePartner(this.partnerId, { groups: updatedGroups });
      Helpers.showAlert('Group created successfully', 'success');
    }
    
    App.navigate('partner-detail', { partnerId: this.partnerId, tab: 'groups' });
  }
};