// Extended employee modal templates

Templates.showEditEmployeeModal = function(partner, employee, partnerId) {
  console.log('Edit Employee Modal - Partner Config:', partner.employeeFieldConfig);
  console.log('Edit Employee Modal - Employee Data:', employee);
  
  var modalHtml = '<div class="modal fade" id="edit-employee-modal" tabindex="-1">' +
    '<div class="modal-dialog">' +
    '<div class="modal-content">' +
    '<div class="modal-header">' +
    '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
    '<h4 class="modal-title">Edit Employee</h4>' +
    '</div>' +
    '<form id="edit-employee-form">' +
    '<div class="modal-body">' +
    '<div class="form-group">' +
    '<label>First Name *</label>' +
    '<input type="text" class="form-control" id="edit-employee-first-name" value="' + Helpers.escapeHtml(employee.firstName || employee.name.split(' ')[0] || '') + '" required>' +
    '</div>' +
    '<div class="form-group">' +
    '<label>Last Name *</label>' +
    '<input type="text" class="form-control" id="edit-employee-last-name" value="' + Helpers.escapeHtml(employee.lastName || employee.name.split(' ').slice(1).join(' ') || '') + '" required>' +
    '</div>';
  
  // Conditionally add Employee ID field
  if (partner.employeeFieldConfig.requireEmployeeId) {
    modalHtml += '<div class="form-group">' +
      '<label>Employee ID *</label>' +
      '<input type="text" class="form-control" id="edit-employee-id" value="' + Helpers.escapeHtml(employee.employeeId || '') + '" required>' +
      '</div>';
  }
  
  // Conditionally add Username field
  if (partner.employeeFieldConfig.requireUsername) {
    modalHtml += '<div class="form-group">' +
      '<label>Username *</label>' +
      '<input type="text" class="form-control" id="edit-employee-username" value="' + Helpers.escapeHtml(employee.username || '') + '" required>' +
      '</div>';
  }
  
  // Conditionally add Date of Birth field
  if (partner.employeeFieldConfig.requireDateOfBirth) {
    modalHtml += '<div class="form-group">' +
      '<label>Date of Birth *</label>' +
      '<input type="date" class="form-control" id="edit-employee-dob" value="' + (employee.dateOfBirth || '') + '" required>' +
      '</div>';
  }
  
  // Conditionally add Start Date field
  if (partner.employeeFieldConfig.requireStartDate) {
    modalHtml += '<div class="form-group">' +
      '<label>Start Date *</label>' +
      '<input type="date" class="form-control" id="edit-employee-start-date" value="' + (employee.startDate || '') + '" required>' +
      '</div>';
  }
  
  // User Group (always shown)
  modalHtml += '<div class="form-group">' +
    '<label>User Group *</label>' +
    '<select class="form-control" id="edit-employee-group" required>' +
    partner.groups.map(function(g) {
      var groupVouchers = partner.vouchers.filter(function(v) {
        return v.userGroupIds && v.userGroupIds.indexOf(g.id) > -1;
      });
      var totalAmount = groupVouchers.reduce(function(sum, v) { return sum + v.defaultAmount; }, 0);
      var selected = g.id === employee.groupId ? ' selected' : '';
      return '<option value="' + g.id + '"' + selected + '>' +
        Helpers.escapeHtml(g.name) + ' - $' + totalAmount.toFixed(2) + ' (' + groupVouchers.length + ' vouchers)' +
        '</option>';
    }).join('') +
    '</select>' +
    '</div>';
  
  // Notes (always shown)
  modalHtml += '<div class="form-group">' +
    '<label>Notes</label>' +
    '<textarea class="form-control" id="edit-employee-notes" rows="3" placeholder="Optional notes about this employee...">' + Helpers.escapeHtml(employee.notes || '') + '</textarea>' +
    '</div>' +
    '</div>' +
    '<div class="modal-footer">' +
    '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
    '<button type="submit" class="btn btn-primary">Save Changes</button>' +
    '</div>' +
    '</form>' +
    '</div>' +
    '</div>' +
    '</div>';
  
  $('body').append(modalHtml);
  $('#edit-employee-modal').modal('show');
  
  $(document).off('submit', '#edit-employee-form').on('submit', '#edit-employee-form', function(e) {
    e.preventDefault();
    
    var firstName = $('#edit-employee-first-name').val();
    var lastName = $('#edit-employee-last-name').val();
    var newGroupId = $('#edit-employee-group').val();
    var oldGroupId = employee.groupId;
    
    var updatedEmployeeData = {
      firstName: firstName,
      lastName: lastName,
      name: firstName + ' ' + lastName,
      groupId: newGroupId,
      notes: $('#edit-employee-notes').val() || ''
    };
    
    // Only update fields that are configured for this partner
    if (partner.employeeFieldConfig.requireEmployeeId) {
      updatedEmployeeData.employeeId = $('#edit-employee-id').val();
    }
    
    if (partner.employeeFieldConfig.requireUsername) {
      updatedEmployeeData.username = $('#edit-employee-username').val();
    }
    
    if (partner.employeeFieldConfig.requireDateOfBirth) {
      updatedEmployeeData.dateOfBirth = $('#edit-employee-dob').val();
    }
    
    if (partner.employeeFieldConfig.requireStartDate) {
      updatedEmployeeData.startDate = $('#edit-employee-start-date').val();
    }
    
    // If group changed, update voucher balances
    if (newGroupId !== oldGroupId) {
      var groupVouchers = partner.vouchers.filter(function(v) {
        return v.userGroupIds && v.userGroupIds.indexOf(newGroupId) > -1;
      });
      
      var totalBalance = groupVouchers.reduce(function(sum, v) { return sum + v.defaultAmount; }, 0);
      var voucherBalances = groupVouchers.map(function(v) {
        return {
          voucherId: v.id,
          remainingAmount: v.defaultAmount
        };
      });
      var voucherExpiry = groupVouchers.length > 0 ? groupVouchers[0].endDate : '';
      
      updatedEmployeeData.voucherBalances = voucherBalances;
      updatedEmployeeData.remainingBalance = totalBalance;
      updatedEmployeeData.voucherExpiry = voucherExpiry;
    }
    
    console.log('Updating employee with data:', updatedEmployeeData);
    
    // Update employee
    var updatedEmployees = partner.employees.map(function(e) {
      if (e.id === employee.id) {
        return Object.assign({}, e, updatedEmployeeData);
      }
      return e;
    });
    
    // Update employee counts in groups
    var updatedGroups = partner.groups.map(function(group) {
      var count = updatedEmployees.filter(function(e) { return e.groupId === group.id; }).length;
      return Object.assign({}, group, { employeeCount: count });
    });
    
    AppState.updatePartner(partnerId, {
      employees: updatedEmployees,
      groups: updatedGroups
    });
    
    $('#edit-employee-modal').modal('hide');
    PartnerDetailComponent.renderTabContent('employees');
    Helpers.showAlert('Employee updated successfully', 'success');
  });
  
  $('#edit-employee-modal').on('hidden.bs.modal', function() {
    $(this).remove();
  });
};
