// Enhanced Employee Table Template

Templates.renderEmployeesTabEnhanced = function(partner) {
  var html = '<div class="row">' +
    '<div class="col-md-12">';
  
  // Help Section - How Employee Management Works
  html += '<div class="alert alert-info" style="background-color: #e3f2fd; border-color: #90caf9; margin-bottom: 20px;">' +
    '<div style="display: flex; align-items: start; gap: 15px;">' +
    '<div style="background-color: #bbdefb; padding: 10px; border-radius: 4px; flex-shrink: 0;">' +
    '<span class="glyphicon glyphicon-info-sign" style="font-size: 20px; color: #1976d2;"></span>' +
    '</div>' +
    '<div style="flex: 1;">' +
    '<h4 style="margin: 0 0 8px 0; color: #0d47a1; font-size: 14px; font-weight: 600;">How Employee Management Works</h4>' +
    '<p style="margin: 0; color: #1565c0; font-size: 13px; line-height: 1.5;">' +
    'Add individual employees to this partner by entering their details such as name and configured fields like Employee ID, Username, or date of birth. ' +
    'Each employee is automatically assigned to the "Default Group" when created, and you can later reassign them to different user groups as needed. ' +
    'Use the bulk upload feature to add multiple employees at once from a CSV file.' +
    '</p>' +
    '</div>' +
    '</div>' +
    '</div>';
  
  // Employees section only - full width
  html += '<div class="mb-4">' +
    '<div class="btn-toolbar">' +
    '<button class="btn btn-primary" id="add-employee-btn">' +
    '<span class="glyphicon glyphicon-plus"></span> Add Employee' +
    '</button> ' +
    '<button class="btn btn-primary" id="bulk-import-btn">' +
    '<span class="glyphicon glyphicon-upload"></span> Bulk Import' +
    '</button> ' +
    '<button class="btn btn-default" id="export-employees-btn">' +
    '<span class="glyphicon glyphicon-download-alt"></span> Export to CSV' +
    '</button>' +
    '</div>' +
    '</div>';
  
  // Bulk actions toolbar (hidden by default)
  html += '<div id="bulk-actions-toolbar" class="alert alert-info" style="display: none;">' +
    '<div class="row">' +
    '<div class="col-sm-6">' +
    '<strong><span id="selected-count">0</span> employee(s) selected</strong>' +
    '</div>' +
    '<div class="col-sm-6 text-right">' +
    '<button class="btn btn-sm btn-primary" id="bulk-change-group-btn">' +
    '<span class="glyphicon glyphicon-transfer"></span> Change Group' +
    '</button> ' +
    '<button class="btn btn-sm btn-default" id="clear-selection-btn">' +
    '<span class="glyphicon glyphicon-remove"></span> Clear Selection' +
    '</button>' +
    '</div>' +
    '</div>' +
    '</div>';
  
  if (partner.employees.length > 0) {
    // Sort employees if needed
    var employees = partner.employees;
    if (EmployeeTableEnhanced.sortColumn) {
      employees = EmployeeTableEnhanced.sortEmployees(employees);
    }
    
    html += '<div class="table-responsive">' +
      '<table class="table table-hover">' +
      '<thead>' +
      '<tr>' +
      '<th style="width: 30px;">' +
      '<input type="checkbox" id="select-all-employees">' +
      '</th>' +
      '<th style="cursor: pointer;" class="sortable-column" data-column="name">' +
      'Name ' + EmployeeTableEnhanced.getSortIcon('name') +
      '</th>' +
      (partner.employeeFieldConfig.requireEmployeeId ? 
        '<th style="cursor: pointer;" class="sortable-column" data-column="employeeId">' +
        'Employee ID ' + EmployeeTableEnhanced.getSortIcon('employeeId') +
        '</th>' : '') +
      (partner.employeeFieldConfig.requireUsername ? 
        '<th style="cursor: pointer;" class="sortable-column" data-column="username">' +
        'Username ' + EmployeeTableEnhanced.getSortIcon('username') +
        '</th>' : '') +
      (partner.employeeFieldConfig.requireDateOfBirth ? 
        '<th style="cursor: pointer;" class="sortable-column" data-column="dateOfBirth">' +
        'Date of Birth ' + EmployeeTableEnhanced.getSortIcon('dateOfBirth') +
        '</th>' : '') +
      (partner.employeeFieldConfig.requireStartDate ? 
        '<th style="cursor: pointer;" class="sortable-column" data-column="startDate">' +
        'Start Date ' + EmployeeTableEnhanced.getSortIcon('startDate') +
        '</th>' : '') +
      '<th style="cursor: pointer;" class="sortable-column" data-column="group">' +
      'Group ' + EmployeeTableEnhanced.getSortIcon('group') +
      '</th>' +
      '<th style="cursor: pointer;" class="sortable-column" data-column="notes">' +
      'Notes ' + EmployeeTableEnhanced.getSortIcon('notes') +
      '</th>' +
      '<th style="width: 120px;">Actions</th>' +
      '</tr>' +
      '</thead>' +
      '<tbody>';
    
    employees.forEach(function(emp) {
      var group = partner.groups.find(function(g) { return g.id === emp.groupId; });
      
      html += '<tr>' +
        '<td>' +
        '<input type="checkbox" class="employee-checkbox" data-employee-id="' + emp.id + '">' +
        '</td>' +
        '<td>' + Helpers.escapeHtml(emp.firstName ? emp.firstName + ' ' + emp.lastName : emp.name) + '</td>' +
        (partner.employeeFieldConfig.requireEmployeeId ? 
          '<td>' + Helpers.escapeHtml(emp.employeeId || '') + '</td>' : '') +
        (partner.employeeFieldConfig.requireUsername ? 
          '<td>' + Helpers.escapeHtml(emp.username || '') + '</td>' : '') +
        (partner.employeeFieldConfig.requireDateOfBirth ? 
          '<td>' + Helpers.formatDate(emp.dateOfBirth || '') + '</td>' : '') +
        (partner.employeeFieldConfig.requireStartDate ? 
          '<td>' + Helpers.formatDate(emp.startDate || '') + '</td>' : '') +
        '<td>' + (group ? Helpers.escapeHtml(group.name) : '-') + '</td>' +
        '<td>' + (emp.notes ? Helpers.escapeHtml(emp.notes) : '-') + '</td>' +
        '<td>' +
        '<div class="btn-group btn-group-xs">' +
        '<button class="btn btn-default edit-employee-btn" data-employee-id="' + emp.id + '" title="Edit" style="padding: 5px 10px; background-color: transparent; border-color: transparent; color: #6b7280;">' +
        '<span class="glyphicon glyphicon-pencil"></span>' +
        '</button>' +
        '<button class="btn btn-default delete-employee-btn" data-employee-id="' + emp.id + '" title="Delete" style="padding: 5px 10px; background-color: transparent; border-color: transparent; color: #dc2626;">' +
        '<span class="glyphicon glyphicon-trash"></span>' +
        '</button>' +
        '</div>' +
        '</td>' +
        '</tr>';
    });
    
    html += '</tbody></table></div>';
  } else {
    html += '<div class="alert alert-info">No employees added yet. Click "Add Employee" to get started.</div>';
  }
  
  html += '</div></div>';
  
  return html;
};