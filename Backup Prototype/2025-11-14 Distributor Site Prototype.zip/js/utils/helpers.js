// Helper utility functions

var Helpers = {
  // Format currency
  formatCurrency: function(value) {
    return '$' + parseFloat(value).toFixed(2).replace(/\d(?=(\d{3})+\.)/g, '$&,');
  },
  
  // Format date
  formatDate: function(dateString) {
    var date = new Date(dateString);
    return date.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'short', 
      day: 'numeric' 
    });
  },
  
  // Format number with commas
  formatNumber: function(value) {
    return parseInt(value, 10).toLocaleString();
  },
  
  // Escape HTML entities to prevent XSS
  escapeHtml: function(text) {
    if (text === null || text === undefined) {
      return '';
    }
    var map = {
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#039;'
    };
    return text.toString().replace(/[&<>"']/g, function(m) { return map[m]; });
  },
  
  // Generate unique ID
  generateId: function() {
    return 'id-' + Math.random().toString(36).substr(2, 9);
  },
  
  // Show alert message
  showAlert: function(message, type, targetElement) {
    // Remove existing alerts first
    $('.contextual-alert').remove();
    
    // If no target element, show at top (fallback)
    if (!targetElement) {
      if ($('.app-alert-container').length === 0) {
        $('body').append('<div class="app-alert-container"></div>');
      }
      
      var alertHtml = '<div class="alert alert-' + (type || 'info') + ' alert-dismissible fade-in" role="alert" style="margin-bottom: 10px;">' +
        '<button type="button" class="close" data-dismiss="alert" aria-label="Close">' +
        '<span aria-hidden="true">&times;</span>' +
        '</button>' +
        '<span class="glyphicon glyphicon-' + (type === 'success' ? 'ok-sign' : type === 'danger' ? 'exclamation-sign' : type === 'warning' ? 'warning-sign' : 'info-sign') + '"></span> ' +
        Helpers.escapeHtml(message) +
        '</div>';
      
      $('.app-alert-container').append(alertHtml);
      
      setTimeout(function() {
        $('.app-alert-container .alert').addClass('fade-out');
        setTimeout(function() {
          $('.app-alert-container .alert').remove();
        }, 300);
      }, 4000);
      return;
    }
    
    // Show contextual alert near the target element
    var $target = $(targetElement);
    var iconClass = type === 'success' ? 'ok-sign' : type === 'danger' ? 'exclamation-sign' : type === 'warning' ? 'warning-sign' : 'info-sign';
    
    var alertHtml = '<div class="contextual-alert alert alert-' + (type || 'info') + ' fade-in" role="alert">' +
      '<span class="glyphicon glyphicon-' + iconClass + '"></span> ' +
      Helpers.escapeHtml(message) +
      '</div>';
    
    // Find the best container (form, modal body, or panel body)
    var $container = $target.closest('.modal-body, .panel-body, form, .container, .container-fluid');
    if ($container.length === 0) {
      $container = $target.parent();
    }
    
    // Position alert after the target element or its parent
    var $insertAfter = $target.is('button, a') ? $target.parent() : $target;
    $insertAfter.after(alertHtml);
    
    var $alert = $insertAfter.next('.contextual-alert');
    
    // Auto dismiss after 4 seconds
    setTimeout(function() {
      $alert.addClass('fade-out');
      setTimeout(function() {
        $alert.remove();
      }, 300);
    }, 4000);
  },
  
  // Get status badge class
  getStatusBadgeClass: function(status) {
    var map = {
      'Processing': 'status-processing',
      'Shipped': 'status-shipped',
      'Cancelled': 'status-cancelled',
      'Returned': 'status-returned',
      'Active': 'label-success',
      'Inactive': 'label-default'
    };
    return map[status] || 'label-default';
  },
  
  // Debounce function
  debounce: function(func, wait) {
    var timeout;
    return function() {
      var context = this;
      var args = arguments;
      clearTimeout(timeout);
      timeout = setTimeout(function() {
        func.apply(context, args);
      }, wait);
    };
  },
  
  // Export to CSV
  exportToCSV: function(data, filename) {
    if (!data || !data.length) {
      Helpers.showAlert('No data to export', 'warning');
      return;
    }
    
    // Get headers from first object
    var headers = Object.keys(data[0]);
    
    // Build CSV content
    var csvContent = headers.join(',') + '\n';
    
    data.forEach(function(row) {
      var values = headers.map(function(header) {
        var val = row[header];
        // Escape quotes and wrap in quotes if contains comma
        if (typeof val === 'string' && (val.indexOf(',') > -1 || val.indexOf('"') > -1)) {
          val = '"' + val.replace(/"/g, '""') + '"';
        }
        return val;
      });
      csvContent += values.join(',') + '\n';
    });
    
    // Create download link
    var blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    var link = document.createElement('a');
    if (link.download !== undefined) {
      var url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', filename || 'export.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      Helpers.showAlert('Export successful', 'success');
    }
  }
};