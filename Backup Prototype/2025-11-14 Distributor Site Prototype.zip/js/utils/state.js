// Global Application State
var AppState = {
  isLoggedIn: false,
  currentUser: null,
  currentView: 'login',
  currentPartnerId: null,
  currentTab: 'employees',
  distributorName: 'My Distributor',
  distributorLogo: null,
  partners: [],
  transactions: [],
  users: [],
  products: [],
  
  // Initialize state
  init: function() {
    this.loadFromStorage();
    this.initializeData();
  },
  
  // Load state from localStorage
  loadFromStorage: function() {
    var stored = localStorage.getItem('appState');
    if (stored) {
      var parsed = JSON.parse(stored);
      this.isLoggedIn = parsed.isLoggedIn || false;
      this.currentUser = parsed.currentUser || null;
      // Load partners from localStorage if they exist
      if (parsed.partners && Array.isArray(parsed.partners) && parsed.partners.length > 0) {
        this.partners = parsed.partners;
      }
    }
  },
  
  // Save state to localStorage
  saveToStorage: function() {
    var toSave = {
      isLoggedIn: this.isLoggedIn,
      currentUser: this.currentUser,
      partners: this.partners
    };
    localStorage.setItem('appState', JSON.stringify(toSave));
  },
  
  // Save partners to localStorage
  savePartners: function() {
    var stored = localStorage.getItem('appState');
    var toSave = stored ? JSON.parse(stored) : {};
    toSave.partners = this.partners;
    localStorage.setItem('appState', JSON.stringify(toSave));
  },
  
  // Login user
  login: function(email, password) {
    // Find user in mock data
    var user = this.users.find(function(u) {
      return u.email === email && u.password === password;
    });
    
    if (user) {
      this.isLoggedIn = true;
      this.currentUser = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        partnerId: user.partnerId
      };
      this.saveToStorage();
      return true;
    }
    return false;
  },
  
  // Logout user
  logout: function() {
    this.isLoggedIn = false;
    this.currentUser = null;
    this.currentView = 'login';
    this.saveToStorage();
  },
  
  // Navigate to view
  navigate: function(view, params) {
    this.currentView = view;
    if (params && params.partnerId) {
      this.currentPartnerId = params.partnerId;
    }
    if (params && params.tab) {
      this.currentTab = params.tab;
    }
  },
  
  // Get partner by ID
  getPartnerById: function(id) {
    return this.partners.find(function(p) { return p.id === id; });
  },
  
  // Update partner
  updatePartner: function(partnerId, updates) {
    var index = this.partners.findIndex(function(p) { return p.id === partnerId; });
    if (index > -1) {
      this.partners[index] = Object.assign({}, this.partners[index], updates);
      this.savePartners();
      return true;
    }
    return false;
  },
  
  // Initialize mock data
  initializeData: function() {
    // Global Products - 100 Demo Products
    this.products = [
      // Eye Protection (15 products)
      { id: 'prod1', name: 'Safety Glasses - Clear Lens', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 15.99, cost: 12.00, surewerxSku: 'SWX-SG-001', description: 'Clear lens safety glasses with side shields', status: 'Active', visible: true },
      { id: 'prod2', name: 'Safety Glasses - Tinted', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 17.99, cost: 13.50, surewerxSku: 'SWX-SG-002', description: 'Tinted lens safety glasses for outdoor use', status: 'Active', visible: true },
      { id: 'prod3', name: 'Safety Goggles - Anti-Fog', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 22.99, cost: 16.00, surewerxSku: 'SWX-SG-003', description: 'Anti-fog safety goggles with indirect ventilation', status: 'Active', visible: true },
      { id: 'prod4', name: 'Face Shield - Full Coverage', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 28.99, cost: 21.00, surewerxSku: 'SWX-FS-001', description: 'Full face shield with adjustable headband', status: 'Active', visible: true },
      { id: 'prod5', name: 'Welding Helmet - Auto-Darkening', category: 'Eye Protection', supplier: 'WeldTech Pro', price: 125.99, cost: 95.00, surewerxSku: 'SWX-WH-001', description: 'Auto-darkening welding helmet with adjustable shade', status: 'Active', visible: true },
      { id: 'prod6', name: 'Safety Glasses - Polarized', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.00, surewerxSku: 'SWX-SG-004', description: 'Polarized safety glasses for glare reduction', status: 'Active', visible: true },
      { id: 'prod7', name: 'Safety Goggles - Chemical Splash', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.50, surewerxSku: 'SWX-SG-005', description: 'Chemical splash resistant safety goggles', status: 'Active', visible: true },
      { id: 'prod8', name: 'Safety Glasses - Bifocal', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 26.99, cost: 19.50, surewerxSku: 'SWX-SG-006', description: 'Bifocal safety glasses with reading magnification', status: 'Active', visible: true },
      { id: 'prod9', name: 'Face Shield - Mesh', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 18.99, cost: 13.00, surewerxSku: 'SWX-FS-002', description: 'Mesh face shield for forestry work', status: 'Active', visible: true },
      { id: 'prod10', name: 'Safety Glasses - Mirror Lens', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 21.99, cost: 16.00, surewerxSku: 'SWX-SG-007', description: 'Mirror lens safety glasses for extreme brightness', status: 'Active', visible: true },
      { id: 'prod11', name: 'Over-Glasses Safety Spectacles', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.00, surewerxSku: 'SWX-SG-008', description: 'Safety spectacles designed to fit over prescription glasses', status: 'Active', visible: true },
      { id: 'prod12', name: 'Laser Safety Glasses - Green', category: 'Eye Protection', supplier: 'LaserSafe Pro', price: 89.99, cost: 68.00, surewerxSku: 'SWX-LS-001', description: 'Green laser safety glasses with OD4+ protection', status: 'Active', visible: true },
      { id: 'prod13', name: 'Safety Glasses - Blue Light Blocking', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 23.99, cost: 17.50, surewerxSku: 'SWX-SG-009', description: 'Blue light blocking safety glasses for screen work', status: 'Active', visible: true },
      { id: 'prod14', name: 'Welding Goggles - Shade 5', category: 'Eye Protection', supplier: 'WeldTech Pro', price: 32.99, cost: 24.00, surewerxSku: 'SWX-WG-001', description: 'Flip-up welding goggles with shade 5 lens', status: 'Active', visible: true },
      { id: 'prod15', name: 'Safety Glasses - Foam Lined', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 20.99, cost: 15.50, surewerxSku: 'SWX-SG-010', description: 'Foam lined safety glasses for dust protection', status: 'Active', visible: true },
      
      // Head Protection (12 products)
      { id: 'prod16', name: 'Hard Hat - Yellow', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 24.99, cost: 18.50, surewerxSku: 'SWX-HH-002', description: 'Type 1 hard hat with ratchet suspension', status: 'Active', visible: true },
      { id: 'prod17', name: 'Hard Hat - White', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 24.99, cost: 18.50, surewerxSku: 'SWX-HH-003', description: 'Type 1 hard hat in white with ratchet suspension', status: 'Active', visible: true },
      { id: 'prod18', name: 'Hard Hat - Orange', category: 'Head Protection', supplier: 'ProGear Ltd', price: 26.99, cost: 20.00, surewerxSku: 'SWX-HH-004', description: 'Type 1 hard hat in high visibility orange', status: 'Active', visible: true },
      { id: 'prod19', name: 'Hard Hat - Vented', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 29.99, cost: 22.50, surewerxSku: 'SWX-HH-005', description: 'Vented hard hat for improved air circulation', status: 'Active', visible: true },
      { id: 'prod20', name: 'Hard Hat - Full Brim', category: 'Head Protection', supplier: 'ProGear Ltd', price: 32.99, cost: 25.00, surewerxSku: 'SWX-HH-006', description: 'Full brim hard hat for sun and rain protection', status: 'Active', visible: true },
      { id: 'prod21', name: 'Bump Cap - Baseball Style', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 18.99, cost: 14.00, surewerxSku: 'SWX-BC-001', description: 'Baseball style bump cap with protective insert', status: 'Active', visible: true },
      { id: 'prod22', name: 'Hard Hat - Electrical Rated', category: 'Head Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-HH-007', description: 'Class E electrical rated hard hat', status: 'Active', visible: true },
      { id: 'prod23', name: 'Winter Liner for Hard Hat', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 12.99, cost: 9.50, surewerxSku: 'SWX-HL-001', description: 'Insulated winter liner for hard hats', status: 'Active', visible: true },
      { id: 'prod24', name: 'Hard Hat - Climbing Helmet Style', category: 'Head Protection', supplier: 'ClimbSafe', price: 45.99, cost: 35.00, surewerxSku: 'SWX-HH-008', description: 'Climbing helmet style hard hat with chin strap', status: 'Active', visible: true },
      { id: 'prod25', name: 'Hard Hat Accessories Kit', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 15.99, cost: 11.50, surewerxSku: 'SWX-HA-001', description: 'Kit includes chin strap, sweatband, and clips', status: 'Active', visible: true },
      { id: 'prod26', name: 'Hard Hat - Carbon Fiber', category: 'Head Protection', supplier: 'ProGear Ltd', price: 89.99, cost: 68.00, surewerxSku: 'SWX-HH-009', description: 'Ultra-lightweight carbon fiber hard hat', status: 'Active', visible: true },
      { id: 'prod27', name: 'Welding Hard Hat Adapter', category: 'Head Protection', supplier: 'WeldTech Pro', price: 22.99, cost: 17.00, surewerxSku: 'SWX-WA-001', description: 'Adapter for mounting welding helmet to hard hat', status: 'Active', visible: true },
      
      // Hand Protection (18 products)
      { id: 'prod28', name: 'Work Gloves - Leather', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 12.99, cost: 9.00, surewerxSku: 'SWX-GL-003', description: 'Premium leather work gloves', status: 'Active', visible: true },
      { id: 'prod29', name: 'Work Gloves - Cowhide', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 14.99, cost: 11.00, surewerxSku: 'SWX-GL-004', description: 'Heavy duty cowhide work gloves', status: 'Active', visible: true },
      { id: 'prod30', name: 'Nitrile Gloves - Disposable (100pk)', category: 'Hand Protection', supplier: 'MedSupply Co', price: 19.99, cost: 14.50, surewerxSku: 'SWX-NG-001', description: 'Box of 100 disposable nitrile gloves', status: 'Active', visible: true },
      { id: 'prod31', name: 'Cut Resistant Gloves - Level 5', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.50, surewerxSku: 'SWX-CR-001', description: 'ANSI Level 5 cut resistant gloves', status: 'Active', visible: true },
      { id: 'prod32', name: 'Welding Gloves - Heavy Duty', category: 'Hand Protection', supplier: 'WeldTech Pro', price: 28.99, cost: 22.00, surewerxSku: 'SWX-WG-002', description: 'Heavy duty leather welding gloves', status: 'Active', visible: true },
      { id: 'prod33', name: 'Mechanic Gloves - Synthetic Leather', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 16.99, cost: 12.50, surewerxSku: 'SWX-MG-001', description: 'Synthetic leather mechanic gloves with padding', status: 'Active', visible: true },
      { id: 'prod34', name: 'Chemical Resistant Gloves', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 21.99, cost: 16.50, surewerxSku: 'SWX-CG-001', description: 'Chemical resistant nitrile gloves with extended cuff', status: 'Active', visible: true },
      { id: 'prod35', name: 'Winter Work Gloves - Insulated', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 18.99, cost: 14.00, surewerxSku: 'SWX-WW-001', description: 'Insulated winter work gloves with grip coating', status: 'Active', visible: true },
      { id: 'prod36', name: 'Latex Gloves - Disposable (100pk)', category: 'Hand Protection', supplier: 'MedSupply Co', price: 15.99, cost: 11.50, surewerxSku: 'SWX-LG-001', description: 'Box of 100 disposable latex gloves', status: 'Active', visible: true },
      { id: 'prod37', name: 'Impact Resistant Gloves', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 26.99, cost: 20.00, surewerxSku: 'SWX-IG-001', description: 'TPR impact resistant mechanic gloves', status: 'Active', visible: true },
      { id: 'prod38', name: 'Heat Resistant Gloves - 500°F', category: 'Hand Protection', supplier: 'WeldTech Pro', price: 32.99, cost: 25.00, surewerxSku: 'SWX-HR-001', description: 'Heat resistant gloves rated to 500°F', status: 'Active', visible: true },
      { id: 'prod39', name: 'Puncture Resistant Gloves', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 22.99, cost: 17.00, surewerxSku: 'SWX-PR-001', description: 'Puncture resistant gloves with reinforced palms', status: 'Active', visible: true },
      { id: 'prod40', name: 'Knit Gloves with Rubber Grip (12pk)', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.50, surewerxSku: 'SWX-KG-001', description: 'Pack of 12 cotton knit gloves with rubber grip', status: 'Active', visible: true },
      { id: 'prod41', name: 'Electrical Gloves - Class 0', category: 'Hand Protection', supplier: 'ElectroSafe', price: 89.99, cost: 68.00, surewerxSku: 'SWX-EG-001', description: 'Class 0 electrical insulating gloves (1000V)', status: 'Active', visible: true },
      { id: 'prod42', name: 'Assembly Gloves - Precision Grip', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 11.99, cost: 8.50, surewerxSku: 'SWX-AG-001', description: 'Precision assembly gloves with PU coating', status: 'Active', visible: true },
      { id: 'prod43', name: 'Kevlar Gloves - Cut Level 4', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 29.99, cost: 22.50, surewerxSku: 'SWX-KV-001', description: 'Kevlar blend cut resistant gloves', status: 'Active', visible: true },
      { id: 'prod44', name: 'Nitrile Palm Gloves (12pk)', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.50, surewerxSku: 'SWX-NP-001', description: 'Pack of 12 nitrile palm coated gloves', status: 'Active', visible: true },
      { id: 'prod45', name: 'Anti-Vibration Gloves', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-AV-001', description: 'Anti-vibration gloves for power tool use', status: 'Active', visible: true },
      
      // Body Protection (15 products)
      { id: 'prod46', name: 'Safety Vest - Hi-Vis Orange', category: 'Body Protection', supplier: 'ProGear Ltd', price: 19.99, cost: 14.00, surewerxSku: 'SWX-SV-004', description: 'Class 2 high visibility safety vest', status: 'Active', visible: true },
      { id: 'prod47', name: 'Safety Vest - Hi-Vis Yellow', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.00, surewerxSku: 'SWX-SV-005', description: 'Class 2 high visibility safety vest in yellow', status: 'Active', visible: true },
      { id: 'prod48', name: 'Reflective Vest - Class 3', category: 'Body Protection', supplier: 'ProGear Ltd', price: 29.99, cost: 22.50, surewerxSku: 'SWX-RV-001', description: 'Class 3 high visibility vest with sleeves', status: 'Active', visible: true },
      { id: 'prod49', name: 'Coveralls - Disposable (25pk)', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 49.99, cost: 38.00, surewerxSku: 'SWX-CV-001', description: 'Pack of 25 disposable coveralls', status: 'Active', visible: true },
      { id: 'prod50', name: 'Work Shirt - Hi-Vis Long Sleeve', category: 'Body Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-WS-001', description: 'Class 2 high visibility long sleeve work shirt', status: 'Active', visible: true },
      { id: 'prod51', name: 'Work Pants - Canvas', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 42.99, cost: 32.50, surewerxSku: 'SWX-WP-001', description: 'Heavy duty canvas work pants with knee pads', status: 'Active', visible: true },
      { id: 'prod52', name: 'Welding Jacket - Leather', category: 'Body Protection', supplier: 'WeldTech Pro', price: 89.99, cost: 68.00, surewerxSku: 'SWX-WJ-001', description: 'Leather welding jacket with snap closures', status: 'Active', visible: true },
      { id: 'prod53', name: 'Rain Suit - 2 Piece', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 38.99, cost: 29.50, surewerxSku: 'SWX-RS-001', description: 'Two piece PVC rain suit with hood', status: 'Active', visible: true },
      { id: 'prod54', name: 'Apron - Leather', category: 'Body Protection', supplier: 'ProGear Ltd', price: 45.99, cost: 35.00, surewerxSku: 'SWX-AP-001', description: 'Heavy duty leather apron for welding', status: 'Active', visible: true },
      { id: 'prod55', name: 'Safety Vest - Mesh', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 15.99, cost: 11.50, surewerxSku: 'SWX-SV-006', description: 'Lightweight mesh safety vest for hot weather', status: 'Active', visible: true },
      { id: 'prod56', name: 'Coveralls - Flame Resistant', category: 'Body Protection', supplier: 'FlameSafe Pro', price: 125.99, cost: 95.00, surewerxSku: 'SWX-FR-001', description: 'Flame resistant coveralls with reflective trim', status: 'Active', visible: true },
      { id: 'prod57', name: 'Winter Jacket - Insulated Hi-Vis', category: 'Body Protection', supplier: 'ProGear Ltd', price: 89.99, cost: 68.00, surewerxSku: 'SWX-WJ-002', description: 'Insulated high visibility winter jacket', status: 'Active', visible: true },
      { id: 'prod58', name: 'Lab Coat - Disposable (10pk)', category: 'Body Protection', supplier: 'MedSupply Co', price: 34.99, cost: 26.50, surewerxSku: 'SWX-LC-001', description: 'Pack of 10 disposable lab coats', status: 'Active', visible: true },
      { id: 'prod59', name: 'Bib Overalls - Canvas', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 54.99, cost: 42.00, surewerxSku: 'SWX-BO-001', description: 'Heavy duty canvas bib overalls', status: 'Active', visible: true },
      { id: 'prod60', name: 'Chemical Suit - Disposable', category: 'Body Protection', supplier: 'ProGear Ltd', price: 28.99, cost: 22.00, surewerxSku: 'SWX-CS-001', description: 'Type 5/6 chemical protective suit', status: 'Active', visible: true },
      
      // Foot Protection (12 products)
      { id: 'prod61', name: 'Steel Toe Boots - 6 inch', category: 'Foot Protection', supplier: 'BootMasters', price: 89.99, cost: 68.00, surewerxSku: 'SWX-ST-001', description: '6 inch steel toe work boots', status: 'Active', visible: true },
      { id: 'prod62', name: 'Composite Toe Boots - 8 inch', category: 'Foot Protection', supplier: 'BootMasters', price: 99.99, cost: 76.00, surewerxSku: 'SWX-CT-001', description: '8 inch composite toe work boots', status: 'Active', visible: true },
      { id: 'prod63', name: 'Rubber Boots - Steel Toe', category: 'Foot Protection', supplier: 'SafetyFirst Inc', price: 64.99, cost: 49.50, surewerxSku: 'SWX-RB-001', description: 'Waterproof rubber boots with steel toe', status: 'Active', visible: true },
      { id: 'prod64', name: 'Safety Shoes - Athletic Style', category: 'Foot Protection', supplier: 'BootMasters', price: 79.99, cost: 61.00, surewerxSku: 'SWX-AS-001', description: 'Athletic style safety shoes with composite toe', status: 'Active', visible: true },
      { id: 'prod65', name: 'Winter Work Boots - Insulated', category: 'Foot Protection', supplier: 'BootMasters', price: 119.99, cost: 91.00, surewerxSku: 'SWX-WB-001', description: 'Insulated winter work boots with steel toe', status: 'Active', visible: true },
      { id: 'prod66', name: 'Metatarsal Guard Boots', category: 'Foot Protection', supplier: 'BootMasters', price: 109.99, cost: 84.00, surewerxSku: 'SWX-MG-002', description: 'Steel toe boots with metatarsal guard', status: 'Active', visible: true },
      { id: 'prod67', name: 'Electrical Hazard Boots', category: 'Foot Protection', supplier: 'ElectroSafe', price: 94.99, cost: 72.50, surewerxSku: 'SWX-EH-001', description: 'EH rated safety boots with composite toe', status: 'Active', visible: true },
      { id: 'prod68', name: 'Boot Covers - Disposable (100pk)', category: 'Foot Protection', supplier: 'SafetyFirst Inc', price: 29.99, cost: 22.50, surewerxSku: 'SWX-BC-002', description: 'Pack of 100 disposable boot covers', status: 'Active', visible: true },
      { id: 'prod69', name: 'Slip-Resistant Shoes', category: 'Foot Protection', supplier: 'BootMasters', price: 69.99, cost: 53.50, surewerxSku: 'SWX-SR-001', description: 'Slip-resistant work shoes with composite toe', status: 'Active', visible: true },
      { id: 'prod70', name: 'Wellington Boots - Steel Toe', category: 'Foot Protection', supplier: 'SafetyFirst Inc', price: 74.99, cost: 57.00, surewerxSku: 'SWX-WL-001', description: 'Wellington style steel toe rubber boots', status: 'Active', visible: true },
      { id: 'prod71', name:'Boot Insoles - Comfort', category: 'Foot Protection', supplier: 'BootMasters', price: 24.99, cost: 18.50, surewerxSku: 'SWX-BI-001', description: 'Comfort insoles for work boots', status: 'Active', visible: true },
      { id: 'prod72', name: 'Chemical Resistant Boots', category: 'Foot Protection', supplier: 'ProGear Ltd', price: 84.99, cost: 65.00, surewerxSku: 'SWX-CR-002', description: 'Chemical resistant PVC boots with steel toe', status: 'Active', visible: true },
      
      // Hearing Protection (10 products)
      { id: 'prod73', name: 'Ear Plugs - Foam (200 pairs)', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.50, surewerxSku: 'SWX-EP-001', description: 'Box of 200 pairs foam ear plugs (NRR 33)', status: 'Active', visible: true },
      { id: 'prod74', name: 'Ear Muffs - Standard', category: 'Hearing Protection', supplier: 'ProGear Ltd', price: 22.99, cost: 17.00, surewerxSku: 'SWX-EM-001', description: 'Standard ear muffs (NRR 25)', status: 'Active', visible: true },
      { id: 'prod75', name: 'Ear Muffs - Electronic', category: 'Hearing Protection', supplier: 'TechSound', price: 89.99, cost: 68.00, surewerxSku: 'SWX-EM-002', description: 'Electronic ear muffs with sound amplification', status: 'Active', visible: true },
      { id: 'prod76', name: 'Ear Plugs - Reusable with Cord', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 8.99, cost: 6.50, surewerxSku: 'SWX-EP-002', description: 'Reusable corded ear plugs (NRR 27)', status: 'Active', visible: true },
      { id: 'prod77', name: 'Ear Muffs - Hard Hat Mount', category: 'Hearing Protection', supplier: 'ProGear Ltd', price: 28.99, cost: 22.00, surewerxSku: 'SWX-EM-003', description: 'Ear muffs that mount to hard hats', status: 'Active', visible: true },
      { id: 'prod78', name: 'Ear Band - Banded Plugs', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 12.99, cost: 9.50, surewerxSku: 'SWX-EB-001', description: 'Banded ear plugs for easy on/off', status: 'Active', visible: true },
      { id: 'prod79', name: 'Ear Muffs - Bluetooth', category: 'Hearing Protection', supplier: 'TechSound', price: 129.99, cost: 98.00, surewerxSku: 'SWX-EM-004', description: 'Bluetooth ear muffs with AM/FM radio', status: 'Active', visible: true },
      { id: 'prod80', name: 'Ear Plugs - Metal Detectable (100 pairs)', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 34.99, cost: 26.50, surewerxSku: 'SWX-EP-003', description: 'Metal detectable ear plugs for food industry', status: 'Active', visible: true },
      { id: 'prod81', name: 'Ear Muffs - Folding Compact', category: 'Hearing Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.50, surewerxSku: 'SWX-EM-005', description: 'Compact folding ear muffs (NRR 27)', status: 'Active', visible: true },
      { id: 'prod82', name: 'Custom Molded Ear Plugs', category: 'Hearing Protection', supplier: 'TechSound', price: 79.99, cost: 61.00, surewerxSku: 'SWX-EP-004', description: 'Custom molded reusable ear plugs', status: 'Active', visible: true },
      
      // Respiratory Protection (10 products)
      { id: 'prod83', name: 'Dust Mask - N95 (20pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 24.99, cost: 18.50, surewerxSku: 'SWX-DM-001', description: 'Pack of 20 N95 dust masks', status: 'Active', visible: true },
      { id: 'prod84', name: 'Half Mask Respirator - Reusable', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-HM-001', description: 'Reusable half mask respirator (mask only)', status: 'Active', visible: true },
      { id: 'prod85', name: 'Respirator Filters - P100 (2pk)', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 19.99, cost: 14.50, surewerxSku: 'SWX-RF-001', description: 'Pair of P100 respirator filters', status: 'Active', visible: true },
      { id: 'prod86', name: 'Full Face Respirator', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 189.99, cost: 145.00, surewerxSku: 'SWX-FF-001', description: 'Full face respirator with head harness', status: 'Active', visible: true },
      { id: 'prod87', name: 'Disposable Respirator - N95 Valve (10pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 29.99, cost: 22.50, surewerxSku: 'SWX-DR-001', description: 'Pack of 10 N95 respirators with valve', status: 'Active', visible: true },
      { id: 'prod88', name: 'Organic Vapor Cartridges (2pk)', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 28.99, cost: 22.00, surewerxSku: 'SWX-OV-001', description: 'Pair of organic vapor cartridges', status: 'Active', visible: true },
      { id: 'prod89', name: 'PAPR System - Complete', category: 'Respiratory Protection', supplier: 'AirTech Pro', price: 899.99, cost: 685.00, surewerxSku: 'SWX-PAPR-001', description: 'Complete powered air purifying respirator system', status: 'Active', visible: true },
      { id: 'prod90', name: 'Dust Mask - P95 (50pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 59.99, cost: 45.50, surewerxSku: 'SWX-DM-002', description: 'Pack of 50 P95 dust masks', status: 'Active', visible: true },
      { id: 'prod91', name: 'Combination Cartridges - Multi-Gas', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 42.99, cost: 32.50, surewerxSku: 'SWX-CC-001', description: 'Multi-gas combination cartridges (pair)', status: 'Active', visible: true },
      { id: 'prod92', name: 'Respirator Cleaning Wipes (100pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 14.99, cost: 11.00, surewerxSku: 'SWX-RW-001', description: 'Pack of 100 respirator cleaning wipes', status: 'Active', visible: true },
      
      // Fall Protection (8 products)
      { id: 'prod93', name: 'Safety Harness - Full Body', category: 'Fall Protection', supplier: 'HeightSafe', price: 149.99, cost: 114.00, surewerxSku: 'SWX-SH-001', description: 'Full body safety harness with D-ring', status: 'Active', visible: true },
      { id: 'prod94', name: 'Lanyard - 6ft Shock Absorbing', category: 'Fall Protection', supplier: 'HeightSafe', price: 89.99, cost: 68.00, surewerxSku: 'SWX-LA-001', description: '6 foot shock absorbing lanyard', status: 'Active', visible: true },
      { id: 'prod95', name: 'Retractable Lifeline - 30ft', category: 'Fall Protection', supplier: 'HeightSafe', price: 279.99, cost: 213.00, surewerxSku: 'SWX-RL-001', description: '30 foot self-retracting lifeline', status: 'Active', visible: true },
      { id: 'prod96', name: 'Anchor Point - Roof', category: 'Fall Protection', supplier: 'HeightSafe', price: 124.99, cost: 95.00, surewerxSku: 'SWX-AP-002', description: 'Permanent roof anchor point', status: 'Active', visible: true },
      { id: 'prod97', name: 'Rescue Kit - Confined Space', category: 'Fall Protection', supplier: 'HeightSafe', price: 499.99, cost: 380.00, surewerxSku: 'SWX-RK-001', description: 'Complete confined space rescue kit', status: 'Active', visible: true },
      { id: 'prod98', name: 'Safety Net - 10x10ft', category: 'Fall Protection', supplier: 'HeightSafe', price: 189.99, cost: 145.00, surewerxSku: 'SWX-SN-001', description: '10x10 foot safety catch net', status: 'Active', visible: true },
      { id: 'prod99', name: 'Harness Storage Bag', category: 'Fall Protection', supplier: 'HeightSafe', price: 34.99, cost: 26.50, surewerxSku: 'SWX-HS-001', description: 'Breathable storage bag for harnesses', status: 'Active', visible: true },
      { id: 'prod100', name: 'Tripod - Confined Space Entry', category: 'Fall Protection', supplier: 'HeightSafe', price: 899.99, cost: 685.00, surewerxSku: 'SWX-TP-001', description: 'Adjustable tripod for confined space entry', status: 'Active', visible: true }
    ];
    
    // Partners - only initialize if not already set
    if (!this.partners || this.partners.length === 0) {
      this.partners = [
      {
        id: 'p1',
        name: 'Tech Solutions Inc.',
        slug: 'tech-solutions-inc',
        industry: 'Technology',
        contactEmail: 'contact@techsolutions.com',
        contactPhone: '(555) 123-4567',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiMyNTYzZWIiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPlQ8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 45,
        activeVouchers: 3,
        monthlySpend: 12450.00,
        totalBudget: 50000,
        paymentMethods: ['Credit Card', 'Payroll Deduction'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: false,
          requireDateOfBirth: false,
          requireStartDate: true
        },
        employees: [
          {
            id: 'emp1',
            name: 'John Smith',
            email: 'john.smith@techsolutions.com',
            employeeId: 'EMP-001',
            username: 'jsmith',
            startDate: '2023-01-15',
            groupId: 'g1',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 250.00,
            voucherBalances: [
              { voucherId: 'v1', remainingAmount: 150.00 },
              { voucherId: 'v2', remainingAmount: 100.00 }
            ]
          },
          {
            id: 'emp2',
            name: 'Sarah Johnson',
            email: 'sarah.johnson@techsolutions.com',
            employeeId: 'EMP-002',
            username: 'sjohnson',
            startDate: '2023-03-20',
            groupId: 'g1',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 300.00,
            voucherBalances: [
              { voucherId: 'v1', remainingAmount: 200.00 },
              { voucherId: 'v2', remainingAmount: 100.00 }
            ]
          }
        ],
        groups: [
          {
            id: 'g1',
            name: 'Safety Team',
            department: 'Operations',
            location: 'Main Office',
            employeeCount: 2,
            productIds: ['prod1', 'prod2', 'prod3'],
            categoryIds: ['Eye Protection', 'Head Protection']
          },
          {
            id: 'g2',
            name: 'Warehouse Staff',
            department: 'Logistics',
            location: 'Warehouse',
            employeeCount: 0,
            productIds: ['prod1', 'prod2', 'prod3', 'prod4'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Body Protection']
          }
        ],
        vouchers: [
          {
            id: 'v1',
            name: 'Monthly Safety Allowance',
            description: 'Standard monthly safety equipment allowance',
            defaultAmount: 150.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod1', 'prod2', 'prod3'],
            userGroupIds: ['g1', 'g2']
          },
          {
            id: 'v2',
            name: 'Quarterly PPE Budget',
            description: 'Quarterly personal protective equipment budget',
            defaultAmount: 300.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: false,
            rolloverEnabled: true,
            productIds: ['prod1', 'prod2', 'prod3', 'prod4'],
            userGroupIds: ['g1']
          }
        ],
        availableProducts: this.products.slice()
      },
      {
        id: 'p2',
        name: 'Manufacturing Corp',
        slug: 'manufacturing-corp',
        industry: 'Manufacturing',
        contactEmail: 'info@manufacturing.com',
        contactPhone: '(555) 234-5678',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiMxNmEzNGEiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk08L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 78,
        activeVouchers: 5,
        monthlySpend: 23800.00,
        totalBudget: 100000,
        paymentMethods: ['Credit Card'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: true,
          requireDateOfBirth: true,
          requireStartDate: true
        },
        employees: [],
        groups: [
          {
            id: 'g3',
            name: 'Default Group',
            department: '',
            location: '',
            employeeCount: 0,
            productIds: [],
            categoryIds: []
          }
        ],
        vouchers: [],
        availableProducts: this.products.slice()
      },
      {
        id: 'p3',
        name: 'Construction Services',
        slug: 'construction-services',
        industry: 'Construction',
        contactEmail: 'hello@construction.com',
        contactPhone: '(555) 345-6789',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiNmNTllMGIiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkM8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 62,
        activeVouchers: 4,
        monthlySpend: 18900.00,
        totalBudget: 75000,
        paymentMethods: ['Credit Card', 'Payroll Deduction'],
        employeeFieldConfig: {
          requireEmployeeId: false,
          requireUsername: false,
          requireDateOfBirth: false,
          requireStartDate: false
        },
        employees: [],
        groups: [
          {
            id: 'g4',
            name: 'Default Group',
            department: '',
            location: '',
            employeeCount: 0,
            productIds: [],
            categoryIds: []
          }
        ],
        vouchers: [],
        availableProducts: this.products.slice()
      }
    ];
    }
    
    // Users
    this.users = [
      {
        id: 'u1',
        email: 'admin@distributor.com',
        password: 'admin123',
        firstName: 'Admin',
        lastName: 'User',
        role: 'Distributor',
        partnerId: null,
        status: 'Active'
      },
      {
        id: 'u2',
        email: 'partner@techsolutions.com',
        password: 'partner123',
        firstName: 'Partner',
        lastName: 'User',
        role: 'Partner',
        partnerId: 'p1',
        status: 'Active'
      }
    ];
    
    // Transactions - 25 demo transactions across different partners and time periods
    this.transactions = [
      { id: 't1', orderId: 'ORD-2024-001', employeeName: 'John Smith', employeeEmail: 'john.smith@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't2', orderId: 'ORD-2024-001', employeeName: 'John Smith', employeeEmail: 'john.smith@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-11-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't3', orderId: 'ORD-2024-002', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-10-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't4', orderId: 'ORD-2024-002', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-10-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't5', orderId: 'ORD-2024-003', employeeName: 'John Smith', employeeEmail: 'john.smith@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-10-15', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't6', orderId: 'ORD-2024-004', employeeName: 'Mike Davis', employeeEmail: 'mike.davis@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Ear Plugs - Foam (200 pairs)', surewerxPartNumber: 'SWX-EP-001', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.50, dateOrdered: '2024-11-05', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Processing', paymentMethod: 'Voucher' },
      { id: 't7', orderId: 'ORD-2024-004', employeeName: 'Mike Davis', employeeEmail: 'mike.davis@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Safety Goggles - Anti-Fog', surewerxPartNumber: 'SWX-SG-003', distributorPartNumber: '', quantity: 4, unitPrice: 22.99, totalPrice: 91.96, distributorCost: 16.00, dateOrdered: '2024-11-05', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Processing', paymentMethod: 'Credit Card' },
      { id: 't8', orderId: 'ORD-2024-005', employeeName: 'Lisa Chen', employeeEmail: 'lisa.chen@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Hard Hat - Full Brim', surewerxPartNumber: 'SWX-HH-006', distributorPartNumber: '', quantity: 1, unitPrice: 32.99, totalPrice: 32.99, distributorCost: 25.00, dateOrdered: '2024-11-03', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't9', orderId: 'ORD-2024-005', employeeName: 'Lisa Chen', employeeEmail: 'lisa.chen@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Work Gloves - Cowhide', surewerxPartNumber: 'SWX-GL-004', distributorPartNumber: '', quantity: 5, unitPrice: 14.99, totalPrice: 74.95, distributorCost: 11.00, dateOrdered: '2024-11-03', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't10', orderId: 'ORD-2024-006', employeeName: 'Robert Martinez', employeeEmail: 'robert.martinez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Reflective Vest - Class 3', surewerxPartNumber: 'SWX-RV-001', distributorPartNumber: '', quantity: 2, unitPrice: 29.99, totalPrice: 59.98, distributorCost: 22.50, dateOrdered: '2024-10-30', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't11', orderId: 'ORD-2024-007', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-10-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't12', orderId: 'ORD-2024-008', employeeName: 'Tom Wilson', employeeEmail: 'tom.wilson@manufacturing.com', employeeGroup: 'Maintenance', partnerName: 'Manufacturing Corp', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-10-20', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't13', orderId: 'ORD-2024-009', employeeName: 'Anna Rodriguez', employeeEmail: 'anna.rodriguez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-10-18', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't14', orderId: 'ORD-2024-009', employeeName: 'Anna Rodriguez', employeeEmail: 'anna.rodriguez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-10-18', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't15', orderId: 'ORD-2024-010', employeeName: 'John Smith', employeeEmail: 'john.smith@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-10-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't16', orderId: 'ORD-2024-011', employeeName: 'David Kim', employeeEmail: 'david.kim@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-10-10', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't17', orderId: 'ORD-2024-012', employeeName: 'Jessica Brown', employeeEmail: 'jessica.brown@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-10-05', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't18', orderId: 'ORD-2024-013', employeeName: 'Carlos Garcia', employeeEmail: 'carlos.garcia@manufacturing.com', employeeGroup: 'Maintenance', partnerName: 'Manufacturing Corp', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-10-01', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't19', orderId: 'ORD-2024-014', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-09-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't20', orderId: 'ORD-2024-015', employeeName: 'Michael Lee', employeeEmail: 'michael.lee@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Hard Hat - Vented', surewerxPartNumber: 'SWX-HH-005', distributorPartNumber: '', quantity: 2, unitPrice: 29.99, totalPrice: 59.98, distributorCost: 22.50, dateOrdered: '2024-09-25', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't21', orderId: 'ORD-2024-016', employeeName: 'Emma White', employeeEmail: 'emma.white@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-09-20', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't22', orderId: 'ORD-2024-017', employeeName: 'John Smith', employeeEmail: 'john.smith@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-09-15', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't23', orderId: 'ORD-2024-018', employeeName: 'James Taylor', employeeEmail: 'james.taylor@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-09-10', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't24', orderId: 'ORD-2024-019', employeeName: 'Sophia Anderson', employeeEmail: 'sophia.anderson@manufacturing.com', employeeGroup: 'Quality Control', partnerName: 'Manufacturing Corp', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-09-05', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' },
      { id: 't25', orderId: 'ORD-2024-020', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@techsolutions.com', employeeGroup: 'Safety Team', partnerName: 'Tech Solutions Inc.', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-08-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Delivered', paymentMethod: 'Voucher' }
    ];
  }
};

// Initialize state on load
$(function() {
  AppState.init();
});