// Main Application Controller

var App = {
  init: function() {
    var self = this;
    AppState.init();
    
    // Attach header events globally
    HeaderComponent.attachEvents();
    
    if (AppState.isLoggedIn) {
      var user = AppState.currentUser;
      if (user.role === 'Distributor') {
        this.navigate('dashboard');
      } else if (user.role === 'SureWerx') {
        // SureWerx users need to select a distributor first
        if (AppState.selectedDistributorId) {
          this.navigate('dashboard');
        } else {
          // Show distributor selection modal
          LoginComponent.showDistributorSelectionModal();
        }
      } else {
        // Partner users go directly to their partner detail page
        this.navigate('partner-detail', { partnerId: AppState.currentUser.partnerId });
      }
    } else {
      LoginComponent.init();
    }
  },
  
  navigate: function(view, params) {
    // Check if partner user is trying to access restricted pages
    var user = AppState.currentUser;
    var isPartnerUser = user && user.role === 'Partner';
    var isSureWerx = user && user.role === 'SureWerx';
    // Partner users can access user-management (to manage their own users) and partner-reporting but not other restricted views
    var restrictedViews = ['dashboard', 'settings', 'products', 'partner-form'];
    
    if (isPartnerUser && restrictedViews.indexOf(view) > -1) {
      // Redirect partner users back to their partner detail page
      console.log('Access denied: Partner users cannot access', view);
      this.navigate('partner-detail', { partnerId: AppState.currentUser.partnerId });
      return;
    }
    
    // SureWerx users need to have selected a distributor to access distributor views
    if (isSureWerx && restrictedViews.indexOf(view) > -1 && !AppState.selectedDistributorId) {
      // Show distributor selection modal
      LoginComponent.showDistributorSelectionModal();
      return;
    }
    
    AppState.navigate(view, params);
    
    switch(view) {
      case 'login':
        LoginComponent.init();
        break;
      case 'dashboard':
        DashboardComponent.init();
        break;
      case 'partner-detail':
        PartnerDetailComponent.init(params.partnerId, params.tab);
        break;
      case 'partner-form':
        // Handle both partner object and partnerId for edit mode
        var partner = null;
        if (params) {
          if (params.partner) {
            partner = params.partner;
          } else if (params.partnerId) {
            partner = AppState.getPartnerById(params.partnerId);
          }
        }
        PartnerFormComponent.init(partner);
        break;
      case 'partner-group-form':
        UserGroupFormComponent.init(params.partnerId, params.groupId);
        break;
      case 'group-product-visibility':
        GroupProductVisibilityComponent.init(params.partnerId, params.groupId);
        break;
      case 'voucher-form':
        VoucherFormComponent.init(params.partnerId, params.voucherId);
        break;
      case 'voucher-product-selection':
        VoucherProductSelectionComponent.init(params.partnerId, params.voucherId);
        break;
      case 'reporting':
        ReportingComponent.init();
        break;
      case 'user-management':
        UserManagementComponent.init();
        break;
      case 'settings':
        SettingsComponent.init();
        break;
      case 'products':
        ProductsComponent.init();
        break;
      default:
        LoginComponent.init();
    }
  },
  
  showSettingsPlaceholder: function() {
    $('#app-container').html(
      Templates.header() +
      '<div class="container">' +
      '<h2>Distributor Settings</h2>' +
      '<p class="text-muted">Settings page coming soon...</p>' +
      '</div>'
    );
    $('.nav-link').removeClass('active');
    $('.nav-link[data-nav="settings"]').addClass('active');
  },
  
  showProductsPlaceholder: function() {
    $('#app-container').html(
      Templates.header() +
      '<div class="container">' +
      '<h2>Product Management</h2>' +
      '<p class="text-muted">Product management page coming soon...</p>' +
      '</div>'
    );
    $('.nav-link').removeClass('active');
    $('.nav-link[data-nav="products"]').addClass('active');
  }
};

// Initialize app when document is ready
$(function() {
  App.init();
});