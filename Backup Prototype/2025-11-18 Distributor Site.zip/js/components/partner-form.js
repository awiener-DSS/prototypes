// Partner Form Component (Multi-step wizard)

var PartnerFormComponent = {
  currentStep: 1,
  totalSteps: 6,
  isEditMode: false,
  editingPartnerId: null,
  defaultTermsAndConditions: 'Net 30 payment terms. Payment is due within 30 days of invoice date. Late payments may be subject to a 1.5% monthly interest charge. All sales are final unless otherwise specified in writing.',
  formData: {
    name: '',
    slug: '',
    status: 'active',
    logo: null,
    employeeFieldConfig: {
      requireEmployeeId: true,
      requireUsername: false,
      requireDateOfBirth: true,
      requireStartDate: false
    },
    paymentMethods: [],
    termsAndConditions: ''
  },
  
  init: function(partner) {
    this.currentStep = 1;
    this.isEditMode = !!partner;
    this.editingPartnerId = partner ? partner.id : null;
    
    if (partner) {
      // Normalize payment methods - ensure it's an array
      var paymentMethods = partner.paymentMethods;
      if (!Array.isArray(paymentMethods) || paymentMethods.length === 0) {
        paymentMethods = ['Credit Card']; // Default if empty
      }
      
      this.formData = {
        name: partner.name,
        slug: partner.slug,
        status: partner.status,
        logo: partner.logoUrl || null,
        employeeFieldConfig: partner.employeeFieldConfig,
        paymentMethods: paymentMethods,
        termsAndConditions: partner.termsAndConditions || ''
      };
    } else {
      this.resetFormData();
    }
    
    this.render();
    this.attachEvents();
  },
  
  resetFormData: function() {
    this.formData = {
      name: '',
      slug: '',
      status: 'active',
      logo: null,
      employeeFieldConfig: {
        requireEmployeeId: true,
        requireUsername: false,
        requireDateOfBirth: true,
        requireStartDate: false
      },
      paymentMethods: ['Credit Card'], // Default to Credit Card for new partners
      termsAndConditions: ''
    };
  },
  
  render: function() {
    $('#app-container').html(Templates.partnerFormWizard(this.currentStep, this.formData, this.isEditMode));
    // Always update slug preview after rendering step 1
    if (this.currentStep === 1) {
      this.updateSlugPreview();
    }
  },
  
  attachEvents: function() {
    var self = this;
    
    // Remove all existing event handlers first to prevent duplicates
    $(document).off('click', '#cancel-partner-form');
    $(document).off('click', '#next-step-btn');
    $(document).off('click', '#back-step-btn');
    $(document).off('input change', '#partner-name');
    $(document).off('change', '#partner-status');
    $(document).off('change', '#partner-logo-upload');
    $(document).off('click', '#remove-logo-btn');
    $(document).off('click', '#upload-logo-area');
    $(document).off('change', '#require-employee-id');
    $(document).off('change', '#require-username');
    $(document).off('change', '#require-dob');
    $(document).off('change', '#require-start-date');
    $(document).off('change', '#payment-credit-card');
    $(document).off('change', '#payment-payroll');
    $(document).off('input', '#terms-and-conditions');
    $(document).off('click', '#use-default-terms-btn');
    $(document).off('click', '#save-partner-btn');
    
    // Cancel button
    $(document).on('click', '#cancel-partner-form', function(e) {
      e.preventDefault();
      App.navigate('dashboard');
    });
    
    // Next button
    $(document).on('click', '#next-step-btn', function() {
      if (self.validateStep(self.currentStep)) {
        self.currentStep++;
        self.render();
      }
    });
    
    // Back button
    $(document).on('click', '#back-step-btn', function() {
      self.currentStep--;
      self.render();
    });
    
    // Form field changes
    $(document).on('input change', '#partner-name', function() {
      self.formData.name = $(this).val();
      if (!self.isEditMode) {
        self.formData.slug = self.generateSlug($(this).val());
        self.updateSlugPreview();
      }
    });
    
    $(document).on('change', '#partner-status', function() {
      self.formData.status = $(this).val();
    });
    
    // Logo upload
    $(document).on('change', '#partner-logo-upload', function(e) {
      self.handleLogoUpload(e);
    });
    
    $(document).on('click', '#remove-logo-btn', function() {
      self.formData.logo = null;
      self.render();
    });
    
    $(document).on('click', '#upload-logo-area', function() {
      $('#partner-logo-upload').click();
    });
    
    // Employee field config checkboxes - only allow changes if not in edit mode
    $(document).on('change', '#require-employee-id', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireEmployeeId);
        $('#require-username').prop('checked', self.formData.employeeFieldConfig.requireUsername);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireEmployeeId = true;
        self.formData.employeeFieldConfig.requireUsername = false;
      }
    });
    
    $(document).on('change', '#require-username', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireUsername);
        $('#require-employee-id').prop('checked', self.formData.employeeFieldConfig.requireEmployeeId);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireEmployeeId = false;
        self.formData.employeeFieldConfig.requireUsername = true;
      }
    });
    
    $(document).on('change', '#require-dob', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireDateOfBirth);
        $('#require-start-date').prop('checked', self.formData.employeeFieldConfig.requireStartDate);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireDateOfBirth = true;
        self.formData.employeeFieldConfig.requireStartDate = false;
      }
    });
    
    $(document).on('change', '#require-start-date', function() {
      if (self.isEditMode) {
        // Prevent changes in edit mode - restore original value
        $(this).prop('checked', self.formData.employeeFieldConfig.requireStartDate);
        $('#require-dob').prop('checked', self.formData.employeeFieldConfig.requireDateOfBirth);
        return;
      }
      if ($(this).prop('checked')) {
        self.formData.employeeFieldConfig.requireDateOfBirth = false;
        self.formData.employeeFieldConfig.requireStartDate = true;
      }
    });
    
    // Payment methods (checkboxes - multiple selection)
    $(document).on('change', 'input[name="payment-method"]', function() {
      var selectedMethods = [];
      $('input[name="payment-method"]:checked').each(function() {
        selectedMethods.push($(this).val());
      });
      self.formData.paymentMethods = selectedMethods;
    });
    
    // Terms and conditions
    $(document).on('input', '#terms-and-conditions', function() {
      self.formData.termsAndConditions = $(this).val();
    });
    
    $(document).on('click', '#use-default-terms-btn', function() {
      $('#terms-and-conditions').val(self.defaultTermsAndConditions);
      self.formData.termsAndConditions = self.defaultTermsAndConditions;
    });
    
    // Save button
    $(document).on('click', '#save-partner-btn', function() {
      self.handleSave();
    });
    
    // Step indicator click (only works in edit mode)
    $(document).on('click', '.wizard-step-clickable', function() {
      if (self.isEditMode) {
        var stepId = parseInt($(this).data('step-id'));
        if (stepId && stepId !== self.currentStep) {
          self.jumpToStep(stepId);
        }
      }
    });
  },
  
  jumpToStep: function(step) {
    // In edit mode, allow jumping to any step without validation
    this.currentStep = step;
    this.render();
  },
  
  generateSlug: function(text) {
    return text
      .toLowerCase()
      .trim()
      .replace(/[^\w\s-]/g, '')
      .replace(/\s+/g, '-')
      .replace(/-+/g, '-')
      .replace(/^-|-$/g, '');
  },
  
  updateSlugPreview: function() {
    var distributorName = AppState.distributorName || 'Premier Distributor Co';
    var distributorSlug = this.generateSlug(distributorName);
    var partnerSlug = this.formData.slug || 'partner-name';
    var url = 'www.surewerxdistributor.com/<span style="color: #666;">' + distributorSlug + '</span>/<strong>' + partnerSlug + '</strong>';
    $('#slug-preview').html(url);
  },
  
  handleLogoUpload: function(e) {
    var file = e.target.files[0];
    if (!file) return;
    
    if (file.size > 5 * 1024 * 1024) {
      Helpers.showAlert('Logo file size must be less than 5MB', 'danger');
      return;
    }
    
    if (!file.type.startsWith('image/')) {
      Helpers.showAlert('Please upload an image file', 'danger');
      return;
    }
    
    var reader = new FileReader();
    var self = this;
    reader.onload = function(event) {
      self.formData.logo = event.target.result;
      self.render();
    };
    reader.readAsDataURL(file);
  },
  
  validateStep: function(step) {
    switch(step) {
      case 1:
        if (!this.formData.name.trim()) {
          Helpers.showAlert('Please enter a partner name', 'danger', '#next-step-btn');
          return false;
        }
        // Auto-generate slug from name if not in edit mode
        if (!this.isEditMode) {
          this.formData.slug = this.generateSlug(this.formData.name);
          if (!this.formData.slug.trim()) {
            Helpers.showAlert('Partner name must contain at least one letter or number', 'danger', '#next-step-btn');
            return false;
          }
          // Check if slug already exists (only for new partners)
          var existingPartner = AppState.partners.find(function(p) {
            return p.slug === this.formData.slug;
          }.bind(this));
          if (existingPartner) {
            // If slug exists, append a number to make it unique
            var baseSlug = this.formData.slug;
            var counter = 1;
            while (existingPartner) {
              this.formData.slug = baseSlug + '-' + counter;
              existingPartner = AppState.partners.find(function(p) {
                return p.slug === this.formData.slug;
              }.bind(this));
              counter++;
            }
            this.updateSlugPreview();
          }
        }
        return true;
      case 3:
        // Check at least one identifier field
        var hasIdentifier = this.formData.employeeFieldConfig.requireEmployeeId || 
                           this.formData.employeeFieldConfig.requireUsername;
        if (!hasIdentifier) {
          Helpers.showAlert('Please select at least one identifier field (Employee ID or Username)', 'danger', '#next-step-btn');
          return false;
        }
        // Check at least one date field
        var hasDate = this.formData.employeeFieldConfig.requireDateOfBirth || 
                     this.formData.employeeFieldConfig.requireStartDate;
        if (!hasDate) {
          Helpers.showAlert('Please select at least one date field (Date of Birth or Start Date)', 'danger', '#next-step-btn');
          return false;
        }
        return true;
      case 4:
        if (this.formData.paymentMethods.length === 0) {
          Helpers.showAlert('Please select at least one payment method', 'danger', '#next-step-btn');
          return false;
        }
        return true;
      default:
        return true;
    }
  },
  
  handleSave: function() {
    // In edit mode, validate step 1 (name) and step 4 (payment methods) if on those steps
    // In create mode, always validate step 4 (payment methods)
    if (this.isEditMode) {
      // Always validate step 1 (name is required)
      if (!this.validateStep(1)) {
        return;
      }
      // Validate payment methods if we're on step 4 or 5
      if (this.currentStep >= 4 && !this.validateStep(4)) {
        return;
      }
    } else {
      // For new partners, validate step 4 (payment methods)
      if (!this.validateStep(4)) {
        return;
      }
    }
    
    if (this.isEditMode) {
      // Get the original partner to preserve identifier fields
      var originalPartner = AppState.getPartnerById(this.editingPartnerId);
      
      // Update existing partner - preserve all employee field config from original
      var employeeFieldConfig = {
        requireEmployeeId: originalPartner.employeeFieldConfig.requireEmployeeId,
        requireUsername: originalPartner.employeeFieldConfig.requireUsername,
        requireDateOfBirth: originalPartner.employeeFieldConfig.requireDateOfBirth,
        requireStartDate: originalPartner.employeeFieldConfig.requireStartDate
      };
      
      AppState.updatePartner(this.editingPartnerId, {
        name: this.formData.name.trim(),
        status: this.formData.status,
        logoUrl: this.formData.logo,
        employeeFieldConfig: employeeFieldConfig,
        paymentMethods: this.formData.paymentMethods,
        termsAndConditions: this.formData.termsAndConditions.trim()
      });
      
      Helpers.showAlert('Partner updated successfully', 'success');
    } else {
      // Create new partner
      var newPartner = {
        id: Helpers.generateId(),
        name: this.formData.name.trim(),
        slug: this.formData.slug.trim(),
        industry: 'General', // Default industry
        status: this.formData.status,
        logoUrl: this.formData.logo,
        employeeCount: 0,
        activeVouchers: 0,
        monthlySpend: 0,
        totalBudget: 0,
        paymentMethods: this.formData.paymentMethods,
        employeeFieldConfig: this.formData.employeeFieldConfig,
        termsAndConditions: this.formData.termsAndConditions.trim() || this.defaultTermsAndConditions,
        employees: [],
        groups: [],
        vouchers: [],
        availableProducts: AppState.products.slice()
      };
      
      AppState.partners.push(newPartner);
      AppState.savePartners();
      Helpers.showAlert('Partner created successfully', 'success');
      
      // Ensure the partner is saved before navigating
      // Use setTimeout to ensure localStorage write is complete
      var self = this;
      setTimeout(function() {
        // Verify partner exists before navigating
        var savedPartner = AppState.getPartnerById(newPartner.id);
        if (savedPartner) {
          App.navigate('partner-detail', { partnerId: newPartner.id });
        } else {
          // If partner not found, reload and try again
          console.error('Partner not found after save, reloading...');
          window.location.reload();
        }
      }, 100);
      return;
    }
    
    App.navigate('dashboard');
  }
};