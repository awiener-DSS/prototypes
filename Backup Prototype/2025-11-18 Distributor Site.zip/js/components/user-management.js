// User Management Component

var UserManagementComponent = {
  init: function() {
    this.render();
    this.attachEvents();
  },
  
  render: function() {
    var isPartnerUser = AppState.currentUser && AppState.currentUser.role === 'Partner';
    var isDistributorUser = AppState.currentUser && AppState.currentUser.role === 'Distributor';
    var pageTitle = isPartnerUser ? 'My Account' : 'User Management';
    var pageDescription = isPartnerUser ? 'Manage users for your account' : 'Manage distributor and customer user accounts';
    
    var html = '<div>' +
      Templates.header() +
      '<div class="container">' +
      '<div class="row mb-4">' +
      '<div class="col-md-8">' +
      // Add back button for appropriate users
      (isDistributorUser ? 
        '<button class="btn btn-default mb-3" id="back-to-dashboard">' +
        '<span class="glyphicon glyphicon-chevron-left"></span> Back to Dashboard' +
        '</button>' : '') +
      (isPartnerUser ? 
        '<button class="btn btn-default mb-3" id="back-to-partner-detail">' +
        '<span class="glyphicon glyphicon-chevron-left"></span> Back to Customer Detail' +
        '</button>' : '') +
      '<h2>' + pageTitle + '</h2>' +
      '<p class="text-muted">' + pageDescription + '</p>' +
      '</div>' +
      '<div class="col-md-4 text-right">' +
      '<button class="btn btn-primary" id="create-user-btn">' +
      '<span class="glyphicon glyphicon-plus"></span> Create User' +
      '</button>' +
      '</div>' +
      '</div>';
    
    // Only show role filter for distributor users
    if (!isPartnerUser) {
      html += '<div class="row mb-3">' +
        '<div class="col-md-4">' +
        '<select class="form-control" id="role-filter">' +
        '<option value="all">All Roles</option>' +
        '<option value="Distributor">Distributor Users</option>' +
        '<option value="Partner">Customer Users</option>' +
        '</select>' +
        '</div>' +
        '</div>';
    }
    
    html += this.renderUsersTable() +
      '</div>' +
      '</div>';
    
    $('#app-container').html(html);
  },
  
  attachEvents: function() {
    var self = this;
    
    // Role filter
    $(document).on('change', '#role-filter', function() {
      self.filterUsers($(this).val());
    });
    
    // Create user
    $(document).on('click', '#create-user-btn', function() {
      self.showCreateUserModal();
    });
    
    // Edit user
    $(document).on('click', '.edit-user-btn', function() {
      var userId = $(this).data('user-id');
      self.showEditUserModal(userId);
    });
    
    // Toggle user status (activate/deactivate)
    $(document).on('click', '.toggle-user-status-btn', function() {
      var userId = $(this).data('user-id');
      self.toggleUserStatus(userId);
    });
    
    // Back to dashboard
    $(document).on('click', '#back-to-dashboard', function() {
      App.navigate('dashboard');
    });
    
    // Back to partner detail
    $(document).on('click', '#back-to-partner-detail', function() {
      App.navigate('partner-detail', { partnerId: AppState.currentUser.partnerId });
    });
  },
  
  renderUsersTable: function() {
    var isPartnerUser = AppState.currentUser && AppState.currentUser.role === 'Partner';
    var users = AppState.users;
    
    // Filter users for partner users - only show users from their partner
    if (isPartnerUser) {
      users = users.filter(function(u) {
        return u.partnerId === AppState.currentUser.partnerId;
      });
    }
    
    return '<div class="panel panel-default">' +
      '<div class="panel-heading">' +
      '<h3 class="panel-title">Users</h3>' +
      '</div>' +
      '<table class="table table-hover">' +
      '<thead>' +
      '<tr>' +
      '<th>Name</th>' +
      '<th>Email</th>' +
      '<th>Role</th>' +
          (isPartnerUser ? '' : '<th>Customer</th>') +
      '<th>Status</th>' +
      '<th>Actions</th>' +
      '</tr>' +
      '</thead>' +
      '<tbody id="users-table-body">' +
      users.map(function(user) {
        var partner = user.partnerId ? 
          AppState.partners.find(function(p) { return p.id === user.partnerId; }) : null;
        
        return '<tr>' +
          '<td>' + Helpers.escapeHtml(user.firstName + ' ' + user.lastName) + '</td>' +
          '<td>' + Helpers.escapeHtml(user.email) + '</td>' +
          '<td><span class="label ' + (user.role === 'Distributor' ? 'label-primary' : 'label-info') + '">' +
          Helpers.escapeHtml(user.role === 'Partner' ? 'Customer' : user.role) + '</span></td>' +
          (isPartnerUser ? '' : '<td>' + (partner ? Helpers.escapeHtml(partner.name) : '-') + '</td>') +
          '<td><span class="label ' + Helpers.getStatusBadgeClass(user.status) + '">' +
          Helpers.escapeHtml(user.status) + '</span></td>' +
          '<td>' +
          '<button class="btn btn-sm btn-default edit-user-btn" data-user-id="' + user.id + '">' +
          '<span class="glyphicon glyphicon-pencil"></span>' +
          '</button> ' +
          (user.id !== AppState.currentUser.id ?
            '<button class="btn btn-sm btn-' + (user.status === 'Active' ? 'warning' : 'success') + ' toggle-user-status-btn" data-user-id="' + user.id + '" title="' + (user.status === 'Active' ? 'Deactivate' : 'Activate') + ' User">' +
            '<span class="glyphicon glyphicon-' + (user.status === 'Active' ? 'ban-circle' : 'ok-circle') + '"></span> ' +
            (user.status === 'Active' ? 'Deactivate' : 'Activate') +
            '</button>' : '') +
          '</td>' +
          '</tr>';
      }).join('') +
      '</tbody>' +
      '</table>' +
      '</div>';
  },
  
  filterUsers: function(role) {
    var users = AppState.users;
    
    if (role !== 'all') {
      users = users.filter(function(u) { return u.role === role; });
    }
    
    var tbody = users.map(function(user) {
      var partner = user.partnerId ? 
        AppState.partners.find(function(p) { return p.id === user.partnerId; }) : null;
      
      return '<tr>' +
        '<td>' + Helpers.escapeHtml(user.firstName + ' ' + user.lastName) + '</td>' +
        '<td>' + Helpers.escapeHtml(user.email) + '</td>' +
        '<td><span class="label ' + (user.role === 'Distributor' ? 'label-primary' : 'label-info') + '">' +
        Helpers.escapeHtml(user.role) + '</span></td>' +
        '<td>' + (partner ? Helpers.escapeHtml(partner.name) : '-') + '</td>' +
        '<td><span class="label ' + Helpers.getStatusBadgeClass(user.status) + '">' +
        Helpers.escapeHtml(user.status) + '</span></td>' +
        '<td>' +
        '<button class="btn btn-sm btn-default edit-user-btn" data-user-id="' + user.id + '">' +
        '<span class="glyphicon glyphicon-pencil"></span>' +
        '</button> ' +
        (user.id !== AppState.currentUser.id ?
          '<button class="btn btn-sm btn-' + (user.status === 'Active' ? 'warning' : 'success') + ' toggle-user-status-btn" data-user-id="' + user.id + '" title="' + (user.status === 'Active' ? 'Deactivate' : 'Activate') + ' User">' +
          '<span class="glyphicon glyphicon-' + (user.status === 'Active' ? 'ban-circle' : 'ok-circle') + '"></span> ' +
          (user.status === 'Active' ? 'Deactivate' : 'Activate') +
          '</button>' : '') +
        '</td>' +
        '</tr>';
    }).join('');
    
    $('#users-table-body').html(tbody);
  },
  
  showCreateUserModal: function() {
    var isPartnerUser = AppState.currentUser && AppState.currentUser.role === 'Partner';
    
    var modalHtml = '<div class="modal fade" id="create-user-modal" tabindex="-1">' +
      '<div class="modal-dialog">' +
      '<div class="modal-content">' +
      '<div class="modal-header">' +
      '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
      '<h4 class="modal-title">Create New User</h4>' +
      '</div>' +
      '<form id="create-user-form">' +
      '<div class="modal-body">' +
      '<div class="alert alert-info" style="margin-bottom: 20px;">' +
      '<span class="glyphicon glyphicon-info-sign"></span> ' +
      'An email will be sent to the user with instructions to set up their password.' +
      '</div>' +
      '<div class="form-group">' +
      '<label>First Name *</label>' +
      '<input type="text" class="form-control" id="user-firstname" required>' +
      '</div>' +
      '<div class="form-group">' +
      '<label>Last Name *</label>' +
      '<input type="text" class="form-control" id="user-lastname" required>' +
      '</div>' +
      '<div class="form-group">' +
      '<label>Email *</label>' +
      '<input type="email" class="form-control" id="user-email" required>' +
      '</div>';
    
    // Only show role and partner select for distributor users
    if (!isPartnerUser) {
      modalHtml += '<div class="form-group">' +
        '<label>Role *</label>' +
        '<select class="form-control" id="user-role" required>' +
        '<option value="">Select role...</option>' +
        '<option value="Distributor">Distributor</option>' +
        '<option value="Partner">Customer</option>' +
        '</select>' +
        '</div>' +
        '<div class="form-group" id="partner-select-group" style="display:none;">' +
        '<label>Customer *</label>' +
        '<select class="form-control" id="user-partner">' +
        '<option value="">Select customer...</option>' +
        AppState.partners.map(function(p) {
          return '<option value="' + p.id + '">' + Helpers.escapeHtml(p.name) + '</option>';
        }).join('') +
        '</select>' +
        '</div>';
    }
    
    modalHtml += '</div>' +
      '<div class="modal-footer">' +
      '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
      '<button type="submit" class="btn btn-primary">Create User</button>' +
      '</div>' +
      '</form>' +
      '</div>' +
      '</div>' +
      '</div>';
    
    $('body').append(modalHtml);
    $('#create-user-modal').modal('show');
    
    // Show/hide partner select based on role (only for distributor users)
    if (!isPartnerUser) {
      $(document).on('change', '#user-role', function() {
        if ($(this).val() === 'Partner') {
          $('#partner-select-group').show();
          $('#user-partner').prop('required', true);
        } else {
          $('#partner-select-group').hide();
          $('#user-partner').prop('required', false);
        }
      });
    }
    
    // Handle form submission
    $(document).off('submit', '#create-user-form').on('submit', '#create-user-form', function(e) {
      e.preventDefault();
      
      var newUser = {
        id: Helpers.generateId(),
        firstName: $('#user-firstname').val(),
        lastName: $('#user-lastname').val(),
        email: $('#user-email').val(),
        role: isPartnerUser ? 'Partner' : $('#user-role').val(),
        partnerId: isPartnerUser ? AppState.currentUser.partnerId : 
                   ($('#user-role').val() === 'Partner' ? $('#user-partner').val() : null),
        status: 'Active'
      };
      
      AppState.users.push(newUser);
      $('#create-user-modal').modal('hide');
      UserManagementComponent.render();
      Helpers.showAlert('User created successfully. An email has been sent to ' + newUser.email + ' with password setup instructions.', 'success');
    });
    
    // Clean up modal on hide
    $('#create-user-modal').on('hidden.bs.modal', function() {
      $(this).remove();
    });
  },
  
  showEditUserModal: function(userId) {
    var isPartnerUser = AppState.currentUser && AppState.currentUser.role === 'Partner';
    var user = AppState.users.find(function(u) { return u.id === userId; });
    
    var modalHtml = '<div class="modal fade" id="edit-user-modal" tabindex="-1">' +
      '<div class="modal-dialog">' +
      '<div class="modal-content">' +
      '<div class="modal-header">' +
      '<button type="button" class="close" data-dismiss="modal">&times;</button>' +
      '<h4 class="modal-title">Edit User</h4>' +
      '</div>' +
      '<form id="edit-user-form">' +
      '<div class="modal-body">' +
      '<div class="form-group">' +
      '<label>First Name *</label>' +
      '<input type="text" class="form-control" id="user-firstname" value="' + Helpers.escapeHtml(user.firstName) + '" required>' +
      '</div>' +
      '<div class="form-group">' +
      '<label>Last Name *</label>' +
      '<input type="text" class="form-control" id="user-lastname" value="' + Helpers.escapeHtml(user.lastName) + '" required>' +
      '</div>' +
      '<div class="form-group">' +
      '<label>Email *</label>' +
      '<input type="email" class="form-control" id="user-email" value="' + Helpers.escapeHtml(user.email) + '" required>' +
      '</div>';
    
    // Only show role and partner select for distributor users
    if (!isPartnerUser) {
      modalHtml += '<div class="form-group">' +
        '<label>Role *</label>' +
        '<select class="form-control" id="user-role" required>' +
        '<option value="">Select role...</option>' +
        '<option value="Distributor" ' + (user.role === 'Distributor' ? 'selected' : '') + '>Distributor</option>' +
        '<option value="Partner" ' + (user.role === 'Partner' ? 'selected' : '') + '>Partner</option>' +
        '</select>' +
        '</div>' +
        '<div class="form-group" id="partner-select-group" style="display:none;">' +
        '<label>Customer *</label>' +
        '<select class="form-control" id="user-partner">' +
        '<option value="">Select customer...</option>' +
        AppState.partners.map(function(p) {
          return '<option value="' + p.id + '" ' + (user.partnerId === p.id ? 'selected' : '') + '>' + Helpers.escapeHtml(p.name) + '</option>';
        }).join('') +
        '</select>' +
        '</div>';
    }
    
    modalHtml += '</div>' +
      '<div class="modal-footer">' +
      '<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>' +
      '<button type="submit" class="btn btn-primary">Save Changes</button>' +
      '</div>' +
      '</form>' +
      '</div>' +
      '</div>' +
      '</div>';
    
    $('body').append(modalHtml);
    $('#edit-user-modal').modal('show');
    
    // Show/hide partner select based on role (only for distributor users)
    if (!isPartnerUser) {
      $(document).on('change', '#user-role', function() {
        if ($(this).val() === 'Partner') {
          $('#partner-select-group').show();
          $('#user-partner').prop('required', true);
        } else {
          $('#partner-select-group').hide();
          $('#user-partner').prop('required', false);
        }
      });
    }
    
    // Handle form submission
    $(document).off('submit', '#edit-user-form').on('submit', '#edit-user-form', function(e) {
      e.preventDefault();
      
      user.firstName = $('#user-firstname').val();
      user.lastName = $('#user-lastname').val();
      user.email = $('#user-email').val();
      user.role = isPartnerUser ? 'Partner' : $('#user-role').val();
      user.partnerId = isPartnerUser ? AppState.currentUser.partnerId : 
                   ($('#user-role').val() === 'Partner' ? $('#user-partner').val() : null);
      
      $('#edit-user-modal').modal('hide');
      UserManagementComponent.render();
      Helpers.showAlert('User updated successfully', 'success');
    });
    
    // Clean up modal on hide
    $('#edit-user-modal').on('hidden.bs.modal', function() {
      $(this).remove();
    });
  },
  
  toggleUserStatus: function(userId) {
    var user = AppState.users.find(function(u) { return u.id === userId; });
    if (!user) return;
    
    // Prevent users from deactivating themselves
    if (user.id === AppState.currentUser.id) {
      Helpers.showAlert('You cannot deactivate your own account', 'warning');
      return;
    }
    
    var newStatus = user.status === 'Active' ? 'Inactive' : 'Active';
    var action = newStatus === 'Active' ? 'activate' : 'deactivate';
    
    if (confirm('Are you sure you want to ' + action + ' this user?')) {
      user.status = newStatus;
      this.render();
      Helpers.showAlert('User ' + action + 'd successfully', 'success');
    }
  }
};