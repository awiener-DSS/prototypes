// Navigation Helper - Replaces App.navigate with page redirects
var Navigation = {
  navigate: function(view, params) {
    params = params || {};
    
    switch(view) {
      case 'login':
        window.location.href = 'login.html';
        break;
        
      case 'dashboard':
        window.location.href = 'dashboard.html';
        break;
        
      case 'partner-detail':
        var url = 'partner-detail.html';
        if (params.partnerId) {
          url += '?partnerId=' + encodeURIComponent(params.partnerId);
          if (params.tab) {
            url += '&tab=' + encodeURIComponent(params.tab);
          }
        }
        window.location.href = url;
        break;
        
      case 'partner-form':
        var url = 'partner-form.html';
        if (params.partnerId) {
          url += '?partnerId=' + encodeURIComponent(params.partnerId);
        }
        window.location.href = url;
        break;
        
      case 'partner-group-form':
        var url = 'user-group-form.html';
        if (params.partnerId) {
          url += '?partnerId=' + encodeURIComponent(params.partnerId);
          if (params.groupId) {
            url += '&groupId=' + encodeURIComponent(params.groupId);
          }
        }
        window.location.href = url;
        break;
      
      case 'group-product-visibility':
        var url = 'group-product-visibility.html';
        if (params.partnerId) {
          url += '?partnerId=' + encodeURIComponent(params.partnerId);
          if (params.groupId) {
            url += '&groupId=' + encodeURIComponent(params.groupId);
          }
        }
        window.location.href = url;
        break;
      
      case 'voucher-form':
        var url = 'voucher-form.html';
        if (params.partnerId) {
          url += '?partnerId=' + encodeURIComponent(params.partnerId);
          if (params.voucherId) {
            url += '&voucherId=' + encodeURIComponent(params.voucherId);
          }
        }
        window.location.href = url;
        break;
      
      case 'voucher-product-selection':
        var url = 'voucher-product-selection.html';
        if (params.partnerId) {
          url += '?partnerId=' + encodeURIComponent(params.partnerId);
          if (params.voucherId) {
            url += '&voucherId=' + encodeURIComponent(params.voucherId);
          }
        }
        window.location.href = url;
        break;
      
      case 'reporting':
        // Check if user is a partner or distributor/SureWerx
        if (AppState.currentUser && AppState.currentUser.role === 'Partner') {
          window.location.href = 'partner-reporting.html';
        } else {
          window.location.href = 'reporting.html';
        }
        break;
      
      case 'partner-reporting':
        window.location.href = 'partner-reporting.html';
        break;
        
      case 'user-management':
        window.location.href = 'user-management.html';
        break;
        
      case 'settings':
        window.location.href = 'settings.html';
        break;
        
      case 'products':
        window.location.href = 'products.html';
        break;
        
      default:
        window.location.href = 'login.html';
    }
  }
};

// Create alias for backwards compatibility
var App = {
  navigate: Navigation.navigate
};
