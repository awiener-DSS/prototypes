// Global Application State
var AppState = {
  isLoggedIn: false,
  currentUser: null,
  currentView: 'login',
  currentPartnerId: null,
  currentTab: 'employees',
  distributorName: 'My Distributor',
  distributorLogo: null,
  selectedDistributorId: null, // For SureWerx employees to select which distributor to view as
  partners: [],
  transactions: [],
  users: [],
  products: [],
  distributors: [], // List of distributors for SureWerx employees
  
  // Initialize state
  init: function() {
    this.loadFromStorage();
    this.initializeData();
  },
  
  // Load state from localStorage
  loadFromStorage: function() {
    var stored = localStorage.getItem('appState');
    if (stored) {
      var parsed = JSON.parse(stored);
      this.isLoggedIn = parsed.isLoggedIn || false;
      this.currentUser = parsed.currentUser || null;
      // Load distributor settings from localStorage if they exist
      if (parsed.distributorName !== undefined) {
        this.distributorName = parsed.distributorName;
      }
      if (parsed.distributorLogo !== undefined) {
        this.distributorLogo = parsed.distributorLogo;
      } else {
        // Only set Fastenal logo as default if the distributor is actually Fastenal
        // Check if selected distributor is Fastenal (for SureWerx users)
        // or if distributor name is Fastenal (for regular distributor users)
        var isFastenal = false;
        if (parsed.selectedDistributorId === 'd1') {
          // SureWerx user selected Fastenal
          isFastenal = true;
        } else if (!parsed.selectedDistributorId && parsed.distributorName === 'Fastenal') {
          // Regular distributor user with Fastenal name
          isFastenal = true;
        }
        
        if (isFastenal) {
          this.distributorLogo = 'images/Fastenal_logo.png';
          this.saveToStorage();
        } else {
          // No default logo for other distributors
          this.distributorLogo = null;
        }
      }
      if (parsed.selectedDistributorId !== undefined) {
        this.selectedDistributorId = parsed.selectedDistributorId;
      }
      // Load partners from localStorage if they exist
      if (parsed.partners && Array.isArray(parsed.partners) && parsed.partners.length > 0) {
        // Filter out partners to delete: 'adam', 'abc', 'Adam Co', 'AdamCo'
        var partnersToDelete = ['adam', 'abc', 'Adam Co', 'AdamCo'];
        this.partners = parsed.partners.filter(function(partner) {
          return partnersToDelete.indexOf(partner.name) === -1;
        });
        // If partners were filtered out, save the updated list
        if (this.partners.length !== parsed.partners.length) {
          this.savePartners();
        }
      }
    }
  },
  
  // Save state to localStorage
  saveToStorage: function() {
    var toSave = {
      isLoggedIn: this.isLoggedIn,
      currentUser: this.currentUser,
      distributorName: this.distributorName,
      distributorLogo: this.distributorLogo,
      selectedDistributorId: this.selectedDistributorId,
      partners: this.partners
    };
    localStorage.setItem('appState', JSON.stringify(toSave));
  },
  
  // Get current distributor info (for SureWerx employees)
  getCurrentDistributor: function() {
    if (this.currentUser && this.currentUser.role === 'SureWerx' && this.selectedDistributorId) {
      return this.distributors.find(function(d) { return d.id === this.selectedDistributorId; }.bind(this));
    }
    return null;
  },
  
  // Set selected distributor (for SureWerx employees)
  setSelectedDistributor: function(distributorId) {
    this.selectedDistributorId = distributorId;
    var distributor = this.distributors.find(function(d) { return d.id === distributorId; });
    if (distributor) {
      this.distributorName = distributor.name;
      // Only use Fastenal logo if the distributor is Fastenal, otherwise use their logo or null
      this.distributorLogo = distributor.logo || null;
    }
    this.saveToStorage();
  },
  
  // Save partners to localStorage
  savePartners: function() {
    var stored = localStorage.getItem('appState');
    var toSave = stored ? JSON.parse(stored) : {};
    toSave.partners = this.partners;
    // Also update the full state to ensure consistency
    toSave.isLoggedIn = this.isLoggedIn;
    toSave.currentUser = this.currentUser;
    toSave.distributorName = this.distributorName;
    toSave.distributorLogo = this.distributorLogo;
    toSave.selectedDistributorId = this.selectedDistributorId;
    localStorage.setItem('appState', JSON.stringify(toSave));
  },
  
  // Login user
  login: function(email, password) {
    // Find user in mock data
    var user = this.users.find(function(u) {
      return u.email === email && u.password === password;
    });
    
    if (user) {
      this.isLoggedIn = true;
      this.currentUser = {
        id: user.id,
        email: user.email,
        firstName: user.firstName,
        lastName: user.lastName,
        role: user.role,
        partnerId: user.partnerId
      };
      this.saveToStorage();
      return true;
    }
    return false;
  },
  
  // Logout user
  logout: function() {
    this.isLoggedIn = false;
    this.currentUser = null;
    this.currentView = 'login';
    this.saveToStorage();
  },
  
  // Navigate to view
  navigate: function(view, params) {
    this.currentView = view;
    if (params && params.partnerId) {
      this.currentPartnerId = params.partnerId;
    }
    if (params && params.tab) {
      this.currentTab = params.tab;
    }
  },
  
  // Get partner by ID
  getPartnerById: function(id) {
    return this.partners.find(function(p) { return p.id === id; });
  },
  
  // Update partner
  updatePartner: function(partnerId, updates) {
    var index = this.partners.findIndex(function(p) { return p.id === partnerId; });
    if (index > -1) {
      this.partners[index] = Object.assign({}, this.partners[index], updates);
      this.savePartners();
      return true;
    }
    return false;
  },
  
  // Initialize mock data
  initializeData: function() {
    // Global Products - 100 Demo Products
    this.products = [
      // Eye Protection (15 products)
      { id: 'prod1', name: 'Safety Glasses - Clear Lens', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 15.99, cost: 12.00, surewerxSku: 'SWX-SG-001', customSku: 'SG-CLEAR-001', description: 'Clear lens safety glasses with side shields', status: 'Active', visible: true },
      { id: 'prod2', name: 'Safety Glasses - Tinted', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 17.99, cost: 13.50, surewerxSku: 'SWX-SG-002', customSku: 'SG-TINT-002', description: 'Tinted lens safety glasses for outdoor use', status: 'Active', visible: true },
      { id: 'prod3', name: 'Safety Goggles - Anti-Fog', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 22.99, cost: 16.00, surewerxSku: 'SWX-SG-003', customSku: 'GG-ANTIFOG-003', description: 'Anti-fog safety goggles with indirect ventilation', status: 'Active', visible: true },
      { id: 'prod4', name: 'Face Shield - Full Coverage', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 28.99, cost: 21.00, surewerxSku: 'SWX-FS-001', customSku: 'FS-FULL-001', description: 'Full face shield with adjustable headband', status: 'Active', visible: true },
      { id: 'prod5', name: 'Welding Helmet - Auto-Darkening', category: 'Eye Protection', supplier: 'WeldTech Pro', price: 125.99, cost: 95.00, surewerxSku: 'SWX-WH-001', customSku: 'WH-AUTO-001', description: 'Auto-darkening welding helmet with adjustable shade', status: 'Active', visible: true },
      { id: 'prod6', name: 'Safety Glasses - Polarized', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.00, surewerxSku: 'SWX-SG-004', description: 'Polarized safety glasses for glare reduction', status: 'Active', visible: true },
      { id: 'prod7', name: 'Safety Goggles - Chemical Splash', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.50, surewerxSku: 'SWX-SG-005', description: 'Chemical splash resistant safety goggles', status: 'Active', visible: true },
      { id: 'prod8', name: 'Safety Glasses - Bifocal', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 26.99, cost: 19.50, surewerxSku: 'SWX-SG-006', description: 'Bifocal safety glasses with reading magnification', status: 'Active', visible: true },
      { id: 'prod9', name: 'Face Shield - Mesh', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 18.99, cost: 13.00, surewerxSku: 'SWX-FS-002', description: 'Mesh face shield for forestry work', status: 'Active', visible: true },
      { id: 'prod10', name: 'Safety Glasses - Mirror Lens', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 21.99, cost: 16.00, surewerxSku: 'SWX-SG-007', description: 'Mirror lens safety glasses for extreme brightness', status: 'Active', visible: true },
      { id: 'prod11', name: 'Over-Glasses Safety Spectacles', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.00, surewerxSku: 'SWX-SG-008', description: 'Safety spectacles designed to fit over prescription glasses', status: 'Active', visible: true },
      { id: 'prod12', name: 'Laser Safety Glasses - Green', category: 'Eye Protection', supplier: 'LaserSafe Pro', price: 89.99, cost: 68.00, surewerxSku: 'SWX-LS-001', description: 'Green laser safety glasses with OD4+ protection', status: 'Active', visible: true },
      { id: 'prod13', name: 'Safety Glasses - Blue Light Blocking', category: 'Eye Protection', supplier: 'ProGear Ltd', price: 23.99, cost: 17.50, surewerxSku: 'SWX-SG-009', description: 'Blue light blocking safety glasses for screen work', status: 'Active', visible: true },
      { id: 'prod14', name: 'Welding Goggles - Shade 5', category: 'Eye Protection', supplier: 'WeldTech Pro', price: 32.99, cost: 24.00, surewerxSku: 'SWX-WG-001', description: 'Flip-up welding goggles with shade 5 lens', status: 'Active', visible: true },
      { id: 'prod15', name: 'Safety Glasses - Foam Lined', category: 'Eye Protection', supplier: 'SafetyFirst Inc', price: 20.99, cost: 15.50, surewerxSku: 'SWX-SG-010', description: 'Foam lined safety glasses for dust protection', status: 'Active', visible: true },
      
      // Head Protection (12 products)
      { id: 'prod16', name: 'Hard Hat - Yellow', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 24.99, cost: 18.50, surewerxSku: 'SWX-HH-002', customSku: 'HH-YEL-002', description: 'Type 1 hard hat with ratchet suspension', status: 'Active', visible: true },
      { id: 'prod17', name: 'Hard Hat - White', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 24.99, cost: 18.50, surewerxSku: 'SWX-HH-003', customSku: 'HH-WHT-003', description: 'Type 1 hard hat in white with ratchet suspension', status: 'Active', visible: true },
      { id: 'prod18', name: 'Hard Hat - Orange', category: 'Head Protection', supplier: 'ProGear Ltd', price: 26.99, cost: 20.00, surewerxSku: 'SWX-HH-004', customSku: 'HH-ORG-004', description: 'Type 1 hard hat in high visibility orange', status: 'Active', visible: true },
      { id: 'prod19', name: 'Hard Hat - Vented', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 29.99, cost: 22.50, surewerxSku: 'SWX-HH-005', customSku: 'HH-VENT-005', description: 'Vented hard hat for improved air circulation', status: 'Active', visible: true },
      { id: 'prod20', name: 'Hard Hat - Full Brim', category: 'Head Protection', supplier: 'ProGear Ltd', price: 32.99, cost: 25.00, surewerxSku: 'SWX-HH-006', customSku: 'HH-BRIM-006', description: 'Full brim hard hat for sun and rain protection', status: 'Active', visible: true },
      { id: 'prod21', name: 'Bump Cap - Baseball Style', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 18.99, cost: 14.00, surewerxSku: 'SWX-BC-001', description: 'Baseball style bump cap with protective insert', status: 'Active', visible: true },
      { id: 'prod22', name: 'Hard Hat - Electrical Rated', category: 'Head Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-HH-007', description: 'Class E electrical rated hard hat', status: 'Active', visible: true },
      { id: 'prod23', name: 'Winter Liner for Hard Hat', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 12.99, cost: 9.50, surewerxSku: 'SWX-HL-001', description: 'Insulated winter liner for hard hats', status: 'Active', visible: true },
      { id: 'prod24', name: 'Hard Hat - Climbing Helmet Style', category: 'Head Protection', supplier: 'ClimbSafe', price: 45.99, cost: 35.00, surewerxSku: 'SWX-HH-008', description: 'Climbing helmet style hard hat with chin strap', status: 'Active', visible: true },
      { id: 'prod25', name: 'Hard Hat Accessories Kit', category: 'Head Protection', supplier: 'SafetyFirst Inc', price: 15.99, cost: 11.50, surewerxSku: 'SWX-HA-001', description: 'Kit includes chin strap, sweatband, and clips', status: 'Active', visible: true },
      { id: 'prod26', name: 'Hard Hat - Carbon Fiber', category: 'Head Protection', supplier: 'ProGear Ltd', price: 89.99, cost: 68.00, surewerxSku: 'SWX-HH-009', description: 'Ultra-lightweight carbon fiber hard hat', status: 'Active', visible: true },
      { id: 'prod27', name: 'Welding Hard Hat Adapter', category: 'Head Protection', supplier: 'WeldTech Pro', price: 22.99, cost: 17.00, surewerxSku: 'SWX-WA-001', description: 'Adapter for mounting welding helmet to hard hat', status: 'Active', visible: true },
      
      // Hand Protection (18 products)
      { id: 'prod28', name: 'Work Gloves - Leather', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 12.99, cost: 9.00, surewerxSku: 'SWX-GL-003', description: 'Premium leather work gloves', status: 'Active', visible: true },
      { id: 'prod29', name: 'Work Gloves - Cowhide', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 14.99, cost: 11.00, surewerxSku: 'SWX-GL-004', description: 'Heavy duty cowhide work gloves', status: 'Active', visible: true },
      { id: 'prod30', name: 'Nitrile Gloves - Disposable (100pk)', category: 'Hand Protection', supplier: 'MedSupply Co', price: 19.99, cost: 14.50, surewerxSku: 'SWX-NG-001', description: 'Box of 100 disposable nitrile gloves', status: 'Active', visible: true },
      { id: 'prod31', name: 'Cut Resistant Gloves - Level 5', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.50, surewerxSku: 'SWX-CR-001', description: 'ANSI Level 5 cut resistant gloves', status: 'Active', visible: true },
      { id: 'prod32', name: 'Welding Gloves - Heavy Duty', category: 'Hand Protection', supplier: 'WeldTech Pro', price: 28.99, cost: 22.00, surewerxSku: 'SWX-WG-002', description: 'Heavy duty leather welding gloves', status: 'Active', visible: true },
      { id: 'prod33', name: 'Mechanic Gloves - Synthetic Leather', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 16.99, cost: 12.50, surewerxSku: 'SWX-MG-001', description: 'Synthetic leather mechanic gloves with padding', status: 'Active', visible: true },
      { id: 'prod34', name: 'Chemical Resistant Gloves', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 21.99, cost: 16.50, surewerxSku: 'SWX-CG-001', description: 'Chemical resistant nitrile gloves with extended cuff', status: 'Active', visible: true },
      { id: 'prod35', name: 'Winter Work Gloves - Insulated', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 18.99, cost: 14.00, surewerxSku: 'SWX-WW-001', description: 'Insulated winter work gloves with grip coating', status: 'Active', visible: true },
      { id: 'prod36', name: 'Latex Gloves - Disposable (100pk)', category: 'Hand Protection', supplier: 'MedSupply Co', price: 15.99, cost: 11.50, surewerxSku: 'SWX-LG-001', description: 'Box of 100 disposable latex gloves', status: 'Active', visible: true },
      { id: 'prod37', name: 'Impact Resistant Gloves', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 26.99, cost: 20.00, surewerxSku: 'SWX-IG-001', description: 'TPR impact resistant mechanic gloves', status: 'Active', visible: true },
      { id: 'prod38', name: 'Heat Resistant Gloves - 500°F', category: 'Hand Protection', supplier: 'WeldTech Pro', price: 32.99, cost: 25.00, surewerxSku: 'SWX-HR-001', description: 'Heat resistant gloves rated to 500°F', status: 'Active', visible: true },
      { id: 'prod39', name: 'Puncture Resistant Gloves', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 22.99, cost: 17.00, surewerxSku: 'SWX-PR-001', description: 'Puncture resistant gloves with reinforced palms', status: 'Active', visible: true },
      { id: 'prod40', name: 'Knit Gloves with Rubber Grip (12pk)', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.50, surewerxSku: 'SWX-KG-001', description: 'Pack of 12 cotton knit gloves with rubber grip', status: 'Active', visible: true },
      { id: 'prod41', name: 'Electrical Gloves - Class 0', category: 'Hand Protection', supplier: 'ElectroSafe', price: 89.99, cost: 68.00, surewerxSku: 'SWX-EG-001', description: 'Class 0 electrical insulating gloves (1000V)', status: 'Active', visible: true },
      { id: 'prod42', name: 'Assembly Gloves - Precision Grip', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 11.99, cost: 8.50, surewerxSku: 'SWX-AG-001', description: 'Precision assembly gloves with PU coating', status: 'Active', visible: true },
      { id: 'prod43', name: 'Kevlar Gloves - Cut Level 4', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 29.99, cost: 22.50, surewerxSku: 'SWX-KV-001', description: 'Kevlar blend cut resistant gloves', status: 'Active', visible: true },
      { id: 'prod44', name: 'Nitrile Palm Gloves (12pk)', category: 'Hand Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.50, surewerxSku: 'SWX-NP-001', description: 'Pack of 12 nitrile palm coated gloves', status: 'Active', visible: true },
      { id: 'prod45', name: 'Anti-Vibration Gloves', category: 'Hand Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-AV-001', description: 'Anti-vibration gloves for power tool use', status: 'Active', visible: true },
      
      // Body Protection (15 products)
      { id: 'prod46', name: 'Safety Vest - Hi-Vis Orange', category: 'Body Protection', supplier: 'ProGear Ltd', price: 19.99, cost: 14.00, surewerxSku: 'SWX-SV-004', customSku: 'VEST-ORANGE-004', description: 'Class 2 high visibility safety vest', status: 'Active', visible: true },
      { id: 'prod47', name: 'Safety Vest - Hi-Vis Yellow', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.00, surewerxSku: 'SWX-SV-005', customSku: 'VEST-YELLOW-005', description: 'Class 2 high visibility safety vest in yellow', status: 'Active', visible: true },
      { id: 'prod48', name: 'Reflective Vest - Class 3', category: 'Body Protection', supplier: 'ProGear Ltd', price: 29.99, cost: 22.50, surewerxSku: 'SWX-RV-001', customSku: 'VEST-REF-C3', description: 'Class 3 high visibility vest with sleeves', status: 'Active', visible: true },
      { id: 'prod49', name: 'Coveralls - Disposable (25pk)', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 49.99, cost: 38.00, surewerxSku: 'SWX-CV-001', description: 'Pack of 25 disposable coveralls', status: 'Active', visible: true },
      { id: 'prod50', name: 'Work Shirt - Hi-Vis Long Sleeve', category: 'Body Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-WS-001', description: 'Class 2 high visibility long sleeve work shirt', status: 'Active', visible: true },
      { id: 'prod51', name: 'Work Pants - Canvas', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 42.99, cost: 32.50, surewerxSku: 'SWX-WP-001', description: 'Heavy duty canvas work pants with knee pads', status: 'Active', visible: true },
      { id: 'prod52', name: 'Welding Jacket - Leather', category: 'Body Protection', supplier: 'WeldTech Pro', price: 89.99, cost: 68.00, surewerxSku: 'SWX-WJ-001', description: 'Leather welding jacket with snap closures', status: 'Active', visible: true },
      { id: 'prod53', name: 'Rain Suit - 2 Piece', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 38.99, cost: 29.50, surewerxSku: 'SWX-RS-001', description: 'Two piece PVC rain suit with hood', status: 'Active', visible: true },
      { id: 'prod54', name: 'Apron - Leather', category: 'Body Protection', supplier: 'ProGear Ltd', price: 45.99, cost: 35.00, surewerxSku: 'SWX-AP-001', description: 'Heavy duty leather apron for welding', status: 'Active', visible: true },
      { id: 'prod55', name: 'Safety Vest - Mesh', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 15.99, cost: 11.50, surewerxSku: 'SWX-SV-006', description: 'Lightweight mesh safety vest for hot weather', status: 'Active', visible: true },
      { id: 'prod56', name: 'Coveralls - Flame Resistant', category: 'Body Protection', supplier: 'FlameSafe Pro', price: 125.99, cost: 95.00, surewerxSku: 'SWX-FR-001', description: 'Flame resistant coveralls with reflective trim', status: 'Active', visible: true },
      { id: 'prod57', name: 'Winter Jacket - Insulated Hi-Vis', category: 'Body Protection', supplier: 'ProGear Ltd', price: 89.99, cost: 68.00, surewerxSku: 'SWX-WJ-002', description: 'Insulated high visibility winter jacket', status: 'Active', visible: true },
      { id: 'prod58', name: 'Lab Coat - Disposable (10pk)', category: 'Body Protection', supplier: 'MedSupply Co', price: 34.99, cost: 26.50, surewerxSku: 'SWX-LC-001', description: 'Pack of 10 disposable lab coats', status: 'Active', visible: true },
      { id: 'prod59', name: 'Bib Overalls - Canvas', category: 'Body Protection', supplier: 'SafetyFirst Inc', price: 54.99, cost: 42.00, surewerxSku: 'SWX-BO-001', description: 'Heavy duty canvas bib overalls', status: 'Active', visible: true },
      { id: 'prod60', name: 'Chemical Suit - Disposable', category: 'Body Protection', supplier: 'ProGear Ltd', price: 28.99, cost: 22.00, surewerxSku: 'SWX-CS-001', description: 'Type 5/6 chemical protective suit', status: 'Active', visible: true },
      
      // Foot Protection (12 products)
      { id: 'prod61', name: 'Steel Toe Boots - 6 inch', category: 'Foot Protection', supplier: 'BootMasters', price: 89.99, cost: 68.00, surewerxSku: 'SWX-ST-001', customSku: 'BOOT-ST-6IN', description: '6 inch steel toe work boots', status: 'Active', visible: true },
      { id: 'prod62', name: 'Composite Toe Boots - 8 inch', category: 'Foot Protection', supplier: 'BootMasters', price: 99.99, cost: 76.00, surewerxSku: 'SWX-CT-001', customSku: 'BOOT-CT-8IN', description: '8 inch composite toe work boots', status: 'Active', visible: true },
      { id: 'prod63', name: 'Rubber Boots - Steel Toe', category: 'Foot Protection', supplier: 'SafetyFirst Inc', price: 64.99, cost: 49.50, surewerxSku: 'SWX-RB-001', description: 'Waterproof rubber boots with steel toe', status: 'Active', visible: true },
      { id: 'prod64', name: 'Safety Shoes - Athletic Style', category: 'Foot Protection', supplier: 'BootMasters', price: 79.99, cost: 61.00, surewerxSku: 'SWX-AS-001', description: 'Athletic style safety shoes with composite toe', status: 'Active', visible: true },
      { id: 'prod65', name: 'Winter Work Boots - Insulated', category: 'Foot Protection', supplier: 'BootMasters', price: 119.99, cost: 91.00, surewerxSku: 'SWX-WB-001', description: 'Insulated winter work boots with steel toe', status: 'Active', visible: true },
      { id: 'prod66', name: 'Metatarsal Guard Boots', category: 'Foot Protection', supplier: 'BootMasters', price: 109.99, cost: 84.00, surewerxSku: 'SWX-MG-002', description: 'Steel toe boots with metatarsal guard', status: 'Active', visible: true },
      { id: 'prod67', name: 'Electrical Hazard Boots', category: 'Foot Protection', supplier: 'ElectroSafe', price: 94.99, cost: 72.50, surewerxSku: 'SWX-EH-001', description: 'EH rated safety boots with composite toe', status: 'Active', visible: true },
      { id: 'prod68', name: 'Boot Covers - Disposable (100pk)', category: 'Foot Protection', supplier: 'SafetyFirst Inc', price: 29.99, cost: 22.50, surewerxSku: 'SWX-BC-002', description: 'Pack of 100 disposable boot covers', status: 'Active', visible: true },
      { id: 'prod69', name: 'Slip-Resistant Shoes', category: 'Foot Protection', supplier: 'BootMasters', price: 69.99, cost: 53.50, surewerxSku: 'SWX-SR-001', description: 'Slip-resistant work shoes with composite toe', status: 'Active', visible: true },
      { id: 'prod70', name: 'Wellington Boots - Steel Toe', category: 'Foot Protection', supplier: 'SafetyFirst Inc', price: 74.99, cost: 57.00, surewerxSku: 'SWX-WL-001', description: 'Wellington style steel toe rubber boots', status: 'Active', visible: true },
      { id: 'prod71', name:'Boot Insoles - Comfort', category: 'Foot Protection', supplier: 'BootMasters', price: 24.99, cost: 18.50, surewerxSku: 'SWX-BI-001', description: 'Comfort insoles for work boots', status: 'Active', visible: true },
      { id: 'prod72', name: 'Chemical Resistant Boots', category: 'Foot Protection', supplier: 'ProGear Ltd', price: 84.99, cost: 65.00, surewerxSku: 'SWX-CR-002', description: 'Chemical resistant PVC boots with steel toe', status: 'Active', visible: true },
      
      // Hearing Protection (10 products)
      { id: 'prod73', name: 'Ear Plugs - Foam (200 pairs)', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 19.99, cost: 14.50, surewerxSku: 'SWX-EP-001', customSku: 'EP-FOAM-200', description: 'Box of 200 pairs foam ear plugs (NRR 33)', status: 'Active', visible: true },
      { id: 'prod74', name: 'Ear Muffs - Standard', category: 'Hearing Protection', supplier: 'ProGear Ltd', price: 22.99, cost: 17.00, surewerxSku: 'SWX-EM-001', customSku: 'EM-STD-001', description: 'Standard ear muffs (NRR 25)', status: 'Active', visible: true },
      { id: 'prod75', name: 'Ear Muffs - Electronic', category: 'Hearing Protection', supplier: 'TechSound', price: 89.99, cost: 68.00, surewerxSku: 'SWX-EM-002', description: 'Electronic ear muffs with sound amplification', status: 'Active', visible: true },
      { id: 'prod76', name: 'Ear Plugs - Reusable with Cord', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 8.99, cost: 6.50, surewerxSku: 'SWX-EP-002', description: 'Reusable corded ear plugs (NRR 27)', status: 'Active', visible: true },
      { id: 'prod77', name: 'Ear Muffs - Hard Hat Mount', category: 'Hearing Protection', supplier: 'ProGear Ltd', price: 28.99, cost: 22.00, surewerxSku: 'SWX-EM-003', description: 'Ear muffs that mount to hard hats', status: 'Active', visible: true },
      { id: 'prod78', name: 'Ear Band - Banded Plugs', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 12.99, cost: 9.50, surewerxSku: 'SWX-EB-001', description: 'Banded ear plugs for easy on/off', status: 'Active', visible: true },
      { id: 'prod79', name: 'Ear Muffs - Bluetooth', category: 'Hearing Protection', supplier: 'TechSound', price: 129.99, cost: 98.00, surewerxSku: 'SWX-EM-004', description: 'Bluetooth ear muffs with AM/FM radio', status: 'Active', visible: true },
      { id: 'prod80', name: 'Ear Plugs - Metal Detectable (100 pairs)', category: 'Hearing Protection', supplier: 'SafetyFirst Inc', price: 34.99, cost: 26.50, surewerxSku: 'SWX-EP-003', description: 'Metal detectable ear plugs for food industry', status: 'Active', visible: true },
      { id: 'prod81', name: 'Ear Muffs - Folding Compact', category: 'Hearing Protection', supplier: 'ProGear Ltd', price: 24.99, cost: 18.50, surewerxSku: 'SWX-EM-005', description: 'Compact folding ear muffs (NRR 27)', status: 'Active', visible: true },
      { id: 'prod82', name: 'Custom Molded Ear Plugs', category: 'Hearing Protection', supplier: 'TechSound', price: 79.99, cost: 61.00, surewerxSku: 'SWX-EP-004', description: 'Custom molded reusable ear plugs', status: 'Active', visible: true },
      
      // Respiratory Protection (10 products)
      { id: 'prod83', name: 'Dust Mask - N95 (20pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 24.99, cost: 18.50, surewerxSku: 'SWX-DM-001', customSku: 'DM-N95-20PK', description: 'Pack of 20 N95 dust masks', status: 'Active', visible: true },
      { id: 'prod84', name: 'Half Mask Respirator - Reusable', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 34.99, cost: 26.50, surewerxSku: 'SWX-HM-001', customSku: 'RESP-HALF-001', description: 'Reusable half mask respirator (mask only)', status: 'Active', visible: true },
      { id: 'prod85', name: 'Respirator Filters - P100 (2pk)', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 19.99, cost: 14.50, surewerxSku: 'SWX-RF-001', description: 'Pair of P100 respirator filters', status: 'Active', visible: true },
      { id: 'prod86', name: 'Full Face Respirator', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 189.99, cost: 145.00, surewerxSku: 'SWX-FF-001', description: 'Full face respirator with head harness', status: 'Active', visible: true },
      { id: 'prod87', name: 'Disposable Respirator - N95 Valve (10pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 29.99, cost: 22.50, surewerxSku: 'SWX-DR-001', description: 'Pack of 10 N95 respirators with valve', status: 'Active', visible: true },
      { id: 'prod88', name: 'Organic Vapor Cartridges (2pk)', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 28.99, cost: 22.00, surewerxSku: 'SWX-OV-001', description: 'Pair of organic vapor cartridges', status: 'Active', visible: true },
      { id: 'prod89', name: 'PAPR System - Complete', category: 'Respiratory Protection', supplier: 'AirTech Pro', price: 899.99, cost: 685.00, surewerxSku: 'SWX-PAPR-001', description: 'Complete powered air purifying respirator system', status: 'Active', visible: true },
      { id: 'prod90', name: 'Dust Mask - P95 (50pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 59.99, cost: 45.50, surewerxSku: 'SWX-DM-002', description: 'Pack of 50 P95 dust masks', status: 'Active', visible: true },
      { id: 'prod91', name: 'Combination Cartridges - Multi-Gas', category: 'Respiratory Protection', supplier: 'ProGear Ltd', price: 42.99, cost: 32.50, surewerxSku: 'SWX-CC-001', description: 'Multi-gas combination cartridges (pair)', status: 'Active', visible: true },
      { id: 'prod92', name: 'Respirator Cleaning Wipes (100pk)', category: 'Respiratory Protection', supplier: 'SafetyFirst Inc', price: 14.99, cost: 11.00, surewerxSku: 'SWX-RW-001', description: 'Pack of 100 respirator cleaning wipes', status: 'Active', visible: true },
      
      // Fall Protection (8 products)
      { id: 'prod93', name: 'Safety Harness - Full Body', category: 'Fall Protection', supplier: 'HeightSafe', price: 149.99, cost: 114.00, surewerxSku: 'SWX-SH-001', description: 'Full body safety harness with D-ring', status: 'Active', visible: true },
      { id: 'prod94', name: 'Lanyard - 6ft Shock Absorbing', category: 'Fall Protection', supplier: 'HeightSafe', price: 89.99, cost: 68.00, surewerxSku: 'SWX-LA-001', description: '6 foot shock absorbing lanyard', status: 'Active', visible: true },
      { id: 'prod95', name: 'Retractable Lifeline - 30ft', category: 'Fall Protection', supplier: 'HeightSafe', price: 279.99, cost: 213.00, surewerxSku: 'SWX-RL-001', description: '30 foot self-retracting lifeline', status: 'Active', visible: true },
      { id: 'prod96', name: 'Anchor Point - Roof', category: 'Fall Protection', supplier: 'HeightSafe', price: 124.99, cost: 95.00, surewerxSku: 'SWX-AP-002', description: 'Permanent roof anchor point', status: 'Active', visible: true },
      { id: 'prod97', name: 'Rescue Kit - Confined Space', category: 'Fall Protection', supplier: 'HeightSafe', price: 499.99, cost: 380.00, surewerxSku: 'SWX-RK-001', description: 'Complete confined space rescue kit', status: 'Active', visible: true },
      { id: 'prod98', name: 'Safety Net - 10x10ft', category: 'Fall Protection', supplier: 'HeightSafe', price: 189.99, cost: 145.00, surewerxSku: 'SWX-SN-001', description: '10x10 foot safety catch net', status: 'Active', visible: true },
      { id: 'prod99', name: 'Harness Storage Bag', category: 'Fall Protection', supplier: 'HeightSafe', price: 34.99, cost: 26.50, surewerxSku: 'SWX-HS-001', description: 'Breathable storage bag for harnesses', status: 'Active', visible: true },
      { id: 'prod100', name: 'Tripod - Confined Space Entry', category: 'Fall Protection', supplier: 'HeightSafe', price: 899.99, cost: 685.00, surewerxSku: 'SWX-TP-001', description: 'Adjustable tripod for confined space entry', status: 'Active', visible: true }
    ];
    
    // Partners - initialize default partners
    var defaultPartners = [
      {
        id: 'p1',
        name: 'Boeing',
        slug: 'boeing',
        industry: 'Technology',
        contactEmail: 'contact@boeing.com',
        contactPhone: '(555) 123-4567',
        logoUrl: 'images/Boeing_full_logo..png',
        status: 'active',
        employeeCount: 45,
        activeVouchers: 3,
        monthlySpend: 12450.00,
        totalBudget: 50000,
        paymentMethods: ['Credit Card', 'Payroll Deduction'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: false,
          requireDateOfBirth: false,
          requireStartDate: true
        },
        employees: [
          {
            id: 'emp1',
            name: 'John Smith',
            email: 'john.smith@boeing.com',
            employeeId: 'EMP-001',
            username: 'jsmith',
            startDate: '2023-01-15',
            groupId: 'g1',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 250.00,
            voucherBalances: [
              { voucherId: 'v1', remainingAmount: 150.00 },
              { voucherId: 'v2', remainingAmount: 100.00 }
            ]
          },
          {
            id: 'emp2',
            name: 'Sarah Johnson',
            email: 'sarah.johnson@boeing.com',
            employeeId: 'EMP-002',
            username: 'sjohnson',
            startDate: '2023-03-20',
            groupId: 'g1',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 300.00,
            voucherBalances: [
              { voucherId: 'v1', remainingAmount: 200.00 },
              { voucherId: 'v2', remainingAmount: 100.00 }
            ]
          }
        ],
        groups: [
          {
            id: 'g1',
            name: 'Safety Team',
            department: 'Operations',
            location: 'Main Office',
            locationId: 'LOC-001',
            addressLine1: '1000 Boeing Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98108',
            locationAddress: '1000 Boeing Way, Seattle, WA 98108',
            employeeCount: 2,
            productIds: ['prod1', 'prod2', 'prod3'],
            categoryIds: ['Eye Protection', 'Head Protection']
          },
          {
            id: 'g2',
            name: 'Warehouse Staff',
            department: 'Logistics',
            location: 'Warehouse',
            locationId: 'WH-001',
            addressLine1: '2500 Distribution Blvd',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '2500 Distribution Blvd, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod2', 'prod3', 'prod4'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Body Protection']
          },
          {
            id: 'g10',
            name: 'Engineering Team',
            department: 'Engineering',
            location: 'Engineering Center',
            locationId: 'ENG-001',
            addressLine1: '1200 Engineering Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98124',
            locationAddress: '1200 Engineering Way, Seattle, WA 98124',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection']
          },
          {
            id: 'g11',
            name: 'Manufacturing Assembly',
            department: 'Manufacturing',
            location: 'Assembly Plant',
            locationId: 'ASM-001',
            addressLine1: '3000 Production Blvd',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '3000 Production Blvd, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g12',
            name: 'Quality Control',
            department: 'Quality Assurance',
            location: 'QC Lab',
            locationId: 'QC-001',
            addressLine1: '1500 Quality Dr',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '1500 Quality Dr, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod3', 'prod30', 'prod36'],
            categoryIds: ['Eye Protection', 'Hand Protection']
          },
          {
            id: 'g13',
            name: 'Maintenance Crew',
            department: 'Maintenance',
            location: 'Maintenance Facility',
            locationId: 'MAINT-001',
            addressLine1: '1800 Maintenance Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98108',
            locationAddress: '1800 Maintenance Way, Seattle, WA 98108',
            employeeCount: 0,
            productIds: ['prod5', 'prod16', 'prod28', 'prod32', 'prod52', 'prod61'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection']
          },
          {
            id: 'g14',
            name: 'Testing Laboratory',
            department: 'Testing',
            location: 'Test Facility',
            locationId: 'TEST-001',
            addressLine1: '2200 Test Center Dr',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '2200 Test Center Dr, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod3', 'prod30', 'prod83', 'prod84'],
            categoryIds: ['Eye Protection', 'Hand Protection', 'Respiratory Protection']
          },
          {
            id: 'g15',
            name: 'Tooling Department',
            department: 'Tooling',
            location: 'Tool Shop',
            locationId: 'TOOL-001',
            addressLine1: '900 Tooling Ave',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '900 Tooling Ave, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod5', 'prod16', 'prod28', 'prod32', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g16',
            name: 'Research & Development',
            department: 'R&D',
            location: 'R&D Center',
            locationId: 'RD-001',
            addressLine1: '500 Innovation Blvd',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98124',
            locationAddress: '500 Innovation Blvd, Seattle, WA 98124',
            employeeCount: 0,
            productIds: ['prod1', 'prod3', 'prod12', 'prod30', 'prod83'],
            categoryIds: ['Eye Protection', 'Hand Protection', 'Respiratory Protection']
          },
          {
            id: 'g17',
            name: 'Facilities Management',
            department: 'Facilities',
            location: 'Main Campus',
            locationId: 'FAC-001',
            addressLine1: '1000 Boeing Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98108',
            locationAddress: '1000 Boeing Way, Seattle, WA 98108',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection']
          },
          {
            id: 'g18',
            name: 'IT Support',
            department: 'Information Technology',
            location: 'IT Building',
            locationId: 'IT-001',
            addressLine1: '800 Technology Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98124',
            locationAddress: '800 Technology Way, Seattle, WA 98124',
            employeeCount: 0,
            productIds: ['prod1', 'prod13'],
            categoryIds: ['Eye Protection']
          },
          {
            id: 'g19',
            name: 'Security Team',
            department: 'Security',
            location: 'Security Office',
            locationId: 'SEC-001',
            addressLine1: '1000 Boeing Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98108',
            locationAddress: '1000 Boeing Way, Seattle, WA 98108',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod46'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Body Protection']
          },
          {
            id: 'g20',
            name: 'Paint Shop',
            department: 'Manufacturing',
            location: 'Paint Facility',
            locationId: 'PAINT-001',
            addressLine1: '3500 Paint Blvd',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '3500 Paint Blvd, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod3', 'prod16', 'prod28', 'prod34', 'prod46', 'prod61', 'prod73', 'prod83', 'prod84'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection', 'Respiratory Protection']
          },
          {
            id: 'g21',
            name: 'Composite Materials',
            department: 'Manufacturing',
            location: 'Composite Center',
            locationId: 'COMP-001',
            addressLine1: '2800 Composite Way',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '2800 Composite Way, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod3', 'prod16', 'prod28', 'prod34', 'prod46', 'prod61', 'prod73', 'prod83'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection', 'Respiratory Protection']
          },
          {
            id: 'g22',
            name: 'Wiring & Electrical',
            department: 'Manufacturing',
            location: 'Electrical Shop',
            locationId: 'ELEC-001',
            addressLine1: '1900 Electrical Ave',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '1900 Electrical Ave, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod22', 'prod28', 'prod41', 'prod61', 'prod67'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Foot Protection']
          },
          {
            id: 'g23',
            name: 'Charleston Assembly',
            department: 'Manufacturing',
            location: 'Charleston Plant',
            locationId: 'CHS-001',
            addressLine1: '5000 Aviation Way',
            addressCity: 'North Charleston',
            addressState: 'SC',
            addressZip: '29418',
            locationAddress: '5000 Aviation Way, North Charleston, SC 29418',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g24',
            name: 'St. Louis Defense',
            department: 'Defense',
            location: 'St. Louis Facility',
            locationId: 'STL-001',
            addressLine1: '6000 Defense Blvd',
            addressCity: 'St. Louis',
            addressState: 'MO',
            addressZip: '63134',
            locationAddress: '6000 Defense Blvd, St. Louis, MO 63134',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73', 'prod93'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection', 'Fall Protection']
          },
          {
            id: 'g25',
            name: 'Long Beach Operations',
            department: 'Operations',
            location: 'Long Beach Facility',
            locationId: 'LGB-001',
            addressLine1: '4000 Pacific Coast Hwy',
            addressCity: 'Long Beach',
            addressState: 'CA',
            addressZip: '90807',
            locationAddress: '4000 Pacific Coast Hwy, Long Beach, CA 90807',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g26',
            name: 'Philadelphia Manufacturing',
            department: 'Manufacturing',
            location: 'Philadelphia Plant',
            locationId: 'PHL-001',
            addressLine1: '7000 Industrial Blvd',
            addressCity: 'Philadelphia',
            addressState: 'PA',
            addressZip: '19153',
            locationAddress: '7000 Industrial Blvd, Philadelphia, PA 19153',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g27',
            name: 'Flight Test',
            department: 'Testing',
            location: 'Flight Test Center',
            locationId: 'FLT-001',
            addressLine1: '4500 Flight Test Way',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '4500 Flight Test Way, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73', 'prod74'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g28',
            name: 'Hydraulics Shop',
            department: 'Manufacturing',
            location: 'Hydraulics Facility',
            locationId: 'HYD-001',
            addressLine1: '1600 Hydraulics Dr',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '1600 Hydraulics Dr, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod34', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g29',
            name: 'Sheet Metal Fabrication',
            department: 'Manufacturing',
            location: 'Fabrication Shop',
            locationId: 'FAB-001',
            addressLine1: '2400 Fabrication Way',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '2400 Fabrication Way, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod5', 'prod16', 'prod28', 'prod32', 'prod46', 'prod52', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g30',
            name: 'Machining Center',
            department: 'Manufacturing',
            location: 'Machine Shop',
            locationId: 'MACH-001',
            addressLine1: '1100 Machine Way',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '1100 Machine Way, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod37', 'prod46', 'prod61', 'prod73', 'prod74'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g31',
            name: 'Environmental Health',
            department: 'Safety',
            location: 'Safety Office',
            locationId: 'EHS-001',
            addressLine1: '1000 Boeing Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98108',
            locationAddress: '1000 Boeing Way, Seattle, WA 98108',
            employeeCount: 0,
            productIds: ['prod1', 'prod3', 'prod30', 'prod36', 'prod83', 'prod84'],
            categoryIds: ['Eye Protection', 'Hand Protection', 'Respiratory Protection']
          },
          {
            id: 'g32',
            name: 'Material Handling',
            department: 'Logistics',
            location: 'Material Warehouse',
            locationId: 'MAT-001',
            addressLine1: '2500 Distribution Blvd',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '2500 Distribution Blvd, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g33',
            name: 'Calibration Lab',
            department: 'Quality Assurance',
            location: 'Calibration Facility',
            locationId: 'CAL-001',
            addressLine1: '1500 Quality Dr',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '1500 Quality Dr, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod3', 'prod30'],
            categoryIds: ['Eye Protection', 'Hand Protection']
          },
          {
            id: 'g34',
            name: 'Aerospace Systems',
            department: 'Engineering',
            location: 'Systems Engineering',
            locationId: 'SYS-001',
            addressLine1: '1200 Engineering Way',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98124',
            locationAddress: '1200 Engineering Way, Seattle, WA 98124',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection']
          },
          {
            id: 'g35',
            name: 'Plastics & Composites',
            department: 'Manufacturing',
            location: 'Plastics Facility',
            locationId: 'PLAST-001',
            addressLine1: '2800 Composite Way',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '2800 Composite Way, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod3', 'prod16', 'prod28', 'prod34', 'prod46', 'prod61', 'prod73', 'prod83'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection', 'Respiratory Protection']
          },
          {
            id: 'g36',
            name: 'Avionics Installation',
            department: 'Manufacturing',
            location: 'Avionics Shop',
            locationId: 'AVI-001',
            addressLine1: '2000 Avionics Blvd',
            addressCity: 'Renton',
            addressState: 'WA',
            addressZip: '98057',
            locationAddress: '2000 Avionics Blvd, Renton, WA 98057',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod22', 'prod28', 'prod41', 'prod61'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Foot Protection']
          },
          {
            id: 'g37',
            name: 'Interior Installation',
            department: 'Manufacturing',
            location: 'Interior Shop',
            locationId: 'INT-001',
            addressLine1: '3200 Interior Way',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '3200 Interior Way, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g38',
            name: 'Ground Support',
            department: 'Operations',
            location: 'Ground Operations',
            locationId: 'GND-001',
            addressLine1: '5500 Ground Support Way',
            addressCity: 'Everett',
            addressState: 'WA',
            addressZip: '98204',
            locationAddress: '5500 Ground Support Way, Everett, WA 98204',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod48', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g39',
            name: 'Training Center',
            department: 'Training',
            location: 'Training Facility',
            locationId: 'TRN-001',
            addressLine1: '700 Training Center Dr',
            addressCity: 'Seattle',
            addressState: 'WA',
            addressZip: '98124',
            locationAddress: '700 Training Center Dr, Seattle, WA 98124',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection']
          }
        ],
        vouchers: [
          {
            id: 'v1',
            name: 'Monthly Safety Allowance',
            description: 'Standard monthly safety equipment allowance',
            defaultAmount: 150.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod1', 'prod2', 'prod3'],
            userGroupIds: ['g1', 'g2']
          },
          {
            id: 'v2',
            name: 'Quarterly PPE Budget',
            description: 'Quarterly personal protective equipment budget',
            defaultAmount: 300.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: false,
            rolloverEnabled: true,
            productIds: ['prod1', 'prod2', 'prod3', 'prod4'],
            userGroupIds: ['g1']
          }
        ],
        availableProducts: this.products.slice()
      },
      {
        id: 'p2',
        name: 'Manufacturing Corp',
        slug: 'manufacturing-corp',
        industry: 'Manufacturing',
        contactEmail: 'info@manufacturing.com',
        contactPhone: '(555) 234-5678',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiMxNmEzNGEiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk08L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 78,
        activeVouchers: 5,
        monthlySpend: 23800.00,
        totalBudget: 100000,
        paymentMethods: ['Credit Card'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: true,
          requireDateOfBirth: true,
          requireStartDate: true
        },
        employees: [],
        groups: [
          {
            id: 'g3',
            name: 'Production Floor',
            department: 'Production',
            location: 'Manufacturing Plant',
            locationId: 'MFG-001',
            addressLine1: '1800 Industrial Ave',
            addressCity: 'Cleveland',
            addressState: 'OH',
            addressZip: '44101',
            locationAddress: '1800 Industrial Ave, Cleveland, OH 44101',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g3b',
            name: 'Maintenance',
            department: 'Maintenance',
            location: 'Maintenance Shop',
            locationId: 'MAINT-MFG-001',
            addressLine1: '1800 Industrial Ave',
            addressCity: 'Cleveland',
            addressState: 'OH',
            addressZip: '44101',
            locationAddress: '1800 Industrial Ave, Cleveland, OH 44101',
            employeeCount: 0,
            productIds: ['prod5', 'prod16', 'prod28', 'prod32', 'prod52', 'prod61'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection']
          }
        ],
        vouchers: [],
        availableProducts: this.products.slice()
      },
      {
        id: 'p3',
        name: 'Construction Services',
        slug: 'construction-services',
        industry: 'Construction',
        contactEmail: 'hello@construction.com',
        contactPhone: '(555) 345-6789',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiNmNTllMGIiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkM8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 62,
        activeVouchers: 4,
        monthlySpend: 18900.00,
        totalBudget: 75000,
        paymentMethods: ['Credit Card', 'Payroll Deduction'],
        employeeFieldConfig: {
          requireEmployeeId: false,
          requireUsername: true,
          requireDateOfBirth: false,
          requireStartDate: true
        },
        employees: [],
        groups: [
          {
            id: 'g4',
            name: 'Site Workers',
            department: 'Field Operations',
            location: 'Construction Site',
            locationId: 'SITE-001',
            addressLine1: '1200 Building Way',
            addressCity: 'Denver',
            addressState: 'CO',
            addressZip: '80201',
            locationAddress: '1200 Building Way, Denver, CO 80201',
            employeeCount: 0,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61', 'prod73', 'prod93'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection', 'Hearing Protection', 'Fall Protection']
          }
        ],
        vouchers: [],
        availableProducts: this.products.slice()
      },
      {
        id: 'p4',
        name: 'Healthcare Systems Ltd',
        slug: 'healthcare-systems-ltd',
        industry: 'Healthcare',
        contactEmail: 'contact@healthcare.com',
        contactPhone: '(555) 456-7890',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiNlNzM0ZjMiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkg8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 120,
        activeVouchers: 6,
        monthlySpend: 15200.00,
        totalBudget: 80000,
        paymentMethods: ['Credit Card', 'Payroll Deduction'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: true,
          requireDateOfBirth: true,
          requireStartDate: true
        },
        employees: [
          {
            id: 'emp3',
            name: 'Dr. Emily Rodriguez',
            email: 'emily.rodriguez@healthcare.com',
            employeeId: 'HC-001',
            username: 'erodriguez',
            dateOfBirth: '1985-03-15',
            startDate: '2022-06-01',
            groupId: 'g5',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 200.00,
            voucherBalances: [
              { voucherId: 'v3', remainingAmount: 200.00 }
            ]
          },
          {
            id: 'emp4',
            name: 'Michael Chen',
            email: 'michael.chen@healthcare.com',
            employeeId: 'HC-002',
            username: 'mchen',
            dateOfBirth: '1990-07-22',
            startDate: '2023-02-10',
            groupId: 'g5',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 150.00,
            voucherBalances: [
              { voucherId: 'v3', remainingAmount: 150.00 }
            ]
          }
        ],
        groups: [
          {
            id: 'g5',
            name: 'Clinical Staff',
            department: 'Clinical',
            location: 'Main Hospital',
            locationId: 'HOSP-001',
            addressLine1: '500 Medical Center Dr',
            addressCity: 'Chicago',
            addressState: 'IL',
            addressZip: '60611',
            locationAddress: '500 Medical Center Dr, Chicago, IL 60611',
            employeeCount: 2,
            productIds: ['prod30', 'prod36', 'prod83', 'prod84'],
            categoryIds: ['Hand Protection', 'Respiratory Protection']
          },
          {
            id: 'g5b',
            name: 'Administrative',
            department: 'Administration',
            location: 'Main Office',
            locationId: 'ADMIN-001',
            addressLine1: '500 Medical Center Dr',
            addressCity: 'Chicago',
            addressState: 'IL',
            addressZip: '60611',
            locationAddress: '500 Medical Center Dr, Chicago, IL 60611',
            employeeCount: 0,
            productIds: [],
            categoryIds: []
          }
        ],
        vouchers: [
          {
            id: 'v3',
            name: 'Healthcare PPE Allowance',
            description: 'Monthly PPE allowance for clinical staff',
            defaultAmount: 200.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod30', 'prod36', 'prod83', 'prod84'],
            userGroupIds: ['g5']
          }
        ],
        availableProducts: this.products.slice()
      },
      {
        id: 'p5',
        name: 'Energy Solutions Group',
        slug: 'energy-solutions-group',
        industry: 'Energy',
        contactEmail: 'info@energy.com',
        contactPhone: '(555) 567-8901',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiNmZmMxMDciLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkU8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 95,
        activeVouchers: 4,
        monthlySpend: 22100.00,
        totalBudget: 120000,
        paymentMethods: ['Credit Card'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: false,
          requireDateOfBirth: false,
          requireStartDate: true
        },
        employees: [
          {
            id: 'emp5',
            name: 'James Wilson',
            email: 'james.wilson@energy.com',
            employeeId: 'EN-001',
            startDate: '2021-04-12',
            groupId: 'g6',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 300.00,
            voucherBalances: [
              { voucherId: 'v4', remainingAmount: 300.00 }
            ]
          },
          {
            id: 'emp6',
            name: 'Patricia Martinez',
            email: 'patricia.martinez@energy.com',
            employeeId: 'EN-002',
            startDate: '2022-09-05',
            groupId: 'g6b',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 250.00,
            voucherBalances: [
              { voucherId: 'v5', remainingAmount: 250.00 }
            ]
          }
        ],
        groups: [
          {
            id: 'g6',
            name: 'Field Operations',
            department: 'Operations',
            location: 'Field Site A',
            locationId: 'FLD-001',
            addressLine1: '1500 Construction Way',
            addressCity: 'Phoenix',
            addressState: 'AZ',
            addressZip: '85001',
            locationAddress: '1500 Construction Way, Phoenix, AZ 85001',
            employeeCount: 1,
            productIds: ['prod16', 'prod46', 'prod61', 'prod93'],
            categoryIds: ['Head Protection', 'Body Protection', 'Foot Protection', 'Fall Protection']
          },
          {
            id: 'g6b',
            name: 'Maintenance Team',
            department: 'Maintenance',
            location: 'Main Facility',
            locationId: 'MAINT-001',
            addressLine1: '1500 Construction Way',
            addressCity: 'Phoenix',
            addressState: 'AZ',
            addressZip: '85001',
            locationAddress: '1500 Construction Way, Phoenix, AZ 85001',
            employeeCount: 1,
            productIds: ['prod16', 'prod28', 'prod61', 'prod73'],
            categoryIds: ['Head Protection', 'Hand Protection', 'Foot Protection', 'Hearing Protection']
          }
        ],
        vouchers: [
          {
            id: 'v4',
            name: 'Field Safety Equipment',
            description: 'Quarterly safety equipment for field operations',
            defaultAmount: 300.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: true,
            productIds: ['prod16', 'prod46', 'prod61', 'prod93'],
            userGroupIds: ['g6']
          },
          {
            id: 'v5',
            name: 'Maintenance PPE Budget',
            description: 'Monthly PPE budget for maintenance staff',
            defaultAmount: 250.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod16', 'prod28', 'prod61', 'prod73'],
            userGroupIds: ['g6b']
          }
        ],
        availableProducts: this.products.slice()
      },
      {
        id: 'p6',
        name: 'Logistics & Transport Co',
        slug: 'logistics-transport-co',
        industry: 'Transportation',
        contactEmail: 'hello@logistics.com',
        contactPhone: '(555) 678-9012',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiM0M2U1YjUiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkw8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 150,
        activeVouchers: 7,
        monthlySpend: 28900.00,
        totalBudget: 150000,
        paymentMethods: ['Credit Card', 'Payroll Deduction'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: true,
          requireDateOfBirth: true,
          requireStartDate: true
        },
        employees: [
          {
            id: 'emp7',
            name: 'Robert Thompson',
            email: 'robert.thompson@logistics.com',
            employeeId: 'LT-001',
            username: 'rthompson',
            dateOfBirth: '1988-11-30',
            startDate: '2020-03-15',
            groupId: 'g7',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 180.00,
            voucherBalances: [
              { voucherId: 'v6', remainingAmount: 180.00 }
            ]
          },
          {
            id: 'emp8',
            name: 'Jennifer Lee',
            email: 'jennifer.lee@logistics.com',
            employeeId: 'LT-002',
            username: 'jlee',
            dateOfBirth: '1992-05-18',
            startDate: '2021-08-20',
            groupId: 'g7',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 180.00,
            voucherBalances: [
              { voucherId: 'v6', remainingAmount: 180.00 }
            ]
          },
          {
            id: 'emp9',
            name: 'David Brown',
            email: 'david.brown@logistics.com',
            employeeId: 'LT-003',
            username: 'dbrown',
            dateOfBirth: '1985-09-12',
            startDate: '2019-11-01',
            groupId: 'g7b',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 200.00,
            voucherBalances: [
              { voucherId: 'v7', remainingAmount: 200.00 }
            ]
          }
        ],
        groups: [
          {
            id: 'g7',
            name: 'Drivers',
            department: 'Transportation',
            location: 'Main Depot',
            locationId: 'DEPOT-001',
            addressLine1: '3000 Logistics Blvd',
            addressCity: 'Dallas',
            addressState: 'TX',
            addressZip: '75201',
            locationAddress: '3000 Logistics Blvd, Dallas, TX 75201',
            employeeCount: 2,
            productIds: ['prod46', 'prod48', 'prod61', 'prod73'],
            categoryIds: ['Body Protection', 'Foot Protection', 'Hearing Protection']
          },
          {
            id: 'g7b',
            name: 'Warehouse Staff',
            department: 'Warehouse',
            location: 'Distribution Center',
            locationId: 'DC-001',
            addressLine1: '3000 Logistics Blvd',
            addressCity: 'Dallas',
            addressState: 'TX',
            addressZip: '75201',
            locationAddress: '3000 Logistics Blvd, Dallas, TX 75201',
            employeeCount: 1,
            productIds: ['prod16', 'prod28', 'prod46', 'prod61'],
            categoryIds: ['Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection']
          }
        ],
        vouchers: [
          {
            id: 'v6',
            name: 'Driver Safety Allowance',
            description: 'Monthly safety equipment for drivers',
            defaultAmount: 180.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod46', 'prod48', 'prod61', 'prod73'],
            userGroupIds: ['g7']
          },
          {
            id: 'v7',
            name: 'Warehouse PPE Fund',
            description: 'Monthly PPE fund for warehouse operations',
            defaultAmount: 200.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: true,
            productIds: ['prod16', 'prod28', 'prod46', 'prod61'],
            userGroupIds: ['g7b']
          }
        ],
        availableProducts: this.products.slice()
      },
      {
        id: 'p7',
        name: 'Food Processing Industries',
        slug: 'food-processing-industries',
        industry: 'Food & Beverage',
        contactEmail: 'contact@foodprocessing.com',
        contactPhone: '(555) 789-0123',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiM4YjVjZjYiLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkY8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 200,
        activeVouchers: 8,
        monthlySpend: 31200.00,
        totalBudget: 180000,
        paymentMethods: ['Credit Card'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: false,
          requireDateOfBirth: true,
          requireStartDate: true
        },
        employees: [
          {
            id: 'emp10',
            name: 'Maria Garcia',
            email: 'maria.garcia@foodprocessing.com',
            employeeId: 'FP-001',
            dateOfBirth: '1991-02-14',
            startDate: '2022-01-10',
            groupId: 'g8',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 175.00,
            voucherBalances: [
              { voucherId: 'v8', remainingAmount: 175.00 }
            ]
          },
          {
            id: 'emp11',
            name: 'Thomas Anderson',
            email: 'thomas.anderson@foodprocessing.com',
            employeeId: 'FP-002',
            dateOfBirth: '1987-08-25',
            startDate: '2021-05-20',
            groupId: 'g8',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 175.00,
            voucherBalances: [
              { voucherId: 'v8', remainingAmount: 175.00 }
            ]
          },
          {
            id: 'emp12',
            name: 'Lisa White',
            email: 'lisa.white@foodprocessing.com',
            employeeId: 'FP-003',
            dateOfBirth: '1993-12-08',
            startDate: '2023-03-15',
            groupId: 'g8b',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 150.00,
            voucherBalances: [
              { voucherId: 'v9', remainingAmount: 150.00 }
            ]
          }
        ],
        groups: [
          {
            id: 'g8',
            name: 'Production Line',
            department: 'Production',
            location: 'Processing Plant',
            locationId: 'PLANT-001',
            addressLine1: '2000 Industrial Park Dr',
            addressCity: 'Houston',
            addressState: 'TX',
            addressZip: '77001',
            locationAddress: '2000 Industrial Park Dr, Houston, TX 77001',
            employeeCount: 2,
            productIds: ['prod30', 'prod36', 'prod46', 'prod49', 'prod83'],
            categoryIds: ['Hand Protection', 'Body Protection', 'Respiratory Protection']
          },
          {
            id: 'g8b',
            name: 'Quality Control',
            department: 'Quality Assurance',
            location: 'Lab Facility',
            locationId: 'LAB-001',
            addressLine1: '2000 Industrial Park Dr',
            addressCity: 'Houston',
            addressState: 'TX',
            addressZip: '77001',
            locationAddress: '2000 Industrial Park Dr, Houston, TX 77001',
            employeeCount: 1,
            productIds: ['prod30', 'prod36', 'prod49', 'prod58'],
            categoryIds: ['Hand Protection', 'Body Protection']
          }
        ],
        vouchers: [
          {
            id: 'v8',
            name: 'Production Safety Equipment',
            description: 'Monthly safety equipment for production staff',
            defaultAmount: 175.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod30', 'prod36', 'prod46', 'prod49', 'prod83'],
            userGroupIds: ['g8']
          },
          {
            id: 'v9',
            name: 'QC Lab Equipment',
            description: 'Monthly PPE for quality control lab',
            defaultAmount: 150.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod30', 'prod36', 'prod49', 'prod58'],
            userGroupIds: ['g8b']
          }
        ],
        availableProducts: this.products.slice()
      },
      {
        id: 'p8',
        name: 'Automotive Parts Manufacturing',
        slug: 'automotive-parts-manufacturing',
        industry: 'Automotive',
        contactEmail: 'info@autoparts.com',
        contactPhone: '(555) 890-1234',
        logoUrl: 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIGZpbGw9IiM2NzI4NzciLz48dGV4dCB4PSI1MCUiIHk9IjUwJSIgZm9udC1mYW1pbHk9IkFyaWFsIiBmb250LXNpemU9IjIwIiBmaWxsPSJ3aGl0ZSIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkE8L3RleHQ+PC9zdmc+',
        status: 'active',
        employeeCount: 175,
        activeVouchers: 5,
        monthlySpend: 26700.00,
        totalBudget: 140000,
        paymentMethods: ['Credit Card', 'Payroll Deduction'],
        employeeFieldConfig: {
          requireEmployeeId: true,
          requireUsername: true,
          requireDateOfBirth: false,
          requireStartDate: true
        },
        employees: [
          {
            id: 'emp13',
            name: 'Christopher Taylor',
            email: 'christopher.taylor@autoparts.com',
            employeeId: 'AP-001',
            username: 'ctaylor',
            startDate: '2020-07-01',
            groupId: 'g9',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 220.00,
            voucherBalances: [
              { voucherId: 'v10', remainingAmount: 220.00 }
            ]
          },
          {
            id: 'emp14',
            name: 'Amanda Johnson',
            email: 'amanda.johnson@autoparts.com',
            employeeId: 'AP-002',
            username: 'ajohnson',
            startDate: '2021-11-15',
            groupId: 'g9',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 220.00,
            voucherBalances: [
              { voucherId: 'v10', remainingAmount: 220.00 }
            ]
          },
          {
            id: 'emp15',
            name: 'Daniel Kim',
            email: 'daniel.kim@autoparts.com',
            employeeId: 'AP-003',
            username: 'dkim',
            startDate: '2022-04-22',
            groupId: 'g9b',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 250.00,
            voucherBalances: [
              { voucherId: 'v11', remainingAmount: 250.00 }
            ]
          },
          {
            id: 'emp16',
            name: 'Rachel Moore',
            email: 'rachel.moore@autoparts.com',
            employeeId: 'AP-004',
            username: 'rmoore',
            startDate: '2023-01-08',
            groupId: 'g9b',
            voucherExpiry: '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: 250.00,
            voucherBalances: [
              { voucherId: 'v11', remainingAmount: 250.00 }
            ]
          }
        ],
        groups: [
          {
            id: 'g9',
            name: 'Assembly Line',
            department: 'Manufacturing',
            location: 'Plant Floor A',
            locationId: 'PLANT-A-001',
            addressLine1: '4000 Manufacturing Ave',
            addressCity: 'Detroit',
            addressState: 'MI',
            addressZip: '48201',
            locationAddress: '4000 Manufacturing Ave, Detroit, MI 48201',
            employeeCount: 2,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61'],
            categoryIds: ['Eye Protection', 'Head Protection', 'Hand Protection', 'Body Protection', 'Foot Protection']
          },
          {
            id: 'g9b',
            name: 'Welding Department',
            department: 'Manufacturing',
            location: 'Welding Bay',
            locationId: 'WELD-001',
            addressLine1: '4000 Manufacturing Ave',
            addressCity: 'Detroit',
            addressState: 'MI',
            addressZip: '48201',
            locationAddress: '4000 Manufacturing Ave, Detroit, MI 48201',
            employeeCount: 2,
            productIds: ['prod5', 'prod32', 'prod52', 'prod84'],
            categoryIds: ['Eye Protection', 'Hand Protection', 'Body Protection', 'Respiratory Protection']
          }
        ],
        vouchers: [
          {
            id: 'v10',
            name: 'Assembly Line Safety',
            description: 'Monthly safety equipment for assembly workers',
            defaultAmount: 220.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: false,
            productIds: ['prod1', 'prod16', 'prod28', 'prod46', 'prod61'],
            userGroupIds: ['g9']
          },
          {
            id: 'v11',
            name: 'Welding PPE Budget',
            description: 'Monthly PPE budget for welding operations',
            defaultAmount: 250.00,
            startDate: '2024-01-01',
            endDate: '2024-12-31',
            isActive: true,
            autoRenewal: true,
            rolloverEnabled: true,
            productIds: ['prod5', 'prod32', 'prod52', 'prod84'],
            userGroupIds: ['g9b']
          }
        ],
        availableProducts: this.products.slice()
      }
    ];
    
    // Only initialize if not already set, or merge new partners if they don't exist
    if (!this.partners || this.partners.length === 0) {
      this.partners = defaultPartners;
    } else {
      // Merge new partners that don't already exist (by ID), or update existing ones with mock data
      var existingIds = this.partners.map(function(p) { return p.id; });
      defaultPartners.forEach(function(newPartner) {
        var existingIndex = existingIds.indexOf(newPartner.id);
        if (existingIndex === -1) {
          // New partner - add it
          this.partners.push(newPartner);
        } else {
          // Existing partner - update basic info and mock data if needed
          var existingPartner = this.partners[existingIndex];
          
          // Update basic partner info (name, slug, logo, contact info) for p1 (Boeing)
          if (newPartner.id === 'p1') {
            existingPartner.name = newPartner.name;
            existingPartner.slug = newPartner.slug;
            existingPartner.logoUrl = newPartner.logoUrl;
            existingPartner.contactEmail = newPartner.contactEmail;
          }
          
          // Always update employeeFieldConfig to match default (to ensure consistency)
          if (newPartner.employeeFieldConfig) {
            existingPartner.employeeFieldConfig = newPartner.employeeFieldConfig;
          }
          
          // Only update if the partner has no employees, groups, or vouchers (to preserve user-created data)
          if ((!existingPartner.employees || existingPartner.employees.length === 0) &&
              (!existingPartner.groups || existingPartner.groups.length === 0) &&
              (!existingPartner.vouchers || existingPartner.vouchers.length === 0)) {
            // Update with mock data
            existingPartner.employees = newPartner.employees;
            existingPartner.groups = newPartner.groups;
            existingPartner.vouchers = newPartner.vouchers;
            // Update employee count to match
            if (newPartner.employees && newPartner.employees.length > 0) {
              existingPartner.employeeCount = newPartner.employees.length;
            }
            // Update active vouchers count
            if (newPartner.vouchers && newPartner.vouchers.length > 0) {
              existingPartner.activeVouchers = newPartner.vouchers.filter(function(v) { return v.isActive; }).length;
            }
          } else {
            // Update existing groups with locationId, locationAddress, and address fields if they don't have them
            if (existingPartner.groups && existingPartner.groups.length > 0 && newPartner.groups && newPartner.groups.length > 0) {
              existingPartner.groups.forEach(function(existingGroup) {
                // Find matching group in mock data by ID
                var mockGroup = newPartner.groups.find(function(g) { return g.id === existingGroup.id; });
                if (mockGroup) {
                  // Update locationId and locationAddress if missing
                  if (!existingGroup.locationId && mockGroup.locationId) {
                    existingGroup.locationId = mockGroup.locationId;
                  }
                  if (!existingGroup.locationAddress && mockGroup.locationAddress) {
                    existingGroup.locationAddress = mockGroup.locationAddress;
                  }
                  // Also ensure department and location are set if missing
                  if (!existingGroup.department && mockGroup.department) {
                    existingGroup.department = mockGroup.department;
                  }
                  if (!existingGroup.location && mockGroup.location) {
                    existingGroup.location = mockGroup.location;
                  }
                  // Update address fields if missing
                  if (!existingGroup.addressLine1 && mockGroup.addressLine1) {
                    existingGroup.addressLine1 = mockGroup.addressLine1;
                  }
                  if (!existingGroup.addressCity && mockGroup.addressCity) {
                    existingGroup.addressCity = mockGroup.addressCity;
                  }
                  if (!existingGroup.addressState && mockGroup.addressState) {
                    existingGroup.addressState = mockGroup.addressState;
                  }
                  if (!existingGroup.addressZip && mockGroup.addressZip) {
                    existingGroup.addressZip = mockGroup.addressZip;
                  }
                }
              });
              
              // Add any groups from mock data that don't exist in existing partner
              var existingGroupIds = existingPartner.groups.map(function(g) { return g.id; });
              newPartner.groups.forEach(function(mockGroup) {
                if (existingGroupIds.indexOf(mockGroup.id) === -1) {
                  // Group doesn't exist, add it
                  existingPartner.groups.push(mockGroup);
                }
              });
            } else if (newPartner.groups && newPartner.groups.length > 0) {
              // Partner has no groups but mock data does - add them
              existingPartner.groups = newPartner.groups.slice();
            }
          }
        }
      }.bind(this));
      
      // Populate employees from transactions for all partners
      this.populateEmployeesFromTransactions();
      
      // Enrich transactions with invoice, shipping, and payment breakdown fields
      this.enrichTransactions();
      
      // Save merged partners
      this.savePartners();
    }
    
    // Distributors (for SureWerx employees to select from)
    this.distributors = [
      {
        id: 'd1',
        name: 'Fastenal',
        logo: 'images/Fastenal_logo.png'
      },
      {
        id: 'd2',
        name: 'Grainger',
        logo: 'images/Grainger_logo.png'
      },
      {
        id: 'd3',
        name: 'MSC Industrial Supply',
        logo: 'images/msc-logo.png'
      },
      {
        id: 'd4',
        name: 'Motion Industries',
        logo: 'images/motion-industries-logo.png'
      }
    ];
    
    // Users
    this.users = [
      {
        id: 'u1',
        email: 'admin@distributor.com',
        password: 'admin123',
        firstName: 'Admin',
        lastName: 'User',
        role: 'Distributor',
        partnerId: null,
        status: 'Active'
      },
      {
        id: 'u2',
        email: 'partner@boeing.com',
        password: 'partner123',
        firstName: 'Partner',
        lastName: 'User',
        role: 'Partner',
        partnerId: 'p1',
        status: 'Active'
      },
      {
        id: 'u3',
        email: 'surewerx@example.com',
        password: 'surewerx123',
        firstName: 'SureWerx',
        lastName: 'Employee',
        role: 'SureWerx',
        partnerId: null,
        status: 'Active'
      }
    ];
    
    // Transactions - 25 demo transactions across different partners and time periods
    this.transactions = [
      { id: 't1', orderId: 'ORD-2024-001', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't2', orderId: 'ORD-2024-001', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-11-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't3', orderId: 'ORD-2024-002', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-10-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't4', orderId: 'ORD-2024-002', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-10-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't5', orderId: 'ORD-2024-003', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-10-15', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't6', orderId: 'ORD-2024-004', employeeName: 'Mike Davis', employeeEmail: 'mike.davis@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Ear Plugs - Foam (200 pairs)', surewerxPartNumber: 'SWX-EP-001', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.50, dateOrdered: '2024-11-05', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Processing', paymentMethod: 'Voucher' },
      { id: 't7', orderId: 'ORD-2024-004', employeeName: 'Mike Davis', employeeEmail: 'mike.davis@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Safety Goggles - Anti-Fog', surewerxPartNumber: 'SWX-SG-003', distributorPartNumber: '', quantity: 4, unitPrice: 22.99, totalPrice: 91.96, distributorCost: 16.00, dateOrdered: '2024-11-05', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Processing', paymentMethod: 'Credit Card' },
      { id: 't8', orderId: 'ORD-2024-005', employeeName: 'Lisa Chen', employeeEmail: 'lisa.chen@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Hard Hat - Full Brim', surewerxPartNumber: 'SWX-HH-006', distributorPartNumber: '', quantity: 1, unitPrice: 32.99, totalPrice: 32.99, distributorCost: 25.00, dateOrdered: '2024-11-03', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't9', orderId: 'ORD-2024-005', employeeName: 'Lisa Chen', employeeEmail: 'lisa.chen@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Work Gloves - Cowhide', surewerxPartNumber: 'SWX-GL-004', distributorPartNumber: '', quantity: 5, unitPrice: 14.99, totalPrice: 74.95, distributorCost: 11.00, dateOrdered: '2024-11-03', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't10', orderId: 'ORD-2024-006', employeeName: 'Robert Martinez', employeeEmail: 'robert.martinez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Reflective Vest - Class 3', surewerxPartNumber: 'SWX-RV-001', distributorPartNumber: '', quantity: 2, unitPrice: 29.99, totalPrice: 59.98, distributorCost: 22.50, dateOrdered: '2024-10-30', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't11', orderId: 'ORD-2024-007', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-10-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't12', orderId: 'ORD-2024-008', employeeName: 'Tom Wilson', employeeEmail: 'tom.wilson@manufacturing.com', employeeGroup: 'Maintenance', partnerName: 'Manufacturing Corp', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-10-20', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Returned', paymentMethod: 'Voucher' },
      { id: 't13', orderId: 'ORD-2024-009', employeeName: 'Anna Rodriguez', employeeEmail: 'anna.rodriguez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-10-18', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't14', orderId: 'ORD-2024-009', employeeName: 'Anna Rodriguez', employeeEmail: 'anna.rodriguez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-10-18', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't15', orderId: 'ORD-2024-010', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-10-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't16', orderId: 'ORD-2024-011', employeeName: 'David Kim', employeeEmail: 'david.kim@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-10-10', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Cancelled', paymentMethod: 'Voucher' },
      { id: 't17', orderId: 'ORD-2024-012', employeeName: 'Jessica Brown', employeeEmail: 'jessica.brown@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-10-05', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't18', orderId: 'ORD-2024-013', employeeName: 'Carlos Garcia', employeeEmail: 'carlos.garcia@manufacturing.com', employeeGroup: 'Maintenance', partnerName: 'Manufacturing Corp', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-10-01', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't19', orderId: 'ORD-2024-014', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-09-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't20', orderId: 'ORD-2024-015', employeeName: 'Michael Lee', employeeEmail: 'michael.lee@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Hard Hat - Vented', surewerxPartNumber: 'SWX-HH-005', distributorPartNumber: '', quantity: 2, unitPrice: 29.99, totalPrice: 59.98, distributorCost: 22.50, dateOrdered: '2024-09-25', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't21', orderId: 'ORD-2024-016', employeeName: 'Emma White', employeeEmail: 'emma.white@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-09-20', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Returned', paymentMethod: 'Voucher' },
      { id: 't22', orderId: 'ORD-2024-017', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-09-15', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't23', orderId: 'ORD-2024-018', employeeName: 'James Taylor', employeeEmail: 'james.taylor@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-09-10', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't24', orderId: 'ORD-2024-019', employeeName: 'Sophia Anderson', employeeEmail: 'sophia.anderson@manufacturing.com', employeeGroup: 'Quality Control', partnerName: 'Manufacturing Corp', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-09-05', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't25', orderId: 'ORD-2024-020', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-08-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Mixed payment method transactions - voucher + credit card
      { id: 't26', orderId: 'ORD-2024-021', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-11-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't27', orderId: 'ORD-2024-021', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-11-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't28', orderId: 'ORD-2024-021', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't29', orderId: 'ORD-2024-022', employeeName: 'Lisa Chen', employeeEmail: 'lisa.chen@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-11-08', voucherUsed: 'PPE Allowance', voucherAmount: 50.00, lineStatus: 'Processing', paymentMethod: 'Mixed' },
      { id: 't30', orderId: 'ORD-2024-022', employeeName: 'Lisa Chen', employeeEmail: 'lisa.chen@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Work Gloves - Cowhide', surewerxPartNumber: 'SWX-GL-004', distributorPartNumber: '', quantity: 3, unitPrice: 14.99, totalPrice: 44.97, distributorCost: 11.00, dateOrdered: '2024-11-08', voucherUsed: 'PPE Allowance', voucherAmount: 50.00, lineStatus: 'Processing', paymentMethod: 'Mixed' },
      { id: 't31', orderId: 'ORD-2024-023', employeeName: 'Mike Davis', employeeEmail: 'mike.davis@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-11-07', voucherUsed: 'Safety Equipment Fund', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't32', orderId: 'ORD-2024-023', employeeName: 'Mike Davis', employeeEmail: 'mike.davis@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Safety Goggles - Anti-Fog', surewerxPartNumber: 'SWX-SG-003', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 16.00, dateOrdered: '2024-11-07', voucherUsed: 'Safety Equipment Fund', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't33', orderId: 'ORD-2024-024', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-11-06', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't34', orderId: 'ORD-2024-024', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.50, dateOrdered: '2024-11-06', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't35', orderId: 'ORD-2024-025', employeeName: 'Robert Martinez', employeeEmail: 'robert.martinez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Hard Hat - Full Brim', surewerxPartNumber: 'SWX-HH-006', distributorPartNumber: '', quantity: 1, unitPrice: 32.99, totalPrice: 32.99, distributorCost: 25.00, dateOrdered: '2024-11-05', voucherUsed: 'PPE Allowance', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      { id: 't36', orderId: 'ORD-2024-025', employeeName: 'Robert Martinez', employeeEmail: 'robert.martinez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Reflective Vest - Class 3', surewerxPartNumber: 'SWX-RV-001', distributorPartNumber: '', quantity: 1, unitPrice: 29.99, totalPrice: 29.99, distributorCost: 22.50, dateOrdered: '2024-11-05', voucherUsed: 'PPE Allowance', voucherAmount: 50.00, lineStatus: 'Shipped', paymentMethod: 'Mixed' },
      // Additional transactions to reach 75%+ employee voucher usage for some partners
      // Boeing - adding 32 more employees (34 total = 75.6% of 45)
      { id: 't37', orderId: 'ORD-2024-026', employeeName: 'Michael Brown', employeeEmail: 'michael.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-10-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't38', orderId: 'ORD-2024-027', employeeName: 'Emily Davis', employeeEmail: 'emily.davis@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-10-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't39', orderId: 'ORD-2024-028', employeeName: 'David Wilson', employeeEmail: 'david.wilson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-10-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't40', orderId: 'ORD-2024-029', employeeName: 'Jennifer Martinez', employeeEmail: 'jennifer.martinez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-10-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't41', orderId: 'ORD-2024-030', employeeName: 'Robert Taylor', employeeEmail: 'robert.taylor@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-10-12', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't42', orderId: 'ORD-2024-031', employeeName: 'Lisa Anderson', employeeEmail: 'lisa.anderson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-10-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't43', orderId: 'ORD-2024-032', employeeName: 'James White', employeeEmail: 'james.white@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-10-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't44', orderId: 'ORD-2024-033', employeeName: 'Patricia Garcia', employeeEmail: 'patricia.garcia@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-10-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't45', orderId: 'ORD-2024-034', employeeName: 'Christopher Lee', employeeEmail: 'christopher.lee@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-10-03', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't46', orderId: 'ORD-2024-035', employeeName: 'Amanda Rodriguez', employeeEmail: 'amanda.rodriguez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-10-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't47', orderId: 'ORD-2024-036', employeeName: 'Daniel Kim', employeeEmail: 'daniel.kim@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-09-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't48', orderId: 'ORD-2024-037', employeeName: 'Rachel Moore', employeeEmail: 'rachel.moore@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-09-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't49', orderId: 'ORD-2024-038', employeeName: 'Thomas Chen', employeeEmail: 'thomas.chen@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-09-22', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't50', orderId: 'ORD-2024-039', employeeName: 'Maria Johnson', employeeEmail: 'maria.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-09-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't51', orderId: 'ORD-2024-040', employeeName: 'Kevin Brown', employeeEmail: 'kevin.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-09-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't52', orderId: 'ORD-2024-041', employeeName: 'Susan Williams', employeeEmail: 'susan.williams@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-09-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't53', orderId: 'ORD-2024-042', employeeName: 'Mark Thompson', employeeEmail: 'mark.thompson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-09-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't54', orderId: 'ORD-2024-043', employeeName: 'Nancy Davis', employeeEmail: 'nancy.davis@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-09-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't55', orderId: 'ORD-2024-044', employeeName: 'Brian Miller', employeeEmail: 'brian.miller@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-09-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't56', orderId: 'ORD-2024-045', employeeName: 'Karen Wilson', employeeEmail: 'karen.wilson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-09-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't57', orderId: 'ORD-2024-046', employeeName: 'Steven Martinez', employeeEmail: 'steven.martinez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-09-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't58', orderId: 'ORD-2024-047', employeeName: 'Michelle Taylor', employeeEmail: 'michelle.taylor@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-09-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't59', orderId: 'ORD-2024-048', employeeName: 'Ryan Anderson', employeeEmail: 'ryan.anderson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-08-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't60', orderId: 'ORD-2024-049', employeeName: 'Laura White', employeeEmail: 'laura.white@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-08-25', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't61', orderId: 'ORD-2024-050', employeeName: 'Jason Garcia', employeeEmail: 'jason.garcia@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-08-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't62', orderId: 'ORD-2024-051', employeeName: 'Stephanie Lee', employeeEmail: 'stephanie.lee@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-08-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't63', orderId: 'ORD-2024-052', employeeName: 'Eric Rodriguez', employeeEmail: 'eric.rodriguez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-08-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't64', orderId: 'ORD-2024-053', employeeName: 'Nicole Kim', employeeEmail: 'nicole.kim@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-08-15', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't65', orderId: 'ORD-2024-054', employeeName: 'Andrew Moore', employeeEmail: 'andrew.moore@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-08-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't66', orderId: 'ORD-2024-055', employeeName: 'Melissa Chen', employeeEmail: 'melissa.chen@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-08-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't67', orderId: 'ORD-2024-056', employeeName: 'Justin Johnson', employeeEmail: 'justin.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-08-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't68', orderId: 'ORD-2024-057', employeeName: 'Angela Brown', employeeEmail: 'angela.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-08-05', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't69', orderId: 'ORD-2024-058', employeeName: 'Brandon Williams', employeeEmail: 'brandon.williams@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-08-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't70', orderId: 'ORD-2024-059', employeeName: 'Christina Thompson', employeeEmail: 'christina.thompson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-08-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't71', orderId: 'ORD-2024-060', employeeName: 'Tyler Miller', employeeEmail: 'tyler.miller@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-07-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't72', orderId: 'ORD-2024-061', employeeName: 'Samantha Davis', employeeEmail: 'samantha.davis@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-07-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't73', orderId: 'ORD-2024-062', employeeName: 'Jonathan Wilson', employeeEmail: 'jonathan.wilson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-07-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't74', orderId: 'ORD-2024-063', employeeName: 'Rebecca Martinez', employeeEmail: 'rebecca.martinez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-07-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't75', orderId: 'ORD-2024-064', employeeName: 'Matthew Taylor', employeeEmail: 'matthew.taylor@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-07-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't76', orderId: 'ORD-2024-065', employeeName: 'Ashley Anderson', employeeEmail: 'ashley.anderson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-07-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't77', orderId: 'ORD-2024-066', employeeName: 'Joshua White', employeeEmail: 'joshua.white@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-07-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't78', orderId: 'ORD-2024-067', employeeName: 'Megan Garcia', employeeEmail: 'megan.garcia@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-07-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't79', orderId: 'ORD-2024-068', employeeName: 'Nicholas Lee', employeeEmail: 'nicholas.lee@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-07-08', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't80', orderId: 'ORD-2024-069', employeeName: 'Jessica Rodriguez', employeeEmail: 'jessica.rodriguez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-07-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't81', orderId: 'ORD-2024-070', employeeName: 'Benjamin Kim', employeeEmail: 'benjamin.kim@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-07-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't82', orderId: 'ORD-2024-071', employeeName: 'Lauren Moore', employeeEmail: 'lauren.moore@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-07-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't83', orderId: 'ORD-2024-072', employeeName: 'Alexander Chen', employeeEmail: 'alexander.chen@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-06-28', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't84', orderId: 'ORD-2024-073', employeeName: 'Hannah Johnson', employeeEmail: 'hannah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-06-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't85', orderId: 'ORD-2024-074', employeeName: 'Zachary Brown', employeeEmail: 'zachary.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-06-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't86', orderId: 'ORD-2024-075', employeeName: 'Olivia Williams', employeeEmail: 'olivia.williams@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-06-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't87', orderId: 'ORD-2024-076', employeeName: 'Nathan Thompson', employeeEmail: 'nathan.thompson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-06-18', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't88', orderId: 'ORD-2024-077', employeeName: 'Emma Miller', employeeEmail: 'emma.miller@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-06-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't89', orderId: 'ORD-2024-078', employeeName: 'Jacob Davis', employeeEmail: 'jacob.davis@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-06-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't90', orderId: 'ORD-2024-079', employeeName: 'Grace Wilson', employeeEmail: 'grace.wilson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-06-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't91', orderId: 'ORD-2024-080', employeeName: 'Logan Martinez', employeeEmail: 'logan.martinez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-06-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't92', orderId: 'ORD-2024-081', employeeName: 'Victoria Taylor', employeeEmail: 'victoria.taylor@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-06-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't93', orderId: 'ORD-2024-082', employeeName: 'Cameron Anderson', employeeEmail: 'cameron.anderson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-06-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't94', orderId: 'ORD-2024-083', employeeName: 'Sophia White', employeeEmail: 'sophia.white@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-06-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't95', orderId: 'ORD-2024-084', employeeName: 'Aiden Garcia', employeeEmail: 'aiden.garcia@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-05-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't96', orderId: 'ORD-2024-085', employeeName: 'Isabella Lee', employeeEmail: 'isabella.lee@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-05-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't97', orderId: 'ORD-2024-086', employeeName: 'Ethan Rodriguez', employeeEmail: 'ethan.rodriguez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-05-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't98', orderId: 'ORD-2024-087', employeeName: 'Madison Kim', employeeEmail: 'madison.kim@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-05-20', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't99', orderId: 'ORD-2024-088', employeeName: 'Noah Moore', employeeEmail: 'noah.moore@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-05-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't100', orderId: 'ORD-2024-089', employeeName: 'Chloe Chen', employeeEmail: 'chloe.chen@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-05-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't101', orderId: 'ORD-2024-090', employeeName: 'Lucas Johnson', employeeEmail: 'lucas.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-05-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't102', orderId: 'ORD-2024-091', employeeName: 'Ava Brown', employeeEmail: 'ava.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-05-10', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't103', orderId: 'ORD-2024-092', employeeName: 'Mason Williams', employeeEmail: 'mason.williams@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-05-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't104', orderId: 'ORD-2024-093', employeeName: 'Harper Thompson', employeeEmail: 'harper.thompson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-05-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't105', orderId: 'ORD-2024-094', employeeName: 'Liam Miller', employeeEmail: 'liam.miller@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-05-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't106', orderId: 'ORD-2024-095', employeeName: 'Evelyn Davis', employeeEmail: 'evelyn.davis@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-05-01', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't107', orderId: 'ORD-2024-096', employeeName: 'Henry Wilson', employeeEmail: 'henry.wilson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-04-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't108', orderId: 'ORD-2024-097', employeeName: 'Abigail Martinez', employeeEmail: 'abigail.martinez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-04-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't109', orderId: 'ORD-2024-098', employeeName: 'Sebastian Taylor', employeeEmail: 'sebastian.taylor@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-04-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't110', orderId: 'ORD-2024-099', employeeName: 'Emily Anderson', employeeEmail: 'emily.anderson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-04-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't111', orderId: 'ORD-2024-100', employeeName: 'Jackson White', employeeEmail: 'jackson.white@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-04-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't112', orderId: 'ORD-2024-101', employeeName: 'Scarlett Garcia', employeeEmail: 'scarlett.garcia@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-04-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't113', orderId: 'ORD-2024-102', employeeName: 'Aria Lee', employeeEmail: 'aria.lee@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-04-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't114', orderId: 'ORD-2024-103', employeeName: 'Wyatt Rodriguez', employeeEmail: 'wyatt.rodriguez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-04-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't115', orderId: 'ORD-2024-104', employeeName: 'Layla Kim', employeeEmail: 'layla.kim@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-04-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't116', orderId: 'ORD-2024-105', employeeName: 'Carter Moore', employeeEmail: 'carter.moore@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-04-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't117', orderId: 'ORD-2024-106', employeeName: 'Zoey Chen', employeeEmail: 'zoey.chen@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-04-03', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't118', orderId: 'ORD-2024-107', employeeName: 'Owen Johnson', employeeEmail: 'owen.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-04-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't119', orderId: 'ORD-2024-108', employeeName: 'Penelope Brown', employeeEmail: 'penelope.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-03-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't120', orderId: 'ORD-2024-109', employeeName: 'Luke Williams', employeeEmail: 'luke.williams@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-03-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't121', orderId: 'ORD-2024-110', employeeName: 'Nora Thompson', employeeEmail: 'nora.thompson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-03-22', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't122', orderId: 'ORD-2024-111', employeeName: 'Jack Miller', employeeEmail: 'jack.miller@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-03-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't123', orderId: 'ORD-2024-112', employeeName: 'Lillian Davis', employeeEmail: 'lillian.davis@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-03-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't124', orderId: 'ORD-2024-113', employeeName: 'Levi Wilson', employeeEmail: 'levi.wilson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-03-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't125', orderId: 'ORD-2024-114', employeeName: 'Addison Martinez', employeeEmail: 'addison.martinez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-03-12', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't126', orderId: 'ORD-2024-115', employeeName: 'Stella Taylor', employeeEmail: 'stella.taylor@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-03-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't127', orderId: 'ORD-2024-116', employeeName: 'Hazel Anderson', employeeEmail: 'hazel.anderson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-03-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't128', orderId: 'ORD-2024-117', employeeName: 'Violet White', employeeEmail: 'violet.white@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-03-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't129', orderId: 'ORD-2024-118', employeeName: 'Aurora Garcia', employeeEmail: 'aurora.garcia@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-03-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't130', orderId: 'ORD-2024-119', employeeName: 'Savannah Lee', employeeEmail: 'savannah.lee@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-03-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't131', orderId: 'ORD-2024-120', employeeName: 'Audrey Rodriguez', employeeEmail: 'audrey.rodriguez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-02-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't132', orderId: 'ORD-2024-121', employeeName: 'Brooklyn Kim', employeeEmail: 'brooklyn.kim@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-02-25', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't133', orderId: 'ORD-2024-122', employeeName: 'Bella Moore', employeeEmail: 'bella.moore@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-02-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't134', orderId: 'ORD-2024-123', employeeName: 'Claire Chen', employeeEmail: 'claire.chen@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-02-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't135', orderId: 'ORD-2024-124', employeeName: 'Skylar Johnson', employeeEmail: 'skylar.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-02-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't136', orderId: 'ORD-2024-125', employeeName: 'Lucy Brown', employeeEmail: 'lucy.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-02-15', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't137', orderId: 'ORD-2024-126', employeeName: 'Paisley Williams', employeeEmail: 'paisley.williams@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-02-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't138', orderId: 'ORD-2024-127', employeeName: 'Everly Thompson', employeeEmail: 'everly.thompson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-02-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't139', orderId: 'ORD-2024-128', employeeName: 'Anna Miller', employeeEmail: 'anna.miller@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Yellow', surewerxPartNumber: 'SWX-SV-005', distributorPartNumber: '', quantity: 4, unitPrice: 19.99, totalPrice: 79.96, distributorCost: 14.00, dateOrdered: '2024-02-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't140', orderId: 'ORD-2024-129', employeeName: 'Caroline Davis', employeeEmail: 'caroline.davis@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Composite Toe Boots - 8 inch', surewerxPartNumber: 'SWX-CT-001', distributorPartNumber: '', quantity: 1, unitPrice: 99.99, totalPrice: 99.99, distributorCost: 76.00, dateOrdered: '2024-02-05', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't141', orderId: 'ORD-2024-130', employeeName: 'Nova Wilson', employeeEmail: 'nova.wilson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-02-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't142', orderId: 'ORD-2024-131', employeeName: 'Genesis Martinez', employeeEmail: 'genesis.martinez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-02-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't143', orderId: 'ORD-2024-132', employeeName: 'Aaliyah Taylor', employeeEmail: 'aaliyah.taylor@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Ear Muffs - Standard', surewerxPartNumber: 'SWX-EM-001', distributorPartNumber: '', quantity: 2, unitPrice: 22.99, totalPrice: 45.98, distributorCost: 17.00, dateOrdered: '2024-01-28', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't144', orderId: 'ORD-2024-133', employeeName: 'Kennedy Anderson', employeeEmail: 'kennedy.anderson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-01-25', voucherUsed: 'Quarterly PPE Budget', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't145', orderId: 'ORD-2024-134', employeeName: 'Kinsley White', employeeEmail: 'kinsley.white@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Rain Suit - 2 Piece', surewerxPartNumber: 'SWX-RS-001', distributorPartNumber: '', quantity: 2, unitPrice: 38.99, totalPrice: 77.98, distributorCost: 29.50, dateOrdered: '2024-01-22', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't146', orderId: 'ORD-2024-135', employeeName: 'Allison Garcia', employeeEmail: 'allison.garcia@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-01-20', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't147', orderId: 'ORD-2024-136', employeeName: 'Maya Lee', employeeEmail: 'maya.lee@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-01-18', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't148', orderId: 'ORD-2024-137', employeeName: 'Willow Rodriguez', employeeEmail: 'willow.rodriguez@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-01-15', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't149', orderId: 'ORD-2024-138', employeeName: 'Naomi Kim', employeeEmail: 'naomi.kim@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Cut Resistant Gloves - Level 5', surewerxPartNumber: 'SWX-CR-001', distributorPartNumber: '', quantity: 4, unitPrice: 24.99, totalPrice: 99.96, distributorCost: 18.50, dateOrdered: '2024-01-12', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't150', orderId: 'ORD-2024-139', employeeName: 'Aria Moore', employeeEmail: 'aria.moore@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Chemical Resistant Gloves', surewerxPartNumber: 'SWX-CG-001', distributorPartNumber: '', quantity: 3, unitPrice: 21.99, totalPrice: 65.97, distributorCost: 16.50, dateOrdered: '2024-01-10', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't151', orderId: 'ORD-2024-140', employeeName: 'Elena Chen', employeeEmail: 'elena.chen@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-01-08', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't152', orderId: 'ORD-2024-141', employeeName: 'Sarah Johnson', employeeEmail: 'sarah.johnson@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-01-05', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't153', orderId: 'ORD-2024-142', employeeName: 'John Smith', employeeEmail: 'john.smith@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-01-03', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't154', orderId: 'ORD-2024-143', employeeName: 'Michael Brown', employeeEmail: 'michael.brown@boeing.com', employeeGroup: 'Safety Team', partnerName: 'Boeing', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-01-01', voucherUsed: 'Monthly Safety Allowance', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Additional transactions for other partners
      // Manufacturing Corp - adding 5 more employees
      { id: 't155', orderId: 'ORD-2024-200', employeeName: 'Jennifer Adams', employeeEmail: 'jennifer.adams@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-10', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't156', orderId: 'ORD-2024-201', employeeName: 'Robert Johnson', employeeEmail: 'robert.johnson@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-11-08', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't157', orderId: 'ORD-2024-202', employeeName: 'Patricia Williams', employeeEmail: 'patricia.williams@manufacturing.com', employeeGroup: 'Maintenance', partnerName: 'Manufacturing Corp', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-11-05', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't158', orderId: 'ORD-2024-203', employeeName: 'William Brown', employeeEmail: 'william.brown@manufacturing.com', employeeGroup: 'Quality Control', partnerName: 'Manufacturing Corp', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-11-03', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't159', orderId: 'ORD-2024-204', employeeName: 'Linda Martinez', employeeEmail: 'linda.martinez@manufacturing.com', employeeGroup: 'Production Floor', partnerName: 'Manufacturing Corp', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-11-01', voucherUsed: 'Safety Equipment Fund', voucherAmount: 100.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Construction Services - adding 5 more employees
      { id: 't160', orderId: 'ORD-2024-300', employeeName: 'Christopher Anderson', employeeEmail: 'christopher.anderson@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Hard Hat - Full Brim', surewerxPartNumber: 'SWX-HH-006', distributorPartNumber: '', quantity: 1, unitPrice: 32.99, totalPrice: 32.99, distributorCost: 25.00, dateOrdered: '2024-11-12', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't161', orderId: 'ORD-2024-301', employeeName: 'Amanda Taylor', employeeEmail: 'amanda.taylor@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Work Gloves - Cowhide', surewerxPartNumber: 'SWX-GL-004', distributorPartNumber: '', quantity: 5, unitPrice: 14.99, totalPrice: 74.95, distributorCost: 11.00, dateOrdered: '2024-11-10', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't162', orderId: 'ORD-2024-302', employeeName: 'Daniel White', employeeEmail: 'daniel.white@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Reflective Vest - Class 3', surewerxPartNumber: 'SWX-RV-001', distributorPartNumber: '', quantity: 2, unitPrice: 29.99, totalPrice: 59.98, distributorCost: 22.50, dateOrdered: '2024-11-08', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't163', orderId: 'ORD-2024-303', employeeName: 'Michelle Garcia', employeeEmail: 'michelle.garcia@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Safety Glasses - Tinted', surewerxPartNumber: 'SWX-SG-002', distributorPartNumber: '', quantity: 3, unitPrice: 17.99, totalPrice: 53.97, distributorCost: 13.50, dateOrdered: '2024-11-05', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't164', orderId: 'ORD-2024-304', employeeName: 'Kevin Rodriguez', employeeEmail: 'kevin.rodriguez@construction.com', employeeGroup: 'Site Workers', partnerName: 'Construction Services', productName: 'Winter Work Boots - Insulated', surewerxPartNumber: 'SWX-WB-001', distributorPartNumber: '', quantity: 1, unitPrice: 119.99, totalPrice: 119.99, distributorCost: 91.00, dateOrdered: '2024-11-03', voucherUsed: 'PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Healthcare Systems Ltd - adding 5 employees
      { id: 't165', orderId: 'ORD-2024-400', employeeName: 'Dr. Sarah Thompson', employeeEmail: 'sarah.thompson@healthcare.com', employeeGroup: 'Clinical Staff', partnerName: 'Healthcare Systems Ltd', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-11-15', voucherUsed: 'Healthcare PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't166', orderId: 'ORD-2024-401', employeeName: 'Dr. James Wilson', employeeEmail: 'james.wilson@healthcare.com', employeeGroup: 'Clinical Staff', partnerName: 'Healthcare Systems Ltd', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-11-12', voucherUsed: 'Healthcare PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't167', orderId: 'ORD-2024-402', employeeName: 'Nurse Maria Lopez', employeeEmail: 'maria.lopez@healthcare.com', employeeGroup: 'Clinical Staff', partnerName: 'Healthcare Systems Ltd', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-11-10', voucherUsed: 'Healthcare PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't168', orderId: 'ORD-2024-403', employeeName: 'Dr. Robert Kim', employeeEmail: 'robert.kim@healthcare.com', employeeGroup: 'Clinical Staff', partnerName: 'Healthcare Systems Ltd', productName: 'Half Mask Respirator - Reusable', surewerxPartNumber: 'SWX-HM-001', distributorPartNumber: '', quantity: 2, unitPrice: 34.99, totalPrice: 69.98, distributorCost: 26.50, dateOrdered: '2024-11-08', voucherUsed: 'Healthcare PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't169', orderId: 'ORD-2024-404', employeeName: 'Nurse Jennifer Park', employeeEmail: 'jennifer.park@healthcare.com', employeeGroup: 'Clinical Staff', partnerName: 'Healthcare Systems Ltd', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-05', voucherUsed: 'Healthcare PPE Allowance', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Energy Solutions Group - adding 5 employees
      { id: 't170', orderId: 'ORD-2024-500', employeeName: 'Mark Thompson', employeeEmail: 'mark.thompson@energy.com', employeeGroup: 'Field Operations', partnerName: 'Energy Solutions Group', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-11-14', voucherUsed: 'Field Safety Equipment', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't171', orderId: 'ORD-2024-501', employeeName: 'Susan Davis', employeeEmail: 'susan.davis@energy.com', employeeGroup: 'Field Operations', partnerName: 'Energy Solutions Group', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-11-12', voucherUsed: 'Field Safety Equipment', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't172', orderId: 'ORD-2024-502', employeeName: 'Thomas Miller', employeeEmail: 'thomas.miller@energy.com', employeeGroup: 'Maintenance Team', partnerName: 'Energy Solutions Group', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-11-10', voucherUsed: 'Maintenance PPE Budget', voucherAmount: 250.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't173', orderId: 'ORD-2024-503', employeeName: 'Nancy Anderson', employeeEmail: 'nancy.anderson@energy.com', employeeGroup: 'Field Operations', partnerName: 'Energy Solutions Group', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-11-08', voucherUsed: 'Field Safety Equipment', voucherAmount: 300.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't174', orderId: 'ORD-2024-504', employeeName: 'Charles Lee', employeeEmail: 'charles.lee@energy.com', employeeGroup: 'Maintenance Team', partnerName: 'Energy Solutions Group', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-05', voucherUsed: 'Maintenance PPE Budget', voucherAmount: 250.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Logistics & Transport Co - adding 5 employees
      { id: 't175', orderId: 'ORD-2024-600', employeeName: 'Steven Brown', employeeEmail: 'steven.brown@logistics.com', employeeGroup: 'Drivers', partnerName: 'Logistics & Transport Co', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-11-13', voucherUsed: 'Driver Safety Allowance', voucherAmount: 180.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't176', orderId: 'ORD-2024-601', employeeName: 'Karen Martinez', employeeEmail: 'karen.martinez@logistics.com', employeeGroup: 'Drivers', partnerName: 'Logistics & Transport Co', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-11-11', voucherUsed: 'Driver Safety Allowance', voucherAmount: 180.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't177', orderId: 'ORD-2024-602', employeeName: 'Paul Johnson', employeeEmail: 'paul.johnson@logistics.com', employeeGroup: 'Warehouse Staff', partnerName: 'Logistics & Transport Co', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-11-09', voucherUsed: 'Warehouse PPE Fund', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't178', orderId: 'ORD-2024-603', employeeName: 'Betty White', employeeEmail: 'betty.white@logistics.com', employeeGroup: 'Drivers', partnerName: 'Logistics & Transport Co', productName: 'Steel Toe Boots - 6 inch', surewerxPartNumber: 'SWX-ST-001', distributorPartNumber: '', quantity: 1, unitPrice: 89.99, totalPrice: 89.99, distributorCost: 68.00, dateOrdered: '2024-11-07', voucherUsed: 'Driver Safety Allowance', voucherAmount: 180.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't179', orderId: 'ORD-2024-604', employeeName: 'Frank Garcia', employeeEmail: 'frank.garcia@logistics.com', employeeGroup: 'Warehouse Staff', partnerName: 'Logistics & Transport Co', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-05', voucherUsed: 'Warehouse PPE Fund', voucherAmount: 200.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Food Processing Industries - adding 5 employees
      { id: 't180', orderId: 'ORD-2024-700', employeeName: 'Joseph Smith', employeeEmail: 'joseph.smith@foodprocessing.com', employeeGroup: 'Production Line', partnerName: 'Food Processing Industries', productName: 'Latex Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-LG-001', distributorPartNumber: '', quantity: 4, unitPrice: 15.99, totalPrice: 63.96, distributorCost: 11.50, dateOrdered: '2024-11-16', voucherUsed: 'Production Safety Equipment', voucherAmount: 175.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't181', orderId: 'ORD-2024-701', employeeName: 'Carol Johnson', employeeEmail: 'carol.johnson@foodprocessing.com', employeeGroup: 'Production Line', partnerName: 'Food Processing Industries', productName: 'Nitrile Gloves - Disposable (100pk)', surewerxPartNumber: 'SWX-NG-001', distributorPartNumber: '', quantity: 3, unitPrice: 19.99, totalPrice: 59.97, distributorCost: 14.50, dateOrdered: '2024-11-14', voucherUsed: 'Production Safety Equipment', voucherAmount: 175.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't182', orderId: 'ORD-2024-702', employeeName: 'Gary Williams', employeeEmail: 'gary.williams@foodprocessing.com', employeeGroup: 'Quality Control', partnerName: 'Food Processing Industries', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-12', voucherUsed: 'QC Lab Equipment', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't183', orderId: 'ORD-2024-703', employeeName: 'Donna Brown', employeeEmail: 'donna.brown@foodprocessing.com', employeeGroup: 'Production Line', partnerName: 'Food Processing Industries', productName: 'Safety Vest - Hi-Vis Orange', surewerxPartNumber: 'SWX-SV-004', distributorPartNumber: '', quantity: 2, unitPrice: 19.99, totalPrice: 39.98, distributorCost: 14.00, dateOrdered: '2024-11-10', voucherUsed: 'Production Safety Equipment', voucherAmount: 175.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't184', orderId: 'ORD-2024-704', employeeName: 'Ronald Davis', employeeEmail: 'ronald.davis@foodprocessing.com', employeeGroup: 'Quality Control', partnerName: 'Food Processing Industries', productName: 'Dust Mask - N95 (20pk)', surewerxPartNumber: 'SWX-DM-001', distributorPartNumber: '', quantity: 2, unitPrice: 24.99, totalPrice: 49.98, distributorCost: 18.50, dateOrdered: '2024-11-08', voucherUsed: 'QC Lab Equipment', voucherAmount: 150.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      // Automotive Parts Manufacturing - adding 5 employees
      { id: 't185', orderId: 'ORD-2024-800', employeeName: 'Brian Wilson', employeeEmail: 'brian.wilson@autoparts.com', employeeGroup: 'Assembly Line', partnerName: 'Automotive Parts Manufacturing', productName: 'Safety Glasses - Clear Lens', surewerxPartNumber: 'SWX-SG-001', distributorPartNumber: '', quantity: 2, unitPrice: 15.99, totalPrice: 31.98, distributorCost: 12.00, dateOrdered: '2024-11-15', voucherUsed: 'Assembly Line Safety', voucherAmount: 220.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't186', orderId: 'ORD-2024-801', employeeName: 'Sharon Martinez', employeeEmail: 'sharon.martinez@autoparts.com', employeeGroup: 'Assembly Line', partnerName: 'Automotive Parts Manufacturing', productName: 'Hard Hat - Yellow', surewerxPartNumber: 'SWX-HH-002', distributorPartNumber: '', quantity: 1, unitPrice: 24.99, totalPrice: 24.99, distributorCost: 18.50, dateOrdered: '2024-11-13', voucherUsed: 'Assembly Line Safety', voucherAmount: 220.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't187', orderId: 'ORD-2024-802', employeeName: 'Kenneth Taylor', employeeEmail: 'kenneth.taylor@autoparts.com', employeeGroup: 'Welding Department', partnerName: 'Automotive Parts Manufacturing', productName: 'Welding Gloves - Heavy Duty', surewerxPartNumber: 'SWX-WG-002', distributorPartNumber: '', quantity: 2, unitPrice: 28.99, totalPrice: 57.98, distributorCost: 22.00, dateOrdered: '2024-11-11', voucherUsed: 'Welding PPE Budget', voucherAmount: 250.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't188', orderId: 'ORD-2024-803', employeeName: 'Deborah Anderson', employeeEmail: 'deborah.anderson@autoparts.com', employeeGroup: 'Welding Department', partnerName: 'Automotive Parts Manufacturing', productName: 'Face Shield - Full Coverage', surewerxPartNumber: 'SWX-FS-001', distributorPartNumber: '', quantity: 3, unitPrice: 28.99, totalPrice: 86.97, distributorCost: 21.00, dateOrdered: '2024-11-09', voucherUsed: 'Welding PPE Budget', voucherAmount: 250.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' },
      { id: 't189', orderId: 'ORD-2024-804', employeeName: 'George Thomas', employeeEmail: 'george.thomas@autoparts.com', employeeGroup: 'Assembly Line', partnerName: 'Automotive Parts Manufacturing', productName: 'Work Gloves - Leather', surewerxPartNumber: 'SWX-GL-003', distributorPartNumber: '', quantity: 3, unitPrice: 12.99, totalPrice: 38.97, distributorCost: 9.00, dateOrdered: '2024-11-07', voucherUsed: 'Assembly Line Safety', voucherAmount: 220.00, lineStatus: 'Shipped', paymentMethod: 'Voucher' }
    ];
  },
  
  // Populate employees from transactions
  populateEmployeesFromTransactions: function() {
    var self = this;
    
    this.partners.forEach(function(partner) {
      // First, ensure all existing employees have at least one identifier and one date
      if (partner.employees && partner.employees.length > 0) {
        partner.employees.forEach(function(emp) {
          // Ensure at least one identifier (Employee ID or Username)
          if (!emp.employeeId && !emp.username) {
            // Prefer username (from email) if available, otherwise generate employee ID
            if (emp.email) {
              emp.username = emp.email.split('@')[0];
            } else {
              var prefix = partner.id === 'p1' ? 'EMP' : 
                          partner.id === 'p2' ? 'MFG' :
                          partner.id === 'p3' ? 'CON' :
                          partner.id === 'p4' ? 'HC' :
                          partner.id === 'p5' ? 'EN' :
                          partner.id === 'p6' ? 'LT' :
                          partner.id === 'p7' ? 'FP' :
                          partner.id === 'p8' ? 'AP' : 'EMP';
              var num = partner.employees.indexOf(emp) + 1;
              emp.employeeId = prefix + '-' + String(num).padStart(3, '0');
            }
          }
          
          // Ensure at least one date (Birth Date or Start Date)
          if (!emp.dateOfBirth && !emp.startDate) {
            // Prefer start date (more common), otherwise use birth date
            var yearsAgo = Math.floor(Math.random() * 5);
            var startYear = new Date().getFullYear() - yearsAgo;
            var startMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var startDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            emp.startDate = startYear + '-' + startMonth + '-' + startDay;
          }
          
          // Also ensure required fields are present if partner config requires them
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireDateOfBirth && !emp.dateOfBirth) {
            var age = 25 + Math.floor(Math.random() * 40);
            var birthYear = new Date().getFullYear() - age;
            var birthMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var birthDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            emp.dateOfBirth = birthYear + '-' + birthMonth + '-' + birthDay;
          }
          
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireStartDate && !emp.startDate) {
            var yearsAgo = Math.floor(Math.random() * 5);
            var startYear = new Date().getFullYear() - yearsAgo;
            var startMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var startDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            emp.startDate = startYear + '-' + startMonth + '-' + startDay;
          }
        });
      }
      
      // Get unique employees from transactions for this partner
      var partnerTransactions = self.transactions.filter(function(t) {
        return t.partnerName === partner.name;
      });
      
      // If no transactions, skip
      if (partnerTransactions.length === 0) {
        return;
      }
      
      // Create a map of unique employees by email
      var employeeMap = new Map();
      partnerTransactions.forEach(function(t) {
        var email = t.employeeEmail;
        var name = t.employeeName;
        var groupName = t.employeeGroup;
        
        if (email && !employeeMap.has(email.toLowerCase())) {
          // Find or create a group for this employee
          var group = partner.groups.find(function(g) { return g.name === groupName; });
          var groupId = group ? group.id : (partner.groups.length > 0 ? partner.groups[0].id : null);
          
          // Parse name
          var nameParts = name.split(' ');
          var firstName = nameParts[0] || '';
          var lastName = nameParts.slice(1).join(' ') || '';
          
          employeeMap.set(email.toLowerCase(), {
            email: email,
            name: name,
            firstName: firstName,
            lastName: lastName,
            groupId: groupId,
            employeeGroup: groupName
          });
        }
      });
      
      // Get existing employee emails
      var existingEmails = new Set();
      if (partner.employees && partner.employees.length > 0) {
        partner.employees.forEach(function(emp) {
          if (emp.email) {
            existingEmails.add(emp.email.toLowerCase());
          }
        });
      }
      
      // Add employees from transactions that don't already exist
      var newEmployees = [];
      employeeMap.forEach(function(empData, email) {
        if (!existingEmails.has(email)) {
          // Generate employee ID if required
          var employeeId = null;
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireEmployeeId) {
            var prefix = partner.id === 'p1' ? 'EMP' : 
                        partner.id === 'p2' ? 'MFG' :
                        partner.id === 'p3' ? 'CON' :
                        partner.id === 'p4' ? 'HC' :
                        partner.id === 'p5' ? 'EN' :
                        partner.id === 'p6' ? 'LT' :
                        partner.id === 'p7' ? 'FP' :
                        partner.id === 'p8' ? 'AP' : 'EMP';
            var num = (partner.employees ? partner.employees.length : 0) + newEmployees.length + 1;
            employeeId = prefix + '-' + String(num).padStart(3, '0');
          }
          
          // Get first available group if no groupId specified (for mock data generation)
          var groupId = empData.groupId;
          if (!groupId && partner.groups && partner.groups.length > 0) {
            groupId = partner.groups[0].id;
          }
          
          // Get voucher balances if vouchers exist
          var voucherBalances = [];
          var remainingBalance = 0;
          if (partner.vouchers && partner.vouchers.length > 0) {
            var activeVouchers = partner.vouchers.filter(function(v) { return v.isActive; });
            activeVouchers.forEach(function(v) {
              if (v.userGroupIds && v.userGroupIds.indexOf(groupId) > -1) {
                voucherBalances.push({
                  voucherId: v.id,
                  remainingAmount: v.defaultAmount || 0
                });
                remainingBalance += (v.defaultAmount || 0);
              }
            });
          }
          
          var newEmployee = {
            id: 'emp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
            name: empData.name,
            firstName: empData.firstName,
            lastName: empData.lastName,
            email: empData.email,
            groupId: groupId,
            voucherExpiry: partner.vouchers && partner.vouchers.length > 0 ? partner.vouchers[0].endDate : '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: remainingBalance,
            voucherBalances: voucherBalances,
            status: 'active'
          };
          
          // Ensure at least one identifier (Employee ID or Username)
          if (employeeId) {
            newEmployee.employeeId = employeeId;
          }
          
          // Add username if required OR if no employee ID (to ensure at least one identifier)
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireUsername) {
            var username = empData.email.split('@')[0];
            newEmployee.username = username;
          } else if (!employeeId) {
            // If no employee ID and username not required, add username anyway to ensure at least one identifier
            var username = empData.email.split('@')[0];
            newEmployee.username = username;
          }
          
          // Ensure at least one date (Birth Date or Start Date)
          var hasDate = false;
          
          // Add date of birth if required
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireDateOfBirth) {
            // Generate a random date of birth (age between 25-65)
            var age = 25 + Math.floor(Math.random() * 40);
            var birthYear = new Date().getFullYear() - age;
            var birthMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var birthDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            newEmployee.dateOfBirth = birthYear + '-' + birthMonth + '-' + birthDay;
            hasDate = true;
          }
          
          // Add start date if required
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireStartDate) {
            // Generate a random start date (within last 5 years)
            var yearsAgo = Math.floor(Math.random() * 5);
            var startYear = new Date().getFullYear() - yearsAgo;
            var startMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var startDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            newEmployee.startDate = startYear + '-' + startMonth + '-' + startDay;
            hasDate = true;
          }
          
          // If no date was added yet, add a start date to ensure at least one date
          if (!hasDate) {
            var yearsAgo = Math.floor(Math.random() * 5);
            var startYear = new Date().getFullYear() - yearsAgo;
            var startMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var startDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            newEmployee.startDate = startYear + '-' + startMonth + '-' + startDay;
          }
          
          newEmployees.push(newEmployee);
        }
      });
      
      // Add new employees to partner
      if (newEmployees.length > 0) {
        if (!partner.employees) {
          partner.employees = [];
        }
        partner.employees = partner.employees.concat(newEmployees);
      }
      
      // Update employeeCount to match the actual number of employees from transactions
      // This ensures the count reflects all employees that have made transactions
      if (partner.employees && partner.employees.length > 0) {
        partner.employeeCount = partner.employees.length;
      }
      
      // Note: We no longer generate additional employees to fill up to a target count
      // The employeeCount should reflect the actual employees from transactions
      
      // Legacy code removed - we used to generate employees to match employeeCount,
      // but now we populate from transactions and update employeeCount accordingly
      /*
      var currentCount = partner.employees ? partner.employees.length : 0;
      var targetCount = partner.employeeCount || 0;
      
      if (currentCount < targetCount) {
        var needed = targetCount - currentCount;
        // Get first available group if groups exist (for mock data generation)
        var groupId = null;
        if (partner.groups && partner.groups.length > 0) {
          groupId = partner.groups[0].id;
        }
        
        // Get domain from partner email or generate one
        var domain = partner.contactEmail ? partner.contactEmail.split('@')[1] : 
                    partner.id === 'p1' ? 'techsolutions.com' :
                    partner.id === 'p2' ? 'manufacturing.com' :
                    partner.id === 'p3' ? 'construction.com' :
                    partner.id === 'p4' ? 'healthcare.com' :
                    partner.id === 'p5' ? 'energy.com' :
                    partner.id === 'p6' ? 'logistics.com' :
                    partner.id === 'p7' ? 'foodprocessing.com' :
                    partner.id === 'p8' ? 'autoparts.com' : 'company.com';
        
        var firstNames = ['Alex', 'Jordan', 'Taylor', 'Morgan', 'Casey', 'Riley', 'Avery', 'Quinn', 'Cameron', 'Dakota', 'Blake', 'Sage', 'River', 'Phoenix', 'Skylar'];
        var lastNames = ['Johnson', 'Williams', 'Brown', 'Jones', 'Garcia', 'Miller', 'Davis', 'Rodriguez', 'Martinez', 'Hernandez', 'Lopez', 'Wilson', 'Anderson', 'Thomas', 'Taylor'];
        
        for (var i = 0; i < needed; i++) {
          var firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
          var lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
          var email = firstName.toLowerCase() + '.' + lastName.toLowerCase() + '@' + domain;
          
          // Make sure email is unique
          var emailExists = partner.employees.some(function(e) { return e.email && e.email.toLowerCase() === email.toLowerCase(); });
          var counter = 1;
          while (emailExists) {
            email = firstName.toLowerCase() + '.' + lastName.toLowerCase() + counter + '@' + domain;
            emailExists = partner.employees.some(function(e) { return e.email && e.email.toLowerCase() === email.toLowerCase(); });
            counter++;
          }
          
          // Generate employee ID if required
          var employeeId = null;
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireEmployeeId) {
            var prefix = partner.id === 'p1' ? 'EMP' : 
                        partner.id === 'p2' ? 'MFG' :
                        partner.id === 'p3' ? 'CON' :
                        partner.id === 'p4' ? 'HC' :
                        partner.id === 'p5' ? 'EN' :
                        partner.id === 'p6' ? 'LT' :
                        partner.id === 'p7' ? 'FP' :
                        partner.id === 'p8' ? 'AP' : 'EMP';
            var num = partner.employees.length + 1;
            employeeId = prefix + '-' + String(num).padStart(3, '0');
          }
          
          // Get voucher balances
          var voucherBalances = [];
          var remainingBalance = 0;
          if (partner.vouchers && partner.vouchers.length > 0) {
            var activeVouchers = partner.vouchers.filter(function(v) { return v.isActive; });
            activeVouchers.forEach(function(v) {
              if (v.userGroupIds && v.userGroupIds.indexOf(groupId) > -1) {
                voucherBalances.push({
                  voucherId: v.id,
                  remainingAmount: v.defaultAmount || 0
                });
                remainingBalance += (v.defaultAmount || 0);
              }
            });
          }
          
          var generatedEmployee = {
            id: 'emp_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9),
            name: firstName + ' ' + lastName,
            firstName: firstName,
            lastName: lastName,
            email: email,
            groupId: groupId,
            voucherExpiry: partner.vouchers && partner.vouchers.length > 0 ? partner.vouchers[0].endDate : '2024-12-31',
            voucherStatus: 'active',
            remainingBalance: remainingBalance,
            voucherBalances: voucherBalances,
            status: 'active'
          };
          
          // Ensure at least one identifier (Employee ID or Username)
          if (employeeId) {
            generatedEmployee.employeeId = employeeId;
          }
          
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireUsername) {
            generatedEmployee.username = email.split('@')[0];
          } else if (!employeeId) {
            // If no employee ID and username not required, add username anyway to ensure at least one identifier
            generatedEmployee.username = email.split('@')[0];
          }
          
          // Ensure at least one date (Birth Date or Start Date)
          var hasDate = false;
          
          // Add date of birth if required
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireDateOfBirth) {
            // Generate a random date of birth (age between 25-65)
            var age = 25 + Math.floor(Math.random() * 40);
            var birthYear = new Date().getFullYear() - age;
            var birthMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var birthDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            generatedEmployee.dateOfBirth = birthYear + '-' + birthMonth + '-' + birthDay;
            hasDate = true;
          }
          
          // Add start date if required
          if (partner.employeeFieldConfig && partner.employeeFieldConfig.requireStartDate) {
            // Generate a random start date (within last 5 years)
            var yearsAgo = Math.floor(Math.random() * 5);
            var startYear = new Date().getFullYear() - yearsAgo;
            var startMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var startDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            generatedEmployee.startDate = startYear + '-' + startMonth + '-' + startDay;
            hasDate = true;
          }
          
          // If no date was added yet, add a start date to ensure at least one date
          if (!hasDate) {
            var yearsAgo = Math.floor(Math.random() * 5);
            var startYear = new Date().getFullYear() - yearsAgo;
            var startMonth = String(Math.floor(Math.random() * 12) + 1).padStart(2, '0');
            var startDay = String(Math.floor(Math.random() * 28) + 1).padStart(2, '0');
            generatedEmployee.startDate = startYear + '-' + startMonth + '-' + startDay;
          }
          
          partner.employees.push(generatedEmployee);
        }
      }
      */
    });
  },
  
  enrichTransactions: function() {
    // Skip if transactions are empty
    if (!this.transactions || this.transactions.length === 0) {
      return;
    }
    
    // Group transactions by orderId
    var orderGroups = {};
    this.transactions.forEach(function(t) {
      if (!orderGroups[t.orderId]) {
        orderGroups[t.orderId] = [];
      }
      orderGroups[t.orderId].push(t);
    });
    
    // Process each order
    Object.keys(orderGroups).forEach(function(orderId) {
      var orderItems = orderGroups[orderId];
      var firstItem = orderItems[0];
      
      // Always enrich - don't skip even if fields exist (allows updates)
      
      var orderTotal = orderItems.reduce(function(sum, item) { return sum + item.totalPrice; }, 0);
      var voucherAmount = firstItem.voucherAmount || 0;
      
      // Generate order-level fields (same for all items in the order)
      var invoiceNumber = 'INV-' + orderId.replace('ORD-', '');
      var invoiceDate = firstItem.dateOrdered;
      // Due date is 30 days after invoice date
      var invoiceDateObj = new Date(invoiceDate);
      invoiceDateObj.setDate(invoiceDateObj.getDate() + 30);
      var invoiceDueDate = invoiceDateObj.toISOString().split('T')[0];
      var terms = 'Net 30';
      
      // Generate shipping info (use consistent seed based on orderId for reproducibility)
      var shippingCarriers = ['UPS', 'FedEx', 'USPS', 'DHL'];
      var shippingMethods = ['Standard', 'Two-Day Shipping'];
      var orderHash = orderId.split('').reduce(function(acc, char) { return acc + char.charCodeAt(0); }, 0);
      var shippingCarrier = shippingCarriers[orderHash % shippingCarriers.length];
      var shippingMethod = shippingMethods[orderHash % shippingMethods.length];
      var trackingNumber = shippingCarrier.substring(0, 1) + orderId.replace(/[^0-9]/g, '').substring(0, 9).padEnd(9, '0') + 'US';
      var shippingCost = orderTotal > 100 ? 0 : (shippingMethod === 'Two-Day Shipping' ? 15.99 : 8.99);
      
      // Generate shipping address (use employee info if available, otherwise generic)
      var shippingAddress = firstItem.employeeName + '<br>' + 
        (firstItem.employeeEmail ? firstItem.employeeEmail.split('@')[0] + '@' : '') +
        (firstItem.partnerName ? firstItem.partnerName.replace(/\s+/g, '').toLowerCase() + '.com' : 'company.com') +
        '<br>123 Main St<br>Anytown, ST 12345';
      
      // Get partner to determine available payment methods for remainder
      var partner = null;
      if (this.partners && Array.isArray(this.partners)) {
        partner = this.partners.find(function(p) { return p.name === firstItem.partnerName; });
      }
      var partnerPaymentMethods = partner && partner.paymentMethods ? partner.paymentMethods : ['Credit Card'];
      var hasPayrollDeduction = partnerPaymentMethods.indexOf('Payroll Deduction') !== -1;
      var hasCreditCard = partnerPaymentMethods.indexOf('Credit Card') !== -1;
      
      // Determine which payment method to use for remainder (prefer Payroll Deduction if available, otherwise Credit Card)
      var remainderPaymentMethod = hasPayrollDeduction ? 'Payroll Deduction' : 'Credit Card';
      
      // Calculate payment breakdown for each item
      // ALWAYS use voucher first, then remainder goes to credit card or payroll deduction
      var remainingVoucher = voucherAmount;
      orderItems.forEach(function(item, index) {
        // Add order-level fields
        item.invoiceNumber = invoiceNumber;
        item.invoiceDate = invoiceDate;
        item.invoiceDueDate = invoiceDueDate;
        item.terms = terms;
        item.shippingAddress = shippingAddress;
        item.shippingCarrier = shippingCarrier;
        item.shippingMethod = shippingMethod;
        item.trackingNumber = trackingNumber;
        item.shippingCost = index === 0 ? shippingCost : 0; // Only add shipping cost to first item
        
        // Calculate payment breakdown for this item
        // ALWAYS use voucher first, then remainder
        var itemTotal = item.totalPrice;
        var itemVoucherPaid = Math.min(itemTotal, remainingVoucher);
        remainingVoucher -= itemVoucherPaid;
        var itemRemainderPaid = itemTotal - itemVoucherPaid;
        
        // Set payment breakdown fields
        item.voucherAmountPaid = itemVoucherPaid;
        
        // Set remainder payment method based on partner's available methods
        if (itemRemainderPaid > 0) {
          if (remainderPaymentMethod === 'Payroll Deduction') {
            item.payrollDeductionAmountPaid = itemRemainderPaid;
            item.creditCardAmountPaid = 0;
          } else {
            item.creditCardAmountPaid = itemRemainderPaid;
            item.payrollDeductionAmountPaid = 0;
          }
          // Update payment method to reflect the actual split
          item.paymentMethod = itemVoucherPaid > 0 ? 'Mixed' : remainderPaymentMethod;
        } else {
          // Fully paid by voucher
          item.creditCardAmountPaid = 0;
          item.payrollDeductionAmountPaid = 0;
          item.paymentMethod = 'Voucher';
        }
      });
    });
  }
};

// Initialize state on load
$(function() {
  AppState.init();
});